#!/usr/bin/env node
/**
 * Think OS Jest supervisor (Node only, including Windows 10).
 * Jest decides whether a suite passed; this process only enforces a wall-clock
 * limit for each file and records the child's real exit code and output.
 * No PowerShell, stdout matching, or secondary JSON-based pass/fail decision.
 */
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import process from 'node:process';
import { fileURLToPath } from 'node:url';

const PROJECT_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const SELFTEST = process.env.THINK_TEST_INTERNAL_SELFTEST === '1';
const ROOT = SELFTEST && process.env.THINK_TEST_INTERNAL_ROOT
  ? path.resolve(process.env.THINK_TEST_INTERNAL_ROOT) : PROJECT_ROOT;
const JEST = SELFTEST && process.env.THINK_TEST_INTERNAL_JEST
  ? path.resolve(process.env.THINK_TEST_INTERNAL_JEST)
  : path.join(ROOT, 'node_modules/jest/bin/jest.js');
const CONFIG = SELFTEST && process.env.THINK_TEST_INTERNAL_CONFIG
  ? path.resolve(process.env.THINK_TEST_INTERNAL_CONFIG)
  : path.join(ROOT, 'test/configs/jest.core.config.js');
const REPORT_DIR = SELFTEST && process.env.THINK_TEST_INTERNAL_REPORT_DIR
  ? path.resolve(process.env.THINK_TEST_INTERNAL_REPORT_DIR)
  : path.join(ROOT, 'reports/testing');
const RAW_LOG = path.join(REPORT_DIR, '日常测试-完整技术日志.txt');
const FAILURE_LOG = path.join(REPORT_DIR, '日常测试-失败技术日志.txt');
const SUMMARY_FILE = path.join(REPORT_DIR, '日常测试-汇总.json');
const RUN_ARGS = process.argv.slice(2);
const specifiedTimeout = Number(process.env.THINK_TEST_FILE_TIMEOUT_MS);
const TIMEOUT_MS = SELFTEST && Number.isFinite(specifiedTimeout) && specifiedTimeout >= 100
  ? specifiedTimeout : 30_000;
const DISCOVERY_TIMEOUT_MS = SELFTEST ? 10_000 : 90_000;
const STOP_GRACE_MS = 7_000;

let interrupted = false;
let activeChild = null;
let activeTerminate = null;
let completedNormally = false;
let started = false;
let rawFd = null;
let report = null;
let testStartedAt = Date.now();

const relative = (file) => path.relative(ROOT, file).replace(/\\/g, '/');
const explain = (value) => String(value?.stack || value?.message || value);
const cleanTail = (text, max = 16000) => text.length > max ? text.slice(-max) : text;

function recordRaw(text) {
  if (rawFd !== null) fs.writeSync(rawFd, String(text));
}
function saveSummary() {
  if (!report) return;
  report.durationMs = Date.now() - testStartedAt;
  report.counts = {
    passed: report.files.filter((item) => item.status === '通过').length,
    failed: report.files.filter((item) => item.status === '失败').length,
    timedOut: report.files.filter((item) => item.status === '超时').length,
    notRun: report.total - report.files.length,
  };
  report.success = Boolean(report.completed && !report.interrupted && report.total > 0 &&
    report.counts.passed === report.total);
  fs.writeFileSync(SUMMARY_FILE, `${JSON.stringify(report, null, 2)}\n`, 'utf8');
}
function recordFailure(file, reason, detail = '') {
  fs.appendFileSync(FAILURE_LOG,
    `\n===== ${file} =====\n${reason}\n${detail || '没有收到 Jest 的错误输出'}\n`, 'utf8');
}

// Kill the whole subprocess tree on Windows; child.kill() alone does not kill
// grandchildren. POSIX children are placed in their own process group.
function terminateTree(child) {
  if (!child || !Number.isInteger(child.pid)) return;
  if (process.platform === 'win32') {
    try {
      const killer = spawn('taskkill.exe', ['/PID', String(child.pid), '/T', '/F'], {
        windowsHide: true, stdio: 'ignore', shell: false,
      });
      killer.once('error', () => { try { child.kill('SIGKILL'); } catch { /* process has exited */ } });
      killer.once('close', (code) => {
        if (code !== 0) { try { child.kill('SIGKILL'); } catch { /* process has exited */ } }
      });
      killer.unref();
    } catch { try { child.kill('SIGKILL'); } catch { /* process has exited */ } }
  } else {
    try { process.kill(-child.pid, 'SIGKILL'); }
    catch { try { child.kill('SIGKILL'); } catch { /* process has exited */ } }
  }
}

/** Await the real 'close' event; retain a timer so an unresolved Promise cannot
 * silently let the parent exit. A process that cannot be stopped is a fatal
 * supervisor error; do NOT start another Jest process while it may still run.
 */
function execute(args, { timeoutMs, env = process.env, onOutput = () => {} } = {}) {
  return new Promise((resolve) => {
    let child;
    let closed = false;
    let timedOut = false;
    let startError = null;
    let unableToStop = false;
    let stdout = '';
    let stderr = '';
    let deadline = null;
    let stopDeadline = null;
    const start = Date.now();

    const finish = (code, signal) => {
      if (closed) return;
      closed = true;
      clearTimeout(deadline);
      clearTimeout(stopDeadline);
      if (activeChild === child) { activeChild = null; activeTerminate = null; }
      resolve({ code, signal, timedOut, unableToStop, startError,
        durationMs: Date.now() - start, stdout, stderr });
    };
    const append = (kind, data) => {
      const chunk = String(data);
      onOutput(chunk, kind);
      if (kind === 'stdout') stdout = cleanTail(stdout + chunk, 128 * 1024);
      else stderr = cleanTail(stderr + chunk, 128 * 1024);
    };

    try {
      child = spawn(process.execPath, [JEST, ...args], {
        cwd: ROOT, env, windowsHide: true, shell: false,
        detached: process.platform !== 'win32',
        stdio: ['ignore', 'pipe', 'pipe'],
      });
    } catch (error) {
      startError = explain(error);
      finish(null, null);
      return;
    }
    activeChild = child;
    activeTerminate = () => {
      if (closed) return;
      terminateTree(child);
    };
    child.stdout?.setEncoding('utf8');
    child.stderr?.setEncoding('utf8');
    child.stdout?.on('data', (chunk) => append('stdout', chunk));
    child.stderr?.on('data', (chunk) => append('stderr', chunk));
    child.once('error', (error) => { startError = explain(error); });
    child.once('close', (code, signal) => finish(code, signal));

    deadline = setTimeout(() => {
      if (closed) return;
      timedOut = true;
      terminateTree(child);
      stopDeadline = setTimeout(() => {
        if (closed) return;
        unableToStop = true;
        try { child.kill('SIGKILL'); } catch { /* no-op */ }
        child.stdout?.destroy();
        child.stderr?.destroy();
        child.unref();
        finish(null, 'UNCONFIRMED_TERMINATION');
      }, STOP_GRACE_MS);
    }, timeoutMs);
  });
}

function selectRunOptions() {
  // File selection belongs only to --listTests. Forward only options that
  // actually affect each chosen Jest suite; never reapply --findRelatedTests.
  const forwarded = [];
  for (let i = 0; i < RUN_ARGS.length; i++) {
    const arg = RUN_ARGS[i];
    if ((arg === '-t' || arg === '--testNamePattern') && RUN_ARGS[i + 1]) {
      forwarded.push(arg, RUN_ARGS[++i]);
    } else if (/^--testNamePattern=/.test(arg) || ['-u', '--updateSnapshot', '--no-cache'].includes(arg)) {
      forwarded.push(arg);
    }
  }
  return forwarded;
}

async function discover() {
  const args = ['--config', CONFIG, '--listTests', '--json', '--runInBand', ...RUN_ARGS];
  const result = await execute(args, { timeoutMs: DISCOVERY_TIMEOUT_MS });
  if (result.unableToStop) throw new Error('Jest 列表查询无法终止，已停止整轮运行。');
  if (result.timedOut) throw new Error('Jest 列表查询超时，尚未执行测试。');
  if (result.startError || result.code !== 0) {
    throw new Error(`Jest 列表查询失败（退出码 ${result.code ?? '缺失'}）：${result.startError || result.stderr || result.stdout}`);
  }
  let files;
  try { files = JSON.parse(result.stdout.trim()); }
  catch { throw new Error(`Jest 列表不是有效 JSON：${cleanTail(result.stdout, 1200)}`); }
  if (!Array.isArray(files) || files.length === 0 || files.some((file) => typeof file !== 'string' || !file)) {
    throw new Error('Jest 未提供有效的测试文件列表；不能把 0 个文件视为通过。');
  }
  return [...new Set(files.map((file) => path.resolve(ROOT, file)))];
}

async function runFile(file, index, total) {
  const name = relative(file);
  const childFailure = path.join(REPORT_DIR, '.jest-current-failure.txt');
  const childReport = path.join(REPORT_DIR, '.jest-current-report.json');
  fs.rmSync(childFailure, { force: true });
  fs.rmSync(childReport, { force: true });
  console.log(`【正在测试 ${index}/${total}】${name}`);
  report.activeFile = name;
  saveSummary();
  recordRaw(`\n===== ${index}/${total} ${name} =====\n`);
  const result = await execute([
    '--config', CONFIG, '--runInBand', '--runTestsByPath', file, ...selectRunOptions(),
  ], {
    timeoutMs: TIMEOUT_MS,
    env: {
      ...process.env,
      THINK_JEST_REPORT_FILE: '',
      THINK_JEST_FAILURE_FILE: childFailure,
      THINK_JEST_STRUCTURED_FILE: childReport,
      THINK_TEST_LABEL: '日常测试',
    },
    onOutput: recordRaw,
  });

  // One source of truth: the Jest process's actual exit code.
  // JSON generated by the Chinese reporter is diagnostic information only.
  const status = result.timedOut ? '超时' :
    result.code === 0 && !result.startError && !result.unableToStop ? '通过' : '失败';
  const reason = result.timedOut
    ? `超过 ${TIMEOUT_MS / 1000} 秒，已终止 Jest 进程树。`
    : result.unableToStop
      ? '无法确认 Jest 进程已经停止，为安全起见中止整轮运行。'
      : `Jest 退出码=${result.code ?? '缺失'}；信号=${result.signal || '无'}；启动错误=${result.startError || '无'}`;
  if (status !== '通过') {
    const failureText = fs.existsSync(childFailure) ? fs.readFileSync(childFailure, 'utf8') : '';
    recordFailure(name, reason, cleanTail(failureText || result.stderr || result.stdout));
    console.log(`【测试诊断】${reason}`);
  }
  fs.rmSync(childFailure, { force: true });
  fs.rmSync(childReport, { force: true });
  const entry = { file: name, status, durationMs: result.durationMs,
    exitCode: result.code, signal: result.signal || null, ...(result.startError ? { error: result.startError } : {}) };
  report.files.push(entry);
  report.activeFile = null;
  saveSummary();
  console.log(`【测试文件】${status}：${name}（耗时 ${result.durationMs}ms）`);
  return !result.unableToStop;
}

function onInterrupt(signal) {
  interrupted = true;
  console.error(`\n【测试调度】收到 ${signal}，正在终止当前测试并保存进度。`);
  activeTerminate?.();
}
process.on('SIGINT', () => onInterrupt('Ctrl+C'));
process.on('SIGTERM', () => onInterrupt('SIGTERM'));
process.on('beforeExit', () => {
  if (started && !completedNormally) {
    try {
      if (report) { report.completed = false; report.interrupted = true; saveSummary(); }
      recordFailure('测试调度器', '运行器未正常完成；请检查原始技术日志。');
    } catch { /* cannot recover filesystem failures */ }
    console.error('【测试调度错误】进程未正常结束，结果未通过。');
    process.exitCode = 2;
  }
});

async function main() {
  if (!fs.existsSync(JEST)) throw new Error('未找到 Jest，可先运行 npm ci。');
  fs.mkdirSync(REPORT_DIR, { recursive: true });
  fs.writeFileSync(FAILURE_LOG, '', 'utf8');
  rawFd = fs.openSync(RAW_LOG, 'w');
  testStartedAt = Date.now();
  report = {
    schemaVersion: 2, runner: 'node-jest-supervisor', total: 0, completed: false,
    interrupted: false, success: false, testFileTimeoutMs: TIMEOUT_MS,
    startedAt: new Date().toISOString(), activeFile: null, files: [],
  };
  started = true;
  saveSummary();
  let fatal = false;
  try {
    const files = await discover();
    report.total = files.length;
    saveSummary();
    console.log(`【测试】共 ${files.length} 个文件；Node 逐文件执行，每个文件最长 ${TIMEOUT_MS / 1000} 秒。`);
    console.log('【测试】失败继续执行；不依赖 PowerShell，也不二次判断中文报告。');
    for (let i = 0; i < files.length; i++) {
      if (interrupted) break;
      const safeToContinue = await runFile(files[i], i + 1, files.length);
      if (!safeToContinue) { fatal = true; break; }
    }
    report.interrupted = interrupted || fatal;
    report.completed = !report.interrupted && report.files.length === report.total;
    saveSummary();
  } catch (error) {
    fatal = true;
    const reason = explain(error);
    console.error(`【测试调度错误】${reason}`);
    recordFailure('测试调度器', reason);
    recordRaw(`\n【测试调度错误】${reason}\n`);
    report.error = reason;
    report.interrupted = true;
    report.completed = false;
    saveSummary();
  } finally {
    if (rawFd !== null) { fs.closeSync(rawFd); rawFd = null; }
  }
  const { passed, failed, timedOut, notRun } = report.counts;
  console.log(`\n【测试汇总】共 ${report.total} 个文件，通过 ${passed}，失败 ${failed}，超时 ${timedOut}，未执行 ${notRun}。`);
  console.log(`【测试汇总】${report.success ? '全部通过' : '存在失败或未完成'}；${relative(SUMMARY_FILE)}`);
  if (!report.success) console.log(`【失败详情】${relative(FAILURE_LOG)}`);
  completedNormally = true;
  process.exitCode = report.success ? 0 : (interrupted ? 130 : (fatal ? 2 : 1));
}

try { await main(); }
catch (error) {
  console.error(`【测试调度错误】${explain(error)}`);
  process.exitCode = 2;
}
