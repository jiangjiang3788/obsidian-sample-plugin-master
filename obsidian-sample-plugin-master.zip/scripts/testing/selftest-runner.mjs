#!/usr/bin/env node
// No npm dependencies required. Proves the supervisor's behavior with fake Jest
// subprocesses BEFORE asking Windows 10 to run hundreds of real suites.
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import process from 'node:process';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const runner = path.join(here, 'run-jest-with-timeout.mjs');
const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'thinkos-runner-selftest-'));
const root = path.join(temp, 'test project with spaces');
const reports = path.join(temp, 'reports');
const fakeJest = path.join(temp, 'fake-jest.cjs');
const config = path.join(root, 'test/configs/jest.core.config.js');
const names = ['pass 中文 空格.test.ts', 'fail.test.ts', 'hang.test.ts', 'pass-last.test.ts'];

function runSupervisor(scenario, timeoutMs = 8000, selection = []) {
  return new Promise((resolve, reject) => {
    const child = spawn(process.execPath, [runner, ...selection], {
      cwd: root, windowsHide: true, shell: false,
      env: {
        ...process.env,
        THINK_TEST_INTERNAL_SELFTEST: '1',
        THINK_TEST_INTERNAL_ROOT: root,
        THINK_TEST_INTERNAL_JEST: fakeJest,
        THINK_TEST_INTERNAL_CONFIG: config,
        THINK_TEST_INTERNAL_REPORT_DIR: reports,
        THINK_TEST_INTERNAL_CASE: scenario,
        THINK_TEST_FILE_TIMEOUT_MS: String(timeoutMs),
      },
      stdio: ['ignore', 'pipe', 'pipe'],
    });
    let output = '';
    child.stdout.on('data', (data) => { output += String(data); });
    child.stderr.on('data', (data) => { output += String(data); });
    child.once('error', reject);
    const timer = setTimeout(() => {
      child.kill('SIGKILL');
      reject(new Error(`模拟场景 ${scenario} 调度器未能正常退出：${output.slice(-2000)}`));
    }, 40_000);
    child.once('close', (code, signal) => {
      clearTimeout(timer);
      try {
        const summaryPath = path.join(reports, '日常测试-汇总.json');
        const summary = fs.existsSync(summaryPath) ? JSON.parse(fs.readFileSync(summaryPath, 'utf8')) : null;
        resolve({ code, signal, output, summary });
      } catch (error) { reject(error); }
    });
  });
}

const fakeCode = String.raw`
const fs = require('node:fs');
const path = require('node:path');
const args = process.argv.slice(2);
const root = process.env.THINK_TEST_INTERNAL_ROOT;
const scenario = process.env.THINK_TEST_INTERNAL_CASE;
const choose = {
  pass: ['pass 中文 空格.test.ts', 'pass-last.test.ts'],
  fail: ['pass 中文 空格.test.ts', 'fail.test.ts', 'pass-last.test.ts'],
  timeout: ['pass 中文 空格.test.ts', 'hang.test.ts', 'pass-last.test.ts'],
  empty: [],
  badjson: [],
};
let all = choose[scenario] || [];
if (args.includes('--listTests')) {
  const selection = args.find(a => a.endsWith('.test.ts'));
  if (selection) all = all.filter(n => n.includes(selection));
  if (scenario === 'badjson') { process.stdout.write('invalid result\n'); process.exit(0); }
  process.stdout.write(JSON.stringify(all.map(n => path.join(root, 'test/unit', n))));
  process.exit(0);
}
const target = args[args.indexOf('--runTestsByPath') + 1];
const name = path.basename(target || '');
if (!all.includes(name)) { console.error('fake Jest: unknown test file'); process.exit(2); }
if (name === 'hang.test.ts') {
  setInterval(() => {}, 1000);
} else if (name === 'fail.test.ts') {
  console.error('SIMULATED ASSERTION FAILURE');
  process.exitCode = 1;
} else {
  console.log('SIMULATED JEST PASS: ' + name);
  process.exitCode = 0;
}
`;

try {
  fs.mkdirSync(path.dirname(config), { recursive: true });
  fs.mkdirSync(path.join(root, 'test/unit'), { recursive: true });
  fs.writeFileSync(config, 'module.exports = {};\n');
  for (const name of names) fs.writeFileSync(path.join(root, 'test/unit', name), '');
  fs.writeFileSync(fakeJest, fakeCode);

  let result = await runSupervisor('pass');
  assert.equal(result.code, 0, `全通过场景不应失败：${result.output}`);
  assert.equal(result.summary?.success, true);
  assert.deepEqual(result.summary?.counts, { passed: 2, failed: 0, timedOut: 0, notRun: 0 });
  console.log('【运行器自检】正常通过、中文/空格路径：通过');

  result = await runSupervisor('pass', 8000, ['pass-last.test.ts']);
  assert.equal(result.code, 0, `单文件选择不应失败：${result.output}`);
  assert.equal(result.summary?.total, 1);
  assert.deepEqual(result.summary?.counts, { passed: 1, failed: 0, timedOut: 0, notRun: 0 });
  console.log('【运行器自检】命令行选择单文件：通过');

  result = await runSupervisor('fail');
  assert.equal(result.code, 1, `断言失败场景退出码应为 1：${result.output}`);
  assert.equal(result.summary?.completed, true);
  assert.deepEqual(result.summary?.counts, { passed: 2, failed: 1, timedOut: 0, notRun: 0 });
  assert.ok(result.output.includes('pass-last.test.ts'), '失败后仍应执行下一文件');
  console.log('【运行器自检】真实失败如实记录、失败后继续：通过');

  result = await runSupervisor('timeout', 2500);
  assert.equal(result.code, 1, `超时场景退出码应为 1：${result.output}`);
  assert.equal(result.summary?.completed, true);
  assert.deepEqual(result.summary?.counts, { passed: 2, failed: 0, timedOut: 1, notRun: 0 });
  assert.ok(result.output.includes('pass-last.test.ts'), '超时后仍应执行下一文件');
  console.log('【运行器自检】强制超时、终止后继续：通过');

  result = await runSupervisor('empty');
  assert.notEqual(result.code, 0);
  assert.equal(result.summary?.success, false);
  console.log('【运行器自检】无测试文件不能误报成功：通过');

  result = await runSupervisor('badjson');
  assert.notEqual(result.code, 0);
  assert.equal(result.summary?.success, false);
  console.log('【运行器自检】列表解析错误不能误报成功：通过');

  console.log('【运行器自检】全部六组通过，未运行真实项目的 Jest 测试。');
} catch (error) {
  console.error(`【运行器自检失败】${String(error?.stack || error)}`);
  process.exitCode = 1;
} finally {
  try { fs.rmSync(temp, { recursive: true, force: true }); }
  catch { /* Antiviruses may momentarily hold temp files on Windows */ }
}
