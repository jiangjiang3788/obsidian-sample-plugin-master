# Think OS 文档入口

`docs/` 是 Think OS 唯一的实质文档目录；项目根目录只保留标准入口 `README.md`。旧 `doc/` 目录已并入这里，禁止重新创建。

## 当前事实（active truth）

- `ARCHITECTURE.md` — 当前模块边界与依赖方向。
- `RECORD_MODEL.md` — Canonical Record、Record Presentation、Template 与 Field 语义。
- `TESTING_RELEASE.md` — 本地验证、CI 与发布检查。
- `CSS_DESIGN_SPEC.md` — 当前 UI / CSS 设计合同。
- `UI_REDESIGN_PLAN.md` — UI 重构阶段与当前进度。
- `DEVELOPMENT_GUARDRAILS.md` — 防止架构再次发散的开发规则。
- `DOCUMENT_GOVERNANCE.md` — 文档归档与目录治理规则。

## 版本实施

- `releases/1.7.1/` — 1.7.1 Continue Panel：QuickInput/Continuation 共用记录类型可创建性与固定顺序、Continuation 多类型入口、仅成功态允许外部关闭、QuickInput intrinsic-height 根因修复。
- `releases/1.7.0/` — 1.7.0 Record Continuation：`PLAN.md` / `IMPLEMENTATION_RESULT.md` / `TEST_REPORT.md`；完成任务后的同 Goal 打卡建议与 QuickInput 连续录入，RecordRelation 作为后续阶段，不与白板耦合。
- `releases/1.6.0/` — 1.6.0 Presentation Convergence：10 种用户记录类型颜色所有权、Whiteboard/Timeline 交互收敛与发布验证。
- `releases/1.5.0/` — 1.5.0 Record Domain Convergence 的计划、实施结果与测试报告。
- `releases/1.4.0/` — 1.4.0 Record Presentation Contract + Whiteboard Visual Cleanup 的计划、实施结果与测试报告。

## 专项文档

- `testing/` — 测试体系、命令、真实数据/E2E 规范。
- `reports/` — 仍需要随当前源码携带的专题报告。
- `history/` — 历史 Whiteboard 基线、旧 PATCH 说明、旧实施结果与迁移资料；仅用于追溯，不是当前接口。

## 1.5.0 数据迁移

离线迁移入口：`scripts/migration/converge-record-domain-1.5.0.mjs`。它可清洗 Settings，并可选通过 `--vault` 迁移 Markdown Record Blocks；迁移前应保留原始数据备份。
