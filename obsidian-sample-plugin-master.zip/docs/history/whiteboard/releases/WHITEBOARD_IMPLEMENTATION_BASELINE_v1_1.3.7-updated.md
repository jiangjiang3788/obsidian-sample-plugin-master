# ThinkOS 白板 — 实施基线 v1.3.7

> 当前版本：**1.3.7 Real-use Interaction Hotfix**。
> 白板仍是 ThinkOS 一级工作区，不是普通 Dashboard View。
> 所有新增/更新交付文档继续统一放项目根目录 `doc/`。

## 1. 产品真源与基本合同

- canonical Record 唯一业务真源仍是 Markdown Record + RecordRepository / DataStore；Whiteboard 只保存 projection / spatial state。
- 左侧检索继续唯一复用 `RecordQuery`；右侧白板永远不被左侧过滤隐藏或重排。
- `Think/whiteboards.json` 继续 `version: 1`。
- Durable world `x/y` 允许负数；camera / zoom / LOD / locator / selection / marquee / layout guide / nested navigation history / undo UI state 均为 ephemeral。
- Nested Workbench 最多 4 层，继续 `parentGroupId + absolute world XY + atomic subtree translate`；不做破坏性 parent-local migration。
- `screenLocal = (world - camera) * zoom`，`world = camera + screenLocal / zoom`。
- Zoom 继续 0.5%–12800%；低倍率使用 semantic locator 保证对象位置可见、可找回。

## 2. 当前 durable whiteboard 模型

```ts
WhiteboardBoard {
  title;
  items: WhiteboardItem[];
  edges: WhiteboardEdge[];
  groups?: WhiteboardGroup[];
  annotations?: WhiteboardAnnotation[];
  archivedItems?: WhiteboardArchivedItem[];
  archivedEdges?: WhiteboardEdge[];
  modified;
}

WhiteboardItem {
  id; recordId;
  x; y; zIndex?;
  groupId?;
}

WhiteboardArchivedItem extends WhiteboardItem {
  archivedAt;
  archiveX?; archiveY?; archiveZIndex?;
}

WhiteboardGroup {
  id; title;
  x; y;
  collapsed;
  parentGroupId?;
}

WhiteboardAnnotation {
  id;
  kind: "text" | "sticky";
  text;
  x; y; zIndex?;
  groupId?;
}

WhiteboardEdge {
  id;
  fromItemId;
  toItemId;
  label?;
}
```

Archive 坐标合同：

- `x/y/zIndex/groupId` = Restore origin；
- `archiveX/archiveY/archiveZIndex` = Archive Canvas 内独立位置；
- 归档空间重排不能覆盖 Restore origin；
- 父 Workbench subtree 在主白板移动时，归档成员 Restore origin 跟随 parent tree；Archive Canvas placement 不跟着主画布漂移。

## 3. 已完成主路线

### 1.1.0–1.1.9

独立 Whiteboard Workspace → Record Source Retrieval → 左右拖 → Find → Zoom/Pan/world-camera-screen → 左侧批量选择 → Workbench → Canvas 多选 → drag-to-connect → Archive/Restore。

### 1.2.0–1.2.5 R3

Undo/Redo → Nested Workbench（最多 4 层）→ breadcrumb/Back/Forward/Parent/Root → Text/Sticky → Edge label → 右键 arrange → Nested Find/Fit → pointer-world nested drop → content-aware Home。

### 1.2.6–1.2.8

Semantic Zoom / compact / overview → fixed-screen locator → locator 点击回真实对象 100%。

### 1.3.0

跨功能 Stability Closure；新增白板专项测试入口；性能优化继续保持“有真实证据才做”。

## 4. 1.3.1 — Archive Canvas（✅ 代码完成）

- 归档从侧栏升级为全屏空间工作台；
- Pan / Zoom / Ctrl/⌘ marquee / multi-select / multi-drag；
- Grid 与 Goal×Type×Time arrange；
- Center 100% / Fit Content；
- Archive placement 与 Restore origin 分离；
- old archived item 无 archiveX/Y 时稳定 fallback，零迁移读取。

## 5. 1.3.2 — Semantic Interaction（✅ 代码完成）

- compact / overview locator 可直接选择与拖动；
- Ctrl/⌘ 点选 / 框选可混选当前 Canvas 直属 Card + Workbench；
- Workbench 作为 subtree 原子节点；
- 当前 Canvas 不重复暴露嵌套内部节点；
- mixed selection 一次 `translateNodes` 写盘 / 一次 Undo history；
- ancestor + descendant group / group + internal Card 自动去重，防止 double translate；
- detail 模式仍保持原卡片选择体验。

## 6. 1.3.3 — Goal × Record Type × Time（✅ 代码完成）

唯一公开 preset：

- `groupBy = Goal`；
- `x = Record Type`（canonical order）；
- `y = Time`（month / ascending）；
- `cellLayout = grid`。

产品约束：

- 一个 Goal 一块；
- Goal 下横向类型，纵向时间；
- 同 cell 多卡局部网格；
- 无 Goal / 无时间有稳定 fallback；
- 默认批量拖入仍为 neutral grid；
- Arrange 只改 XY，绝不自动创建 Workbench。

底层 `WhiteboardLayoutSpec` 已真正驱动 group/x/y，未来可开放配置；第一版明确不暴露轴/分组设置面板。

## 7. 1.3.4 — Layout Header Selection（✅ 代码完成）

- Goal 区块标题可选中整个 Goal 的卡；
- Record Type 列标题可选中该类型卡；
- Time 行标题可选中该月卡；
- 标题回选后可以继续拖动 / 归档 / 创建 Workbench；
- guide 不持久化；Arrange != Group。

## 8. 测试与发布基线

功能地图：119 项；P0 43/43、P1 71/71、P2 5/5 证据完整。

本环境已真实通过：

- test:syntax / language / evidence / surface / system:strict:p2；
- gate:architecture / records / task-session / energy / ui-runtime。

与 untouched 1.3.5 对照：

- `gate:quality` 仍为既有 explicit-any budget，数值完全相同（src 400、test 598、scripts 4、total 1002）；
- `gate:stability` 仍为既有缺 CI workflow；
- `gate:product` 仍为同一 CI / README release contract；version-sync / manifest 自身通过。

交付容器没有 `node_modules`，实际 Typecheck 入口缺 Jest / Preact / WDIO / Node 类型，所以 Jest / 完整 Typecheck / Vite build / Obsidian E2E 必须在用户本机依赖完整环境跑。稳定候选阻断命令：

```bash
npm run test:whiteboard:full
```

## 9. 1.3.5 — Low-Zoom Mixed Arrange（✅ 代码完成）

- compact / overview 下 mixed Card + Workbench selection 可直接右键整理；
- 支持网格、左/顶对齐、水平/垂直等距；
- Workbench 使用 subtree 真实 frame，作为原子节点参与排布；
- `WhiteboardStore.moveNodes` 一次 mutation 提交 itemMoves + groupMoves，一次 Undo / persistence；
- mixed selection 含 Workbench 时禁用 Card-only 的“按连线 / Goal×Type×Time / 用所选创建工作台”；
- 右键空白可“网格整理当前层”；
- Goal / Type / Time guide 在低倍率使用 inverse zoom 保持标题可读。

## 10. 1.3.6 — Daily-use Closure（✅ 代码与测试契约完成）

1.3.6 不新增白板模型，正式把完整日常主链定义为 P0 F152：

- 左侧批量 Record → neutral grid；
- 用户主动 Goal×Type×Time；
- layout header 回选；
- compact / overview 低倍率直接整理；
- locator 回 100% 后继续创建 Workbench；
- Nested Workbench L1–L4；
- Archive Canvas 独立 placement；
- Restore 回原 world XY + groupId；
- Restore 紧接一次 Undo 回到归档 snapshot；
- Restart 保留 durable state，但不保留 history / selection / camera。

新增专门 Store 回归锁定：Undo Restore 时 `archiveX/archiveY/archiveZIndex`、Restore origin、Workbench membership、incident edge 都不能丢。

静态审阅未发现需要新增 production schema/model 的断点，因此本版主要交付连续 integration/E2E 与历史边界回归。真机若发现问题，只修阻断 F152 的摩擦。

## 11. 下一阶段路线

### Feature Freeze / Real-use Observation

1.3.6 真机主链绿后，白板新增功能冻结一段时间；优先真实使用、收集摩擦和失败样本，不再按版本号继续堆模型。

### Performance（仍为条件项）

只有真机大白板明确出现性能瓶颈才实施 viewport/Edge culling、spatial index、locator clustering、lazy render。没有证据就跳过。

### Later — User-triggered AI Chat

只有用户主动选择 Card / Workbench 并点击“和 AI 聊”时构造 context；不做后台自动推荐、聚类、自动连线或因果判断。

## 12. 明确不做

- 不默认把拖入动作升级成语义解释；
- 不自动按 Goal/Type 生成 Workbench；
- 不开放第一版复杂布局配置 UI；
- 不做 AI 自动聚类/关系猜测；
- 不做无限递归 Workbench；
- 不在没有性能证据时提前做 spatial index；
- 不做强制 parent-local durable migration。

---

## 13. 1.3.7 — Real-use Interaction Hotfix（✅ 代码与静态门禁完成）

1.3.7 不扩功能面，只修 1.3.6 Daily-use Closure 真机使用暴露的空间交互断点：

- Text / Sticky 在 detail / compact 继续直接拖，overview 的 T/◆ Locator 也可拖并持久化 Annotation XY；
- Annotation 与 semantic guide 的 screen drag delta 均按 zoom 换算，允许负 world 坐标；
- Goal / Record Type / Time guide 标签可拖，边框/横线/竖线同步移动；Guide 继续 ephemeral，不改卡片、Record、Group；
- compact / overview 纯 Card selection 可拖回左侧 Record Source，复用 detail 的“移出白板、不删 Record”语义；
- mixed selection 含 Workbench 时不触发 source removal；
- semantic source-drop 单独收敛到 controller，保持 Workspace TSX 架构预算不回退；
- `Think/whiteboards.json` 仍为 version 1，无 migration。

功能地图仍为 119 项，修复证据归入 F139 / F148 / F150。

冻结条件更新为：**1.3.7 真机验证上述三条交互并重新跑通 1.3.6 Daily-use Closure 后，进入 Feature Freeze / Real-use Observation。**
