# ThinkOS 白板 — 实施基线 v1

> 当前版本：**1.1.6 Record Source 多选 / 全选结果 / 批量拖入。**
> 当前产品定义：**白板是 ThinkOS 一级工作区，不是普通 View。**
> 它不注册进 ThinkOS Dashboard View registry，不插入 Layout，不受 Dashboard Toolbar / DateRange / globalFilters 控制。
> 白板仍然是 canonical Record 的 Projection：只引用 `recordId`，不复制 Record 内容，不修改 Markdown Record 真源。

## 1. 产品边界

### 1.1 一级入口

```text
ThinkOS
├─ Dashboard / 普通布局
├─ Settings / 其他能力
└─ 白板
```

技术宿主可以使用 Obsidian `WorkspaceLeaf / ItemView`，但这只是平台容器；产品和 ThinkOS 架构上都不能把白板重新解释成 TableView / TimelineView 一类普通 View。

### 1.2 最终页面结构

```text
┌──────────────────────────────────────────────────────────────┐
│ ThinkOS · 白板                   定位卡片 / 缩放 / Pan       │
├─────────────────────┬────────────────────────────────────────┤
│ 左：Record Source    │ 右：Whiteboard                         │
│                     │                                        │
│ 搜索记录             │ 已加入的卡片                           │
│ Record Type 筛选     │ XY 自由摆放                            │
│ Goal 筛选            │ A → B 显式方向                         │
│ 时间筛选             │                                        │
│                     │ 不受左侧筛选影响                       │
│ 搜索结果             │                                        │
└─────────────────────┴────────────────────────────────────────┘
```

## 2. 三种查找语义必须分开

### 2.1 搜索记录

作用域：全部 canonical Records。

回答：**“我以前写过什么？”**

搜索自由文本，例如“睡眠”“刷手机”“肩膀”“编程”。

### 2.2 筛选记录

作用域：左侧候选 Record Source。

回答：**“我只想在什么范围里找？”**

规划支持：
- Record Type；
- Goal；
- 时间 / dateRole；
- 后续真实需求证明后再加其他筛选。

搜索与筛选必须继续复用 `RecordQuery`，不得创建第二套查询/时间语义。

明确不做“已加入 / 未加入”筛选。是否已在白板上由右侧空间本身表达。

### 2.3 定位卡片

作用域：当前白板已经存在的 WhiteboardItems。

回答：**“我已经放进来的那张卡在哪里？”**

规划行为：
- Ctrl+F / 顶部“定位卡片”；
- 命中卡高亮；
- 非命中卡淡化；
- 上一个 / 下一个通过 ephemeral camera 把目标 world 点带到视野中心；
- 不隐藏、不重排、不写盘、不改变 XY/Edge。

## 3. 核心交互

### 3.1 左 → 右

最终主交互：从左侧 Record Source 直接拖入右侧指定位置。

```text
Record candidate
  → drag
  → drop on board
  → addRecord(boardId, recordId, {x,y})
```

“加入”和“放在哪里”合成一次动作。

### 3.2 右 → 左

将卡拖回左栏 = **移出当前白板**。

只删除 WhiteboardItem projection，并同步删除与它相连的 incident edges；绝不删除原 Record / Markdown。

### 3.3 白板内直接操纵

已验证并保留：
- XY 拖动；
- pointermove 只 preview；
- pointerup 单次 commit；
- zIndex；
- A → B 显式方向；
- 删除 edge；
- 拖卡时 edge 实时跟随；
- canonical Record 点击打开；
- dangling Record 不自动清理；
- 空白处 Pointer Pan 与普通 wheel/trackpad Pan；
- world x/y 允许为负，Pan/Zoom 只改 ephemeral camera/zoom。

## 4. 数据真源

### 4.1 Canonical Record

唯一业务真源仍是 Markdown Record + RecordRepository / DataStore。

白板禁止保存：
- title/content 快照；
- Goal/date/type 副本；
- AI summary；
- embedding；
- 自动 cluster/thread。

### 4.2 Whiteboard durable state

新真源：

```text
Think/whiteboards.json
```

当前模型：

```ts
WhiteboardStoreData {
  version: 1;
  boards: Record<string, WhiteboardBoard>;
}

WhiteboardBoard {
  title: string;
  items: WhiteboardItem[];
  edges: WhiteboardEdge[];
  modified: number;
}

WhiteboardItem {
  id: string;
  recordId: string;
  x: number;
  y: number;
  zIndex?: number;
}

WhiteboardEdge {
  id: string;
  fromItemId: string;
  toItemId: string;
}
```

1.1.5 坐标合同：

```text
world = WhiteboardItem.x/y 所在的持久化逻辑平面，可为负数
camera = 当前 viewport 左上角对应的 world 坐标，仅内存
screenLocal = (world - camera) * zoom
world = camera + screenLocal / zoom
```

`WhiteboardItem.x/y` 仍是唯一持久化空间坐标；`camera/zoom` 不进入 `whiteboards.json`。Pan 与 Zoom 的连续更新不得调用 WhiteboardStore mutation。

### 4.3 Identity

白板 ID 与 `ViewInstance.id` 完全解绑。

1.1.0 先使用默认白板：

```text
whiteboard-default
```

当前产品只保留单一默认白板 `whiteboard-default`；用户已明确不做多白板产品能力。`boards` 容器结构保留为存储实现细节，不新增多白板 UI/生命周期。

同一 Record 在同一个白板默认只允许一个 projection；重复加入应复用/定位已有 item，而不是静默制造重复卡。

## 5. 历史 Association 数据策略

用户已明确确认历史 Association 数据均为测试数据，无迁移价值。

因此 1.1.0：
- 不迁移 `Think/association-spaces.json`；
- 新 `whiteboards.json` 成功初始化后清理旧 association 测试 JSON；
- 从 `data.json` 当前 Settings shape 中清理旧 `AssociationView`；
- 同步清理 Layout 的旧 `viewInstanceIds` / `viewPlacements` 引用；
- 不触碰任何 Markdown Record；
- 普通已注册 View 必须保留。

## 6. 生命周期与数据安全

白板继承 1.0.77 真机故障后建立的数据安全合同：

1. 启动恢复在 Obsidian workspace/layout ready 后开始；
2. Vault cache miss 必须用 adapter 核实，不能把“暂时不可见”当成“文件不存在”；
3. 初始化完成前 Store 不允许 mutation；
4. schema-invalid / read failure 进入 error 并 fail-closed；
5. mutation 使用 draft → schema validate → write success → publish memory；
6. write failure 不允许 UI 假成功；
7. dispose 后 IO 显式失败，不能 silent no-op。

## 7. 普通 View 与白板的架构隔离

最终不允许白板出现在：
- `core/config/views/types.ts` 的普通 View union；
- `core/config/views/registry.ts`；
- `features/views/registry.ts`；
- Settings View editor registry；
- Dashboard `viewPropsFactory`；
- Layout `viewInstanceIds/viewPlacements`。

白板只通过独立 Feature + Obsidian workspace 注册：

```text
Whiteboard Feature
  → registerView(think-os-whiteboard)
  → Ribbon: ThinkOS 白板
  → Command: 打开 ThinkOS 白板
```

## 8. 版本路线

### 1.1.0 — 独立白板工作区（✅ 已实施/真机通过）

唯一目标：**把 Association 从普通 View/Layout 中彻底迁出，建立 ThinkOS 一级“白板”，旧测试壳清理，核心卡片/拖动/连线继续工作。**

做：
- standalone Workspace Leaf；
- Ribbon + Command 一级入口；
- 左右永久分栏；
- 左栏基础关键词 Record Source；
- 右栏现有卡片/XY/Edge；
- `WhiteboardStore` + `Think/whiteboards.json`；
- 退出普通 View registry/editor/Layout；
- 清理旧 AssociationView 测试壳与测试 JSON；
- restart recovery。

不做：Goal/Type/时间完整筛选、左拖右、右拖左、定位卡片、多白板、框选、AI、zoom/pan。

### 1.1.1 — Record Source Retrieval（✅ 已实施/用户通过）

唯一目标：**降低“我记得以前写过，但找不到”的成本。**

左侧加入：
- keyword；
- Record Type；
- Goal；
- date/dateRole/time range。

全部通过现有 `RecordQuery`。右侧白板永远不被左侧筛选隐藏或重排。

### 1.1.2 — 左右直接拖（✅ 已实施/用户真机通过）

唯一目标：**让“找到 → 加入 → 放到哪里”成为一次动作。**

- 左 Record → 右 Board 指定位置；
- 右 Board → 左栏 = 移出白板；
- 原 Record 永远不删除；
- pointer gesture 与内部 card drag 保持清晰状态机。

### 1.1.3 — 白板内定位 + 工作区收纳（✅ 已实施）

唯一目标：**卡多以后快速找到已经放进来的卡，同时让白板工作区可以收纳界面，不破坏空间记忆。**

- 白板右上角“查找白板卡片”；
- Ctrl/⌘+F 聚焦白板查找；
- 命中卡高亮，非命中卡淡化；
- 上一项/下一项循环并 bring into view；
- 查找不隐藏、不重排、不写盘、不改变 XY/Edge；
- 左侧“筛选范围”独立折叠；
- 整个 Record Source 可收起/展开；
- 收起只改变 workspace chrome，不卸载或丢失左侧当前查询状态。

### 1.1.4 — 白板缩放（✅ 代码完成 / 待用户真机验收）

唯一目标：**在不引入完整无限画布引擎的前提下，让大白板可以缩放浏览。**

- 50%～200% 有界缩放；
- `Ctrl/⌘ + wheel` 与 `- / 100% / +`；
- 缩放围绕当前视口/指针，减少跳屏；
- WhiteboardItem 的 x/y 继续是未缩放逻辑坐标；
- 左拖右与卡片内部拖动统一做 screen↔board 坐标换算；
- Edge 与 Card 同处逻辑 Canvas，一起缩放；
- zoom 完全 ephemeral，不写 `whiteboards.json`；
- 已在右侧白板的 Record 从左侧候选结果直接排除；
- 左侧搜索作为主入口，筛选保持次级可折叠区域；右上角白板内查找继续独立存在；
- 不做多白板，不引入 minimap / infinite-canvas engine / spatial index。

### 1.1.5 — 假无限白板 / Pan / World-Camera-Screen（✅ 已实施）

唯一目标：**在不引入第三方无限画布引擎、也不制造超大假 Canvas 的前提下，让白板在视觉和交互上真正呈现“假无限”：四向 Pan、负 world、宽范围连续 Zoom 都可明确感知。**

- 新增可测试的 `world / camera / screen` 纯坐标合同；
- `camera` 表示 viewport 左上角对应的 world 点，可正可负，仅内存；
- Pointer 拖空白处与普通 wheel/trackpad 支持 Pan；
- 新增 camera-aware 自适应世界网格，Pan/Zoom 时网格随 world 原点移动并自动调整密度，不再出现“数学上动了但视觉像没动”的静态空底；
- 1.1.5 将 1.1.4 的 50%～200% 旧缩放扩成 **0.5%～12800% 实用近无限范围**：按钮按倍率缩放，Ctrl/⌘+wheel 连续指数缩放；
- Zoom 与 Pan 组合时保持指针/视口锚点下的 world 点稳定；
- WhiteboardItem x/y 继续是 durable world 坐标，允许负数；
- 卡片拖动继续使用生产 PointerEvent 路径，`screen delta / zoom` 得到 world delta；
- 左侧 Record drop 使用 `screen → world` 统一换算，不再把 x/y 夹到 0；
- Edge/Card 同处 camera-transformed world layer；
- 白板内定位只移动 camera，不改变卡片 x/y；
- 连续 Pan/Zoom 不写 `whiteboards.json`；重启 camera 回默认 0/0，负 x/y 仍恢复。

### 1.1.6 — 左侧 Record 多选 / 全选结果 / 批量拖入（✅ 代码完成 / 待用户真机验收）

唯一目标：**降低从候选区一次挑多条 Record 进入白板的操作成本，同时保持 canonical Record / RecordQuery / world 坐标合同不变。**

- 左侧每条候选加入复选选择；
- 提供“全选结果 / 取消全选 / 清空 / 已选 N”状态；
- “全选结果”针对当前查询的完整 `matchedItems`，不受前 80 条渲染 cap 限制；
- 拖任意已选 Record 时携带整组选中结果；拖未选 Record 时仍保持 1.1.2 单条拖语义；
- 批量 drop 复用 1.1.5 `screen → world` 换算，并从落点向右下网格展开，避免卡片完全重叠；
- `WhiteboardStore.addRecords()` 在单个 mutation / 单次持久化中完成整批新增，并对输入和既有 Projection 去重；
- 已加入白板的 Record 仍立即从左侧候选与选择集合中移除；
- 删除旧“匹配 N 条，显示前 80 条；继续缩小搜索或筛选范围”提示；
- 右上角新增“回到画布中心”：按当前卡片整体包围盒中心移动 ephemeral camera；空白板回 world 原点；不改 zoom、不写卡片 x/y。

明确不做：右侧 Canvas 框选/多选、Workbench 分组、Archive、culling、AI。

### 1.1.7 — Workbench 分组

- 工作台分组；
- 命名；
- 折叠；
- 整组移动。

### 1.1.8 — Canvas 框选 / 多选 / 整组移动

- 右侧白板框选；
- 多选；
- 整组移动；
- 不提前引入第三方 infinite-canvas engine。

### 1.1.9 — Archive / Restore 原位置

- 白板 projection 归档；
- 恢复时保留原 world 位置；
- 不删除 canonical Record。

### 1.1.10 — Viewport culling（仅性能真实需要时）

只有真机出现明显大白板渲染性能问题才实施 viewport culling / spatial 优化，不提前复杂化。

### Later — 主动选择卡片后 AI Chat

只有用户主动选择卡片并点击“和 AI 聊”时构造 context。禁止后台主动推荐、聚类、连线、因果判断。

## 9. 暂不做

- AI 自动推荐/聚类；
- Cluster/Thread 强对象；
- embedding/vector DB；
- complex edge types；
- tldraw / React Flow / Excalidraw；
- 完整 third-party infinite-canvas engine / minimap；
- virtualization/spatial index；
- 自动修改/清理 canonical Record。

## 10. 当前核心产品验收（1.1.6）

- 白板仍是 ThinkOS 一级 Workspace；不回到 Dashboard View/Layout。
- 左侧继续只通过 canonical `RecordQuery` 做关键词 / Type / Goal / 时间筛选；右侧白板不被左侧筛选隐藏或重排。
- 已加入白板的 Record 仍从左侧候选排除。
- 左侧支持逐条多选；“全选结果”覆盖完整 matched results，即使界面只渲染前 80 条。
- 旧匹配数量/80 条提示已删除；选择区只显示与批量操作直接有关的状态。
- 拖已选行 = 整组批量拖；拖未选行 = 单条拖。
- 整批卡片在 drop world 点附近网格展开；负 world / 任意 camera / 任意 zoom 下继续复用 1.1.5 坐标合同。
- 整批新增通过 `WhiteboardStore.addRecords()` 一次写盘；canonical Record / Markdown 不复制、不修改。
- 右上角“回到画布中心”只改变 ephemeral camera；不重置 zoom、不改 durable x/y。
- Card drag / Edge / Find / Pan / Zoom / 右拖左语义保持 1.1.5 兼容。
- F099 已登记 unit/ui/persistence/e2e/regression 证据。
- Syntax / Language / Evidence / Surface / Architecture / Records / UI Runtime 可执行审计全部通过。
- Quality / Stability / Product 仍只有 1.1.5 R2 已存在的 any budget / CI / README release-contract 红项，数值与原因完全一致。
- Jest / 完整 Typecheck / Build / Obsidian E2E 仍需在安装项目依赖的用户环境补跑。
- 下一步：**Hold 1.1.7，先真机验收 1.1.6。**


## Result 1.1.5

实施状态：代码完成 / 待用户真机验收。

- 建立 `screenLocal = (world - camera) * zoom` 与反算合同，新增 `WhiteboardCameraModel`；
- 用 ephemeral camera 替换有限 scroll canvas；支持空白 Pointer Pan、普通 wheel/trackpad Pan 与负 camera；
- Zoom 与 camera 合并为统一 viewport controller，锚点 world 点在缩放前后保持稳定；
- 真机反馈后补齐“无限感”：移除 1.1.4 遗留的 50%～200% 体验限制，改为 0.5%～12800% 宽范围倍率/连续缩放；
- 新增 camera-aware 自适应世界网格与操作提示，Pan/Zoom 时背景明确随 world 移动；
- WhiteboardStore/schema 未改，x/y 原本即允许 finite 负数；Source drop 去掉非负 clamp，负 world 坐标可持久化；
- 生产卡片 PointerEvent 拖动逻辑未重写，只保留既有 `screen delta / zoom` world delta；
- Find 改为移动 camera 居中目标，不再依赖 DOM `scrollIntoView`，不修改 item x/y；
- Edge/Card 同处 world transform，负坐标和 Pan/Zoom 下保持同一几何坐标系；
- 新增 F098 unit/ui/integration/persistence/e2e/regression 证据，并补 world grid / 极小极大 zoom / 连续 wheel zoom 回归；
- 下一步：1.1.6 Hold，先真机验收 1.1.5 修正版的四向 Pan、0.5%～12800% 宽范围 Zoom、负坐标、拖卡/拖入、Edge、定位与重启。


## Result 1.1.6

实施状态：代码完成 / 待用户真机验收。

- 新增 `WhiteboardRecordSelectionModel`：全选、裁剪、toggle、批量拖集合解析；
- 新增 `WhiteboardBatchPlacementModel`：批量 world 网格落点 + 当前画布内容中心；
- 新增 `WhiteboardRecordTransferController`：单条/批量加入 busy 状态、drop world 换算与 Store mutation 接线；
- `WhiteboardStore` 新增 `addRecords()`，整批去重并只持久化一次；
- `WhiteboardRecordSourcePanel` 加逐条复选、全选结果/取消全选/清空/已选数；删除旧匹配数量提示；
- `WhiteboardBoardTools` 加“回到画布中心”；
- 新增独立 `whiteboard-selection.css`，避免把既有 whiteboard.css 推过架构预算；
- 新增 F099 测试与真机 E2E 路径；
- 1.1.7+ 继续 Hold。
