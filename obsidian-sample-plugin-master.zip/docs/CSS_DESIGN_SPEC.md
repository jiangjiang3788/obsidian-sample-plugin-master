# Think OS CSS 与界面元素设计规范

> 版本：1.0.59（Settings IA convergence）  
> 适用范围：Think OS Obsidian 插件所有 Settings、Modal、Layout、View、共享组件  
> 目标：建立统一、克制、高信息密度、主题友好、可访问、可维护的视觉系统  
> 编码：UTF-8

---

## 1. 设计原则

### 1.1 视觉性格

Think OS 的界面应表现为：

- 冷静：不过度使用品牌色和强烈阴影；
- 克制：主操作突出，但普通信息不争夺注意力；
- 高信息密度：在 Obsidian 侧栏和分栏中保持效率；
- 内容优先：减少装饰性 Card；Dashboard 的独立 View 保留清晰边框，数据和记录内容优先；
- 层级明确：通过表面、边框、文字层级和间距建立结构；
- Obsidian-native：颜色、字体、圆角、控件密度优先继承 Obsidian 语义变量与当前社区主题；
- 主题友好：不制造孤立的白色、深色或固定品牌色岛屿；
- 可预测：相同元素在任何 View 中拥有相同尺寸、状态和交互。

### 1.2 禁止原则

禁止：

- 每个 Feature 自己决定按钮高度和圆角；
- 使用十六进制颜色构建普通 UI 皮肤；
- 使用裸 `.active`、`.flex`、`.empty` 等全局 class；
- 用 `!important` 修复普通组件优先级；
- 在 TSX `style` 或 MUI `sx` 中重复整套静态组件皮肤；
- 将图表数据颜色用于按钮、边框和页面表面；
- 为动态坐标生成大量 CSS class；
- 只考虑默认浅色主题；
- 用大面积 accent 填充普通 Module Header；accent 只用于选中、焦点和关键状态。

---


## 1.3 Visual Hierarchy System（1.0.57）

全插件必须遵循统一视觉重量顺序：

```text
独立 View Frame  >  Selected / Active  >  Control Boundary  >  Divider  >  Background
```

这不是“颜色深浅建议”，而是组件职责：

- `--think-border-frame`：只给独立对象边界，例如 Dashboard View；
- `--think-border-selection` + `--think-surface-selection`：表达当前选中，不得比 View Frame 更抢眼；
- `--think-border-control`：Input / Select / Button 等普通控件；
- `--think-border-divider`：最低权重结构线，只在真实结构边界使用；
- `--think-surface-subtle`：Header / Table Header 等轻表面，不用大面积 accent。

文字只使用语义角色：

| 角色 | 用途 | 默认权重 |
|---|---|---|
| Page | Modal/独立页面标题 | semibold |
| View Title | Dashboard Module / Toolbar 主要信息 | semibold |
| Section | 页面一级内容分区 | semibold |
| Subsection | 组标题、Disclosure 标题 | semibold |
| Body | 普通内容 | regular |
| Label | 表单标签、轻强调正文 | medium |
| Meta | 辅助信息 | regular |
| Table Header | 数据表头 | medium |

Feature CSS 不允许通过“再大一级 / 再粗一级”表达业务重要性；需要提升层级时先确认语义角色是否错误。Table Header 永远不能比 View Title 更重。

## 1.4 Rhythm & Boundary System（1.0.58）

空间层级必须使用语义节奏，而不是由 Feature 自己挑 margin：

```text
row < related < group < section < major
```

对应共享 token：

```css
--think-rhythm-row;
--think-rhythm-related;
--think-rhythm-group;
--think-rhythm-section;
--think-rhythm-major;
```

Boundary Ladder：

| 层级 | 表达方式 | 示例 |
|---|---|---|
| Independent Object | `think-object-frame` | Dashboard View、保存的 Layout、独立 Theme 对象 |
| Section | 标题 + whitespace | Settings Section、AI 配置分区 |
| Group | group rhythm / indentation | Goal group、Rule group |
| Row | row rhythm | Field row、Task row、普通列表项 |
| Structural Divider | 低权重结构线 | Header/Body、Footer、Table cell、Axis |

规则：

- 普通 sibling Section/Row 不因为“需要分组感”自动添加横线；先使用 `--think-rhythm-*`。
- Divider 只表示真实结构边界，使用 `--think-structural-divider`，不得替代空间设计。
- 普通页面 Section 不创建 Card；真正可独立移动、选择、保存或管理的对象才使用 `think-object-frame`。
- Object Frame 只有一层边界，默认无阴影，背景使用宿主 canvas/surface 语义。
- Data Grid 是特殊结构：outer frame 表示独立数据区域，cell line 表示二维关系，因此允许内部结构线。
- Feature 只选择语义级别，不自行创建 7px/11px/17px 等“视觉修补间距”。


## 1.5 Settings IA System（1.0.59）

Settings 的导航层级是信息架构，不是表单控件：

```text
Desktop
Primary rail: 数据管理 / 布局 / 通用 / AI
Content top: 记录类型 / 目标 / 主题 / 指标（仅数据管理）
Content: 直接进入当前管理对象
```

规则：

- 桌面一级导航固定在内容左侧；窄 Settings 容器才通过 container query 退化为顶部横向导航。
- 一级/二级 Settings navigation 使用 `SettingsNavigation`，不得用 MUI Tabs 或 `ThinkSegmentedControl` 冒充导航。
- 激活的导航名称不在内容区重复为大标题。
- Data Management 只允许两种主要工作区：Management List 与 Management Matrix。
- List 页顶部只放搜索、数量/状态和主要新增动作；下面直接进入对象列表。
- Matrix 页将创建对象与搜索/视图控制分开，矩阵表面不永久铺满筛选胶囊和维护按钮。
- 特殊记录类型若业务协议不同，仍应进入同一记录类型管理语言；差异只出现在展开后的字段。
- 高频维护动作不得作为永久主操作暴露；迁移/清理类动作不进入日常管理流。

## 2. CSS 架构

### 2.1 Cascade Layer

```css
@layer think.reset,
       think.tokens,
       think.foundations,
       think.primitives,
       think.components,
       think.features,
       think.utilities,
       think.overrides;
```

定义：

| Layer | 职责 | 禁止内容 |
|---|---|---|
| reset | 插件根容器内的最小归一化 | 业务 View 规则 |
| tokens | 所有语义变量 | selector 皮肤 |
| foundations | 字体、focus、motion、基础排版 | 具体业务组件 |
| primitives | Button、Input、Card、Table 等原子元素 | Feature 专属布局 |
| components | Field、Filter、Modal、FloatingPanel 等组合组件 | 数据计算相关样式 |
| features | Progress、Heatmap、Statistics 等差异样式 | 重复 Primitive 皮肤 |
| utilities | 极少量单职责辅助类 | 完整组件外观 |
| overrides | Obsidian/MUI 宿主兼容 | 普通组件日常修补 |

### 2.2 推荐目录

```text
src/styles/
├─ main.css
├─ tokens/
│  ├─ semantic.css
│  ├─ density.css
│  └─ data-colors.css
├─ foundations/
│  ├─ scope.css
│  ├─ typography.css
│  ├─ focus.css
│  └─ motion.css
├─ primitives/
│  ├─ button.css
│  ├─ icon-button.css
│  ├─ input.css
│  ├─ selection-control.css
│  ├─ card.css
│  ├─ chip.css
│  ├─ toolbar.css
│  ├─ table.css
│  └─ empty-state.css
├─ components/
│  ├─ field.css
│  ├─ filter.css
│  ├─ modal.css
│  ├─ grouped-container.css
│  └─ floating-panel.css
├─ features/
│  ├─ layout.css
│  ├─ freeform.css
│  ├─ progress.css
│  ├─ heatmap.css
│  ├─ statistics.css
│  ├─ timeline.css
│  ├─ event-timeline.css
│  ├─ excel.css
│  ├─ block-view.css
│  ├─ settings.css
│  └─ ai-chat.css
├─ utilities/
│  ├─ layout.css
│  └─ accessibility.css
└─ overrides/
   ├─ obsidian.css
   └─ mui.css
```

---

## 2.3 List / Hierarchy ownership

Block、Progress、Energy 等记录列表必须消费共享 `components/task-row.css` 中的 list contract。

共享层负责：

- 普通列表行最小高度与垂直密度；
- divider、hover、selected；
- metadata 字号与节奏；
- hierarchy guide / indent 的基础 token；
- 共享 record metadata pill。

Feature 层只负责自身的数据列、业务缩进语义和特殊可视化。`TaskRow` 这类跨 Table/List 使用的组件必须显式选择 list 模式，不能用全局 skin 误伤其他 View。

补充规则：

- divider 是可选层级信号，不是列表默认装饰；Block 已有 vertical guide 时不再叠加横向 divider。
- 去掉 divider 后必须同步检查 row density；不能用更大的空白替代原来的线。Block 的任务行使用 shared dense row contract。
- `TaskCheckbox` 的 margin / 首行对齐属于共享 TaskRow contract，Feature 不允许各自用 top/translate 修复复选框位置。
- TableView 必须通过显式 matrix-table class 调整密度，不能用 `.think-table` 全局规则误伤 Excel。
- 超宽 Leaf 中，Progress 等可扫描数据列表应使用 `--think-content-width-lg` 约束有效阅读宽度，避免信息列被无意义拉散。
- EventTimeline 的时间轴本身就是边界：事件内容保持 flat，默认结构为 `日期 | 轴 | 时间 | 内容`，不再给每条事件套 Card。
- Energy 任务 cadence 可以保留语义，但普通任务项不再使用 cadence 背景色块；同组任务使用与正文同节奏的文本 `|` separator，不使用整行高的 hairline border。
- Settings 的高级筛选不再折叠；筛选与排序统一使用“已有规则 + 紧凑添加行”的交互模型。
- Quick filter 与 advanced rule 必须在数据层拆分，不能因为共用 `filters[]` 而在两个 UI 区域重复展示同一规则。

## 2.4 Grid / Data ownership

Table、Excel、Heatmap 属于同一个 data-view family，但不要求长成同一种组件。

共享层负责：

- data-view 正文字号、header 高度和 cell padding；
- grid border / row hover / selected state；
- Table / Excel 的普通表头与空状态节奏；
- Heatmap cell 的普通 border、radius、focus 和容器密度 token。

Feature 层负责：

- Table 的行列字段语义；
- Excel 的 sticky、列宽、编辑器、填充柄和风险策略；
- Heatmap 的日历几何、数据颜色、评分/图片内容。

规则：

- Data View 不使用大面积 accent header；header 使用 Obsidian surface，accent 只表达选中/编辑状态。
- 普通 grid toolbar 不再套 Card；一个 View 外框内部只允许 flat toolbar / column toolbar / grid 三层语义。
- Excel 的教学说明不常驻显示；快捷键等信息使用 title/帮助入口，而不是每天占据一整行。
- Excel editable/readonly metadata 可以保留，但不得通过第二层 pill + 高表头制造视觉重量。
- Heatmap 响应式使用 container query，不使用 viewport 宽度推断 Obsidian Leaf 宽度。
- Heatmap 动态十六进制值允许作为记录数据写入 inline background；固定分类/次数颜色必须来自 `tokens/data-colors.css`。

## 2.5 Visualization ownership

Timeline、EventTimeline、Statistics、Energy 属于同一个 visualization family。它们必须消费 `components/visualization.css`，不能各自重新定义普通的轴文字、meta 字号、空状态、guide/track 对比度和 hover/focus 语言。

共享层负责：

- `--think-viz-font-axis / meta / label / value / title` 有界字号；
- `--think-viz-row-height-*` 与 plot height 基础密度；
- guide / track / hover / selection 的普通 UI 对比度；
- `think-viz-surface / axis-label / meta / label / value / empty` 共享表现。

Feature 层只负责：

- Timeline 的时间坐标和 task block 几何；
- EventTimeline 的日期/时间轴列布局；
- Statistics 的 period grid 与柱高；
- Energy 的点大小、位置和 score/capture 数据编码。

规则：

- 可视化字号不得在 Feature CSS 中重新写 `8px / 9px / 10px / 11px / 14px` 等独立 scale；需要更小的轴文字统一使用 visualization token。
- Obsidian Leaf 响应使用 container query，不使用 viewport media query 推断 View 宽度。
- 轴线、baseline、层级引导线属于信息结构；普通记录本体不再额外套 Card 或重复分割线。
- 数据颜色可以动态 inline；固定 UI 颜色、轨道、边界和 hover 必须走 Think token。
- 高频可视化不常驻展示“实心代表什么 / 空心代表什么”这类教学说明；保留 `title / aria-label` 等按需信息。
- Timeline 的普通操作按钮必须使用 Think primitive，不恢复 Unicode 字符按钮。

## 3. Root Scope 与命名

### 3.1 Root Scope

所有插件控制的根容器必须包含：

```html
<div class="think-os think-os--settings">...</div>
<div class="think-os think-os--layout">...</div>
<div class="think-os think-os--modal">...</div>
```

普通规则：

```css
.think-os .think-button { }
.think-os--settings .think-settings-section { }
```

### 3.2 命名规范

```text
组件：     .think-button
元素：     .think-button__icon
变体：     .think-button--primary
尺寸：     .think-button--sm
状态：     .is-selected / .is-disabled
功能根：   .think-progress-view
局部元素： .think-progress-view__metric
Utility：  .think-u-visually-hidden
```

规则：

- 新共享组件只用 `think-*`；
- 现有成熟 Feature 前缀 `sv-* / tn-* / et-* / bv-* / excel-*` 可在迁移期保留；
- 状态 class 不能单独定义皮肤，必须依附组件，例如 `.think-card.is-selected`；
- 禁止使用 DOM 结构过深的 selector；建议最大 3 层；
- 禁止新增 ID selector；
- 避免 tag selector 影响 Obsidian 宿主元素。

---

## 4. Design Token

### 4.1 颜色 Token

Token 不直接定义“紫色按钮”，而表达语义：

```css
.think-os {
  --think-bg-canvas: var(--background-primary);
  --think-bg-surface-1: var(--background-secondary);
  --think-bg-surface-2: var(--background-secondary-alt, var(--background-modifier-hover));
  --think-bg-elevated: var(--background-primary-alt, var(--background-primary));

  --think-text-primary: var(--text-normal);
  --think-text-secondary: var(--text-muted);
  --think-text-subtle: var(--text-faint);
  --think-text-on-accent: var(--text-on-accent);

  --think-border-subtle: var(--background-modifier-border);
  --think-border-strong: var(--background-modifier-border-hover, var(--background-modifier-border));
  --think-border-focus: var(--interactive-accent);

  --think-accent: var(--interactive-accent);
  --think-accent-hover: var(--interactive-accent-hover);
  --think-danger: var(--text-error);
  --think-warning: var(--text-warning);
  --think-success: var(--text-success);
  --think-info: var(--text-accent);
}
```

使用原则：

- 页面表面只用 `bg-*`；
- 文本只用 `text-*`；
- 边界只用 `border-*`；
- 主操作用 accent；
- Danger 仅用于不可逆操作、错误和严重警告；
- UI 不直接消费 `--think-data-*` 数据色。

### 4.2 数据颜色 Token

```css
.think-os {
  --think-data-1: #4f7cff;
  --think-data-2: #20a675;
  --think-data-3: #e39a2d;
  --think-data-4: #d65b74;
  --think-data-5: #8b68d8;
  --think-data-neutral: var(--text-muted);
}
```

要求：

- 浅色和深色分别校准可读性；
- Heatmap 使用同一色相的强度阶梯；
- 分类图表使用可区分色组；
- 状态色与分类色分开；
- 数据颜色必须有非颜色辅助信息，例如标签、图例、纹理或文本。

### 4.3 间距 Token

```css
--think-space-0: 0;
--think-space-1: 2px;
--think-space-2: 4px;
--think-space-3: 6px;
--think-space-4: 8px;
--think-space-5: 12px;
--think-space-6: 16px;
--think-space-7: 24px;
--think-space-8: 32px;
```

推荐优先使用语义 rhythm，而不是直接在 Feature 里选 spacing token：

| 语义 | Token | 典型用途 |
|---|---|---|
| inline | `--think-rhythm-inline` | 图标与文字、紧邻元信息 |
| row | `--think-rhythm-row` | 同一列表/表单中的普通行节奏 |
| related | `--think-rhythm-related` | 同一逻辑组内相关字段 |
| group | `--think-rhythm-group` | sibling group / goal / rule group |
| section | `--think-rhythm-section` | 页面 Section 之间 |
| major | `--think-rhythm-major` | 极少数一级区域之间 |

独立对象内部使用 `--think-object-padding`，独立对象之间使用 `--think-object-gap`。

禁止随意新增 7px、11px、13px、17px 等非标准固定间距，除非是像素对齐需要并有注释。

### 4.4 圆角 Token

```css
--think-radius-xs: 4px;
--think-radius-sm: 6px;
--think-radius-md: 8px;
--think-radius-lg: 12px;
--think-radius-pill: 999px;
```

| 元素 | 圆角 |
|---|---|
| Checkbox、小标签 | 4px |
| Button、Input、Select | 6px |
| Card、Popover | 8px |
| Modal、大型浮层 | 12px |
| Chip/Pill | 999px |

### 4.5 字体 Token

```css
--think-font-xs: 11px;
--think-font-sm: 12px;
--think-font-md: 13px;
--think-font-lg: 14px;
--think-font-xl: 16px;
--think-font-2xl: 18px;
--think-font-3xl: 22px;
--think-font-4xl: 28px;
```

| 用途 | 字号 | 字重 | 行高 |
|---|---:|---:|---:|
| 辅助说明/Badge | 11–12px | 400–500 | 1.3 |
| 默认 UI 文本 | 13px | 400 | 1.45 |
| Button/Input | 13px | 500 | 1.2 |
| 卡片标题 | 14px | 600 | 1.3 |
| Section 标题 | 16px | 600 | 1.3 |
| 页面标题 | 18–22px | 600–700 | 1.25 |
| 大指标 | 22–28px | 600–700 | 1.1 |

数字指标建议使用 `font-variant-numeric: tabular-nums`。

### 4.6 控件高度

```css
--think-control-sm: 28px;
--think-control-md: 32px;
--think-control-lg: 36px;
--think-control-touch: 40px;
```

- 桌面默认：32px；
- 紧凑 Toolbar：28px；
- 主要 Modal 操作：32–36px；
- 触控降级：至少 40px；
- 同一行控件必须对齐到同一高度。

### 4.7 表面与阴影

Think OS 使用全局 flat contract：**不使用投影表达层级**。层级只由 border、surface background、spacing 与 Overlay stack 表达。

```css
--think-shadow-sm: none;
--think-shadow-md: none;
--think-shadow-overlay: none;
```

- 普通卡片、按钮、Goal 行、Popover、Dropdown、Modal、FloatingPanel 均不得引入 box-shadow；
- 宿主主题自带阴影进入 Think OS root 时由 scope 统一压平；
- Overlay 的“在最上层”是交互层级，不是视觉投影。

### 4.8 z-index Token

```css
--think-z-base: 0;
--think-z-sticky: 20;
--think-z-dropdown: 100;
--think-z-popover: 200;
--think-z-modal: 400;
--think-z-toast: 500;
--think-z-drag: 600;
```

禁止随意使用 999、9999、99999。

### 4.9 Motion Token

```css
--think-duration-fast: 100ms;
--think-duration-normal: 160ms;
--think-duration-slow: 240ms;
--think-ease-standard: cubic-bezier(.2, 0, 0, 1);
```

仅动画：颜色、透明度、轻微 transform、展开高度。拖动期间不使用慢 transition。

---

## 4.10 Dashboard Module Frame

Dashboard 中一个 Module 代表一个独立 View，因此必须保留完整边界。它不是 SaaS Card，而是 Obsidian workspace panel：

- 外框：1px `--think-panel-border`；
- 圆角：`--think-radius-md`，由 Obsidian `--radius-m` 映射；
- Header：使用 Obsidian secondary/hover surface，不使用常驻 accent 填充；
- Header 与 Content：仅一条 subtle divider；
- Content：与页面主 surface 同背景；
- Selected：只改变边框/状态，不整条染色；
- 默认无 shadow；
- Module Shell 的基础皮肤只能由 `view-shell.modules.css` 定义，normalization 文件不得再次覆盖同一组基础 selector。

## 4.11 Settings 高频工作区

Settings 是日常工作区，不是说明文档：

- 普通 Section 默认 flat，不使用 border + background + radius 三件套；
- Section 之间优先使用标题、12–16px 间距和 1px subtle divider；
- 列表行使用 hairline 分隔，不把每一行做成 Card；
- 只有独立交互区域、危险区域、预览器、复杂 Rule Builder 等真实边界才允许使用容器框；
- 明显的教学型说明默认不常驻显示；
- Helper text 只用于输入约束、保存副作用、不可逆行为、错误/警告和真正不直观的业务语义；
- 可选解释优先进入 tooltip、help icon 或按需展开区域；
- 成功状态应短暂、低噪声，不用长期占位的大型 Alert。

## 5. 元素设计规范

## 5.1 Button

### 尺寸

| 尺寸 | 高度 | 水平 padding | 字号 | 图标 |
|---|---:|---:|---:|---:|
| sm | 28px | 8px | 12px | 14px |
| md | 32px | 12px | 13px | 16px |
| lg | 36px | 14px | 14px | 18px |

### 变体

- Primary：每个区域只保留一个主要动作；accent 背景；
- Secondary：普通边框和 Surface 背景；
- Ghost：无边框或透明背景，用于 Toolbar；
- Danger：仅删除、重置、不可逆操作；
- Link：用于低强度导航，不用于提交动作。

### 状态

```text
default → hover → active → focus-visible → disabled → loading
```

要求：

- Focus 不得仅靠颜色变化；
- Loading 保留按钮宽度；
- Disabled 不允许 hover；
- 图标按钮必须有 `aria-label` 或可见文本；
- Danger 默认不应大面积高饱和，仅 hover/确认时增强。

## 5.2 IconButton

- 默认 32×32px；紧凑 28×28px；触控 40×40px；
- 图标居中，不用文字行高撑尺寸；
- Toolbar 中使用 ghost；卡片危险操作使用 danger ghost；
- 必须有 Tooltip；
- 删除、置顶、锁定等图标状态需要 `aria-pressed` 或明确标签。

## 5.3 Input / Select / Textarea

### 外观

- 默认高度 32px；
- 背景 `surface-0/1`；
- 1px subtle border；
- 6px radius；
- 左右 padding 8–10px；
- Placeholder 使用 subtle text；
- Focus 使用 accent border + focus ring；
- Error 使用 danger border，并在下方显示文本，不只用红色。

### Textarea

- 最小高度 80px；
- 默认可垂直 resize；
- 长文本编辑器可使用 120–200px；
- 禁止固定高度导致内容不可见。

### Select

- 箭头区域不可与文本重叠；
- 多选用 Chip 展示；
- 无结果、加载、错误必须有明确状态。

## 5.4 Checkbox / Radio / Switch

- 视觉尺寸 16–18px；可点击区域至少 28px；
- Label 与控件间距 8px；
- checked/indeterminate/focus-visible 明确；
- Switch 仅用于即时生效的二元状态；
- 需要“保存后生效”的选项使用 Checkbox，不误导为即时切换。

## 5.5 Field

统一结构：

```html
<div class="think-field">
  <label class="think-field__label">名称</label>
  <div class="think-field__control">...</div>
  <p class="think-field__description">说明</p>
  <p class="think-field__error">错误</p>
</div>
```

- Label 13px/500；
- Description 12px secondary；
- Error 12px danger；
- 字段间距 16px；
- 同一行字段在 XS 容器自动变单列；
- 必填标识不可只用红色星号，应有可访问文本。

## 5.6 Card / Surface

### Independent Object / Card

- 普通内容 Section 不默认使用 Card；
- 只有真正独立的对象才使用共享 `think-object-frame`；
- Frame 为单层 1px 边界，默认无阴影；
- radius / background 走 Object semantic token；
- 内边距使用 `--think-object-padding`；
- 对象之间使用 `--think-object-gap`。

### 状态

- Hover：仅可点击卡片启用，轻微背景或边框变化；
- Selected：accent border + 弱 accent 背景；
- Locked：降低操作强调，但内容保持可读；
- Dragging：提升 z-index、轻阴影、透明度 0.94；
- Resizing：显示尺寸提示和边界；
- Collapsed：仅显示 Header，不改变原持久化尺寸。

### 禁止

- 每层嵌套都使用边框卡片；
- Card 内再套多个同等视觉权重 Card；
- 普通卡片使用 Modal 级阴影。

## 5.7 Chip / Tag / Badge

| 类型 | 用途 | 高度 |
|---|---|---:|
| Chip | 可交互筛选、可删除标签 | 24–28px |
| Tag | 静态分类标签 | 22–24px |
| Badge | 数量、状态、小提示 | 18–22px |

- Pill radius；
- 文字 11–12px；
- 删除按钮必须可聚焦；
- Selected Chip 使用弱 accent 背景和清晰边框；
- 大量标签需要折叠、换行或横向滚动策略。

## 5.8 Toolbar

- 默认高度 36–40px；
- 控件间 gap 6–8px；
- 使用 `display:flex; align-items:center`；
- 主操作靠右或固定位置，不能随着标签折叠消失；
- SM 容器允许换行；XS 容器将低优先级动作收进 More 菜单；
- Toolbar 不承担 Section 标题的视觉职责，除非是 View Header。

## 5.9 Tabs

- Tab 高度 32–36px；
- 当前项使用底边/背景之一，不同时使用多个高强度状态；
- 支持键盘左右导航；
- 窄容器横向滚动，不压缩到不可读；
- Badge 不改变 tab 高度。

## 5.10 Menu / Dropdown / Popover

- Surface 2；8px radius；无 shadow，以边框与 surface 差异表达层级；
- 最小宽度 160px；最大宽度根据内容 320–420px；
- Item 高度 32px，触控 40px；
- 选中、危险、禁用状态明确；
- 不使用 hover 才能访问的唯一操作；
- 超出视口自动翻转和限高滚动。

## 5.11 Modal

统一结构：

```text
Modal
├─ Header：标题 + 关闭
├─ Body：唯一滚动区域
└─ Footer：次操作 + 主操作
```

规范：

- Obsidian Modal host 是唯一外层 surface；普通内容不得再套第二层 Paper/Card；
- radius / border 优先继承 Obsidian host bridge；shadow 始终禁用；
- 最大高度约 `min(85vh, available)`；
- Header/Footer 固定，Body 滚动；
- 宽度分 sm 420px、md 640px、lg 860px；
- XS 视口接近全屏并保留安全区；
- `ModalHeader` 统一标题、右侧动作与关闭按钮；自定义右侧动作不得替代关闭入口；
- Body 默认只拥有一次 section padding；Feature 不再用 Box/Paper 为普通表单重复制造内层边界；
- Footer 使用共享 `think-overlay-footer`，次操作在前、主操作在后；
- 高频 Quick Input / AI / 管理浮层不常驻展示显而易见的快捷键或功能说明；
- Assistant message 默认按内容流展示，不为每条消息创建 Card；仅用户/错误/系统状态使用克制的语义差异；
- FloatingPanel 与 Modal 共用 header action / close icon / focus language；
- Esc 关闭需要遵循未保存确认；
- 初始焦点、焦点陷阱和关闭后焦点恢复完整；
- 宿主兼容 `!important` 只能写在 `overrides/obsidian.css`。

## 5.12 Table / Excel Grid

### 基础

- Header 高度 32–36px；
- Row 紧凑 30px、默认 34px、舒适 40px；
- Cell 水平 padding 8–10px；
- Header 使用 secondary text + 500/600 weight；
- 数值右对齐，文本左对齐；
- 允许横向滚动，不强行压缩关键列。

### 状态

- Hover：弱背景；
- Selected：accent 弱背景 + 左/边界提示；
- Editing：清晰 focus ring；
- Error：边框 + 图标/文本；
- Frozen/Sticky：有分隔阴影或边框；
- Empty：显示统一 EmptyState，而不是只留空白。

## 5.13 List / Tree

- Item 最小高度 30–32px；
- 层级缩进每级 16px；
- 展开按钮与 item 点击区域分离；
- 当前项、选中项、hover 不混淆；
- Drag target 有上/下插入线；
- 长文本截断并提供 Tooltip；
- Theme Tree 等大型树支持虚拟化时，不改变视觉合同。

## 5.14 Section

```text
Section Header
├─ Title
├─ Description
└─ Optional Actions
Section Body
```

- 页面 Section 间距使用 `--think-rhythm-section`；
- 标题 16px/600；
- Description 12–13px secondary；
- Actions 不挤压标题；窄容器移到下一行；
- Section 不默认加卡片边框；视觉分组优先依靠 section rhythm。只有语义上独立的对象才升级为 `think-object-frame`。

## 5.15 Empty / Loading / Error State

### Empty

- 图标 24–32px；
- 标题 14px/600；
- 说明最大宽度约 360px；
- 最多一个主要动作和一个次动作。

### Loading

- 小区域使用 Spinner/Skeleton；
- 大面积数据使用结构化 Skeleton，避免页面跳动；
- 超过合理时间显示说明；
- Loading 不应清空已有内容，刷新时可保留旧数据。

### Error

- 错误文本说明发生了什么和可执行动作；
- 不只显示红色边框；
- 可恢复错误提供重试；
- 技术详情默认折叠。

## 5.16 Tooltip

- 仅补充说明，不承载完成任务必需的信息；
- 延迟 400–600ms，图标按钮可更短；
- 最大宽度 280px；
- 支持键盘 focus；
- 不在触控设备依赖 Tooltip。

## 5.17 Progress

- 轨道高度 6–8px；
- 小型指标 4px；
- 百分比通过 CSS 变量；
- 不使用颜色作为唯一完成状态；
- 100% 状态可以使用 success，但仍显示数字/文本；
- 多系列进度需要图例或标签，避免仅靠相似色。

## 5.18 View Shell / ModulePanel

统一结构：

```text
View Shell
├─ Header：标题、状态、操作
├─ Toolbar/Filter（可选）
├─ Content
└─ Footer/Pagination（可选）
```

- Header 高度 36–40px；
- 普通模式弱化边框；
- List/Grid/Freeform 共用相同 View Shell；
- Freeform 仅额外显示拖动手柄、resize handle、selected/locked 边界；
- 内部 View 不知道自己处于自由布局，不写 drag/resize CSS。

## 5.19 Freeform Widget

- 编辑模式才显示手柄和 resize 边界；
- 非编辑模式外观应接近普通 Card；
- Dragging 使用 `--think-z-drag`；
- Locked 显示锁定图标与弱状态，不降低正文可读性；
- Resize handle 至少 16×16px 可交互区域；
- 键盘 focus 与 selected 状态可区分；
- 小屏/触控降级为普通列表，不强制自由拖动。

## 5.20 Data Visualization

- UI 表面与数据色分离；
- 图表网格线使用 subtle border；
- 轴、标签使用 secondary text；
- Hover tooltip 使用 Surface 2；
- 数据色在浅/深主题均验证；
- 颜色序列应避免相邻低对比；
- Heatmap 至少提供 5 级强度；
- 重要阈值同时使用线型、图标或文本；
- 图表空状态不能显示一张空坐标系。

---

## 6. 响应式规范

### 6.1 容器档位

| 档位 | 宽度 | 默认行为 |
|---|---:|---|
| XS | `<360px` | 单列；主操作保留；文本截断；复杂图表简化 |
| SM | `360–560px` | 紧凑布局；Toolbar 可换行；表单单列优先 |
| MD | `560–840px` | 常规布局；允许双列表单和中等信息密度 |
| LG | `>840px` | 多列、完整标签、并列图表 |

### 6.2 使用顺序

1. Feature 根使用 Container Query；
2. App Shell、Modal 安全区使用 viewport media query；
3. 数据密度降级由组件逻辑或 class 控制；
4. 明确允许滚动的区域包括 Excel、Table 和 Freeform Canvas；其他区域不应无意横向溢出。

---

## 7. 状态设计合同

所有交互元素至少覆盖：

```text
default
hover
active
focus-visible
disabled
```

适用组件增加：

```text
selected
checked
error
warning
success
loading
readonly
dragging
resizing
locked
collapsed
```

状态优先级：

```text
disabled > error > dragging/resizing > selected/checked > focus > hover > default
```

Focus 必须始终可见，不能因为 selected 或 error 被覆盖。

---

## 8. 静态与动态样式边界

### 8.1 必须进入 CSS

- 固定 display、position 关系；
- padding、gap、radius；
- 字体、行高、文字颜色；
- hover/focus/active/disabled；
- 固定背景、边框、阴影；
- 响应式规则；
- 动画定义；
- 组件尺寸变体。

### 8.2 允许留在 TSX

- Freeform x/y/width/height；
- Timeline top/height；
- Progress 百分比；
- Heatmap 数据颜色强度；
- 动态 Grid 行列；
- 运行时测量结果；
- 真正由 props 计算的一次性数值。

### 8.3 推荐 CSS 变量桥接

```tsx
<div
  className="think-progress"
  style={{ '--think-progress-value': `${percent}%` }}
/>
```

```css
.think-progress::after {
  width: var(--think-progress-value);
}
```

TSX 中不得重复写进度条背景、圆角、高度和 transition。

---

## 9. MUI 使用规范

### 9.1 保留 MUI，但必须通过 Bridge

MUI Theme 必须消费 Think Token，统一：

- palette；
- typography；
- spacing；
- shape；
- Button、IconButton、TextField、Select、Chip、Dialog、Paper、Tabs；
- focus-visible；
- hover/selected/disabled/error。

### 9.2 `sx` 允许范围

允许：

- 动态 Grid 列宽；
- 由 props 决定的有限布局；
- 运行时值；
- 一次性排列关系。

禁止：

```tsx
sx={{
  color: '#...',
  background: '#...',
  borderRadius: 12,
  fontSize: 13,
  boxShadow: '...'
}}
```

作为完整皮肤。

同一类 `sx` 出现两次以上，应抽为 Theme override、Primitive 或共享组件。

---

## 10. 可访问性

- 正文和背景对比符合 WCAG AA；
- 非文本图形和 focus 指示器具有足够对比；
- 所有鼠标操作均有键盘路径；
- Hover 不能是唯一信息入口；
- 颜色不能是唯一状态表达；
- Touch target 推荐 40px，最低不小于 32px；
- 支持 `prefers-reduced-motion`；
- 支持 `forced-colors: active`；
- 图标按钮有可访问名称；
- Modal 有焦点陷阱和关闭后焦点恢复；
- 表格 Header、排序、选中和错误状态对辅助技术可读。

---

## 11. Do / Don't

### Do

```css
.think-os .think-button--primary {
  min-height: var(--think-control-md);
  padding-inline: var(--think-space-5);
  color: var(--think-text-on-accent);
  background: var(--think-accent);
  border-radius: var(--think-radius-sm);
}
```

### Don't

```css
.submit-btn {
  height: 31px;
  padding: 0 13px;
  color: white;
  background: #7c3aed !important;
  border-radius: 10px;
}
```

### Do：动态值

```tsx
<div className="think-heatmap-cell" style={{ '--think-level': level }} />
```

### Don't：静态皮肤内联

```tsx
<div style={{ padding: 12, borderRadius: 8, background: '#fff', color: '#222' }} />
```

---

## 12. 新增组件检查清单

开发新组件前必须回答：

- 是否已有 Primitive 或 Component 可以复用？
- 使用的是语义 Token 还是硬编码值？
- 是否在 `.think-os` Scope 内？
- class 是否有 `think-*` 或明确 Feature Prefix？
- default/hover/active/focus/disabled 是否齐全？
- error/loading/empty 是否需要？
- 浅色、深色和第三方主题是否可读？
- 360px 容器是否可用？
- 是否存在可留在 CSS 的静态 `style/sx`？
- 动态值是否可通过 CSS 变量传递？
- 是否新增了 `!important`？如是，是否属于宿主 override 白名单？
- 是否有截图或 Style Catalog 示例？

---

## 13. 完成标准

该规范真正落地后，应满足：

1. 同一个 Button、Input、Card 在 Settings、Modal、View 和 Freeform 中视觉一致；
2. MUI 和普通 CSS 组件在深浅主题下共享语义；
3. Feature CSS 只描述该 Feature 的结构差异，不重复共享元素皮肤；
4. 动态布局仍保持性能，不因 CSS 统一而生成大量 class；
5. 新增组件可以通过 Token 和 Primitive 快速构建，不再复制 `sx/style`；
6. CSS Gate 能阻止旧问题重新进入代码库。

## 2.5 Record Type semantic color contract（1.4.0）

Record Type color is product identity, not View decoration. The 11 canonical types use global `--think-record-type-*` tokens from `tokens/data-colors.css`; feature CSS must consume `--think-record-type-accent` through `data-record-type`, and must not maintain a second type-to-color table.

Rules:

- Record Type and Category colors are separate semantic systems.
- Same Record Type must resolve to the same token in Whiteboard, type filters, type switchers, settings matrices and any future type legend.
- Color never replaces essential text in contexts where the type name itself must be understood; use a marker/rail/header accent plus accessible text/title.
- Whiteboard cards use a 6px start-side Record Type rail. The card header is reserved for Goal (left) and time (right); the body identity uses `primaryText`.
- Low-frequency Whiteboard actions such as Archive/Move are progressively disclosed through context/drag interactions rather than permanently consuming card space.
- Whiteboard grid is optional visual assistance. Hiding it removes the background rendering only; it does not disable spatial coordinates or layout capabilities.
