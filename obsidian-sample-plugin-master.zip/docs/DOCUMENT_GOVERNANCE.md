# 文档治理

当前源码包只保留“现在仍然有效”的操作性文档，不把历史开发过程当成长期产品接口。

## 保留

- 当前架构；
- 当前 Record / Field / Template 语义；
- 当前测试、CI、发布方式；
- 当前 CSS 设计约束；
- 防止架构再次发散的开发规则；
- 本文档治理规则。

## 归档而不是长期随源码携带

- 历史 Energy 版本说明；
- `SOURCE_VALIDATION_*`；
- MVP24～MVP32 过程记录与 Git 提交备注；
- 旧架构重构阶段报告；
- 旧 Demo 数据集；
- 已完成的迁移计划与封版过程文档。

## 原则

文档要描述当前事实，而不是保护过去的文件名。Gate 可以检查当前文档入口和发布命令，但不应要求历史 MVP 文档永久存在。

历史资料需要追溯时从独立 archive 获取，不重新塞回活动源码树。

## Source-package placement rule

If implementation reports are shipped with the source package, they must live under `docs/reports/`. Do not place phase reports loose in the project root. The root keeps only the main `README.md`.
