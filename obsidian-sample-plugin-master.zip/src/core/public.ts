// src/core/public.ts
/**
 * Core Public API (Phase 4.4)
 * ===============================================================
 *
 * ✅ 这是 core 层对外的【唯一门面】。
 * app / features / shared 访问 core，只能 import 这个文件。
 *
 * 你要的“结构性不可绕过事实”靠三件事一起成立：
 * 1) arch-gate（CI 硬闸）解析 import 落点：越界直接 fail
 * 2) eslint（开发期软闸）快速提示：减少无意越界
 * 3) public 门面（代码形状）收敛出口：实现默认不可见
 *
 * 约束（防止 core/public.ts 变垃圾桶）：
 * - ✅ 允许 export：领域 types、纯 utils、稳定 config、必要的 DI tokens/服务类（用于组合根/UseCase）
 * - ❌ 禁止 export：临时性的 UI helper、feature 业务规则、一次性脚本、内部实现细节（优先留在内部文件）
 * - ❌ 禁止把 “export-star from 某个深层实现文件” 当捷径（除非它本身就是模块级 public barrel）
 *
 * 命名约定：
 */

//
// -------------------- Domain Types (唯一真源) --------------------
//
export * from './types';
export type {
    GoalStatus,
    CycleGranularity,
    GoalMetricDirection,
    GoalMetricContract,
    GoalDefinition,
      GoalTemplateStorageRow,
    GoalSettings,
} from './goal';
export { DEFAULT_GOAL_SETTINGS, assertCanonicalGoalSettings, normalizeGoalPath, requireGoalPath, splitGoalPath, getParentGoalPath, getGoalLeaf, isGoalPathDescendant, getGoalOrderPath, getGoalOrderLabel, createGoalOrderIndex, sortGoalsBySettingsOrder, compareGoalPathsBySettingsOrder, sortGoalPathsBySettingsOrder, sortGoalTemplatesBySettingsOrder, resolveDerivedPeriod, normalizePeriodGranularity, isPeriodAwareRecordType, normalizePeriodPolicyGranularity, resolveTemplatePeriodPolicy, SYSTEM_RECORD_CONTEXT_FIELD_KEYS, isSystemRecordContextField, getGoalTemplates, getGoalTemplateId, getGoalTemplateCandidateGoalPaths, findGoalTemplate, findDirectGoalTemplate, normalizeGoalTemplateStorageRow, toGoalTemplateStorageRow, upsertGoalTemplateInSettings, removeGoalTemplateFromSettings, removeGoalTemplatesForGoal, cleanupGoalTemplateStorage, getGoalTemplateDisplayInfo, getGoalTemplateDisplayName, isGeneratedGoalTemplateName, readGoalTemplateIcon, goalTemplateHasCustomOverrides, inferGoalTemplateEditMode, compactGoalTemplateForStorage, describeGoalTemplateStorageDiff, UNASSIGNED_GOAL_KEY, getItemGoalKey, getItemGoalLabel, buildGoalBuckets } from './goal';
export type { GoalPathParts, GoalOrderIndex, DerivedPeriod, GoalTemplate, PeriodGranularity, PeriodPolicy, GoalBucket, CompactGoalTemplateOptions, GoalTemplateDisplayInfo, GoalTemplateEditMode } from './goal';

//
// -------------------- Utils（可复用纯能力） --------------------
//
export * from './utils/public';
export {
    DEFAULT_FREEFORM_LAYOUT_CONFIG,
    FREEFORM_COLLAPSED_HEIGHT,
    bringViewPlacementToFront,
    bringViewPlacementsToFront,
    calculateFreeformCanvasHeight,
    createDefaultViewPlacement,
    createDefaultViewPlacements,
    getDefaultFreeformItemSize,
    filterViewPlacementsForLayout,
    getFreeformVisualHeight,
    moveViewPlacement,
    normalizeFreeformLayoutConfig,
    normalizeViewPlacementZIndices,
    normalizeViewPlacement,
    removeViewPlacement,
    resizeViewPlacement,
    resolveViewPlacements,
    snapFreeformValue,
} from './layout/public';
export type { FreeformItemSize } from './layout/public';
export { buildRecordSubmitFeedbackPresentation } from './recordInput/feedback';
export {
    buildRecordSubmitRecoveryPresentation,
    getRecordRecoveryPaths,
} from './recordInput/recovery';
export type {
    BuildRecordSubmitRecoveryPresentationOptions,
    RecordSubmitRecoveryPresentation,
} from './recordInput/recovery';
export {
    addDisplayField,
    moveDisplayField,
    normalizeDisplayFields,
    removeDisplayField,
    replaceDisplayField,
} from './view-config/displayFields';
export type { NormalizeDisplayFieldsOptions } from './view-config/displayFields';
export {
    VIEW_PRIMARY_FIELD_KEYS,
    VIEW_NOISY_DISPLAY_FIELDS,
    isNoisyViewDisplayField,
    isPeriodViewField,
    normalizeViewFieldKey,
    normalizeViewFilters,
    normalizeViewGroupFields,
    normalizeViewConfigDomain,
    normalizeViewInstanceDomain,
    normalizeViewSort,
} from './view-config/domainFields';
export {
    FIELD_CATEGORY_LABELS,
    FIELD_REGISTRY,
    getAvailableFields,
    getAvailableFieldsByCategory,
    getCanonicalFieldKey,
    getBuiltInFieldGuideGroups,
    getCoreInputFieldPresets,
    getCoreInputFieldTarget,
    getCustomFieldNameWarning,
    getFieldCategory,
    getFieldCategoryLabel,
    getFieldDefinition,
    getFieldLabel,
    getFieldPickerOptions,
    getReservedCustomFieldNames,
    isCoreInputFieldName,
    isReservedCustomFieldName,
    makeSafeCustomFieldName,
    getFieldOptionLabel,
    FIELD_BEHAVIORS,
    getTemplateFieldBehavior,
    getTemplateFieldBehaviorKind,
    matchTemplateFieldOptionValue,
    normalizeBackfilledTemplateFieldValue,
    normalizeFieldValueByBehavior,
    templateFieldValueToArray,
    templateFieldValueToString,
    getTemplateFieldInputType,
    getTemplateFieldSemantic,
    isImageFieldDefinition,
    isTemplateImageField,
    isImageLikeValue,
    isTemplateMultiValueField,
    isTemplatePathField,
    isTemplateTagField,
    normalizeFieldKey,
    normalizeImageValue,
    normalizeTemplateFieldValue,
    normalizeTemplateRenderData,
    createCustomTemplateField,
    getUserTemplateFieldTypeOptions,
    isMultiValueTemplateFieldType,
    normalizeTemplateFieldType,
    sanitizeTemplateField,
    sanitizeTemplateFields,
    templateFieldTypeSupportsDefaultValue,
    templateFieldTypeUsesOptions,
    parseTagList,
    readFieldValue,
    resolveFieldValue,
    splitHierarchyPath,
    canInlineEditField,
    getFieldEditPolicy,
    getFieldEditorKind,
    normalizeEditableFieldKey,
    CONTENT_FIELD_KEY,
    FULL_DATA_FIELD_KEY,
} from './fields/public';
export type {
    BuiltInFieldGuideGroup,
    BuiltInFieldGuideItem,
    CoreInputFieldPreset,
    FieldCategory,
    FieldDefinition,
    FieldInputType,
    FieldPickerOption,
    FieldSemantic,
    FieldValueResolution,
    FieldValueSource,
    ImageFieldValue,
    FieldCommitMode,
    FieldEditDangerLevel,
    FieldEditPolicy,
    FieldEditValueSource,
    FieldEditorKind,
} from './fields/public';

//
// -------------------- AI Module（模块级 public） --------------------
// 注意：AI 子模块本身已经有 index.ts 作为 public barrel
//
export * from './ai/public';

// -------------------- Records（记录标准化/Codec） --------------------
export { normalizeRecordItem, normalizeRecordItems } from './records/public';
export type {
    RecordEntity,
    RecordFileContext,
    RecordLocationContext,
    RecordNormalizeContext,
} from './records/public';

// -------------------- Progression（目标/成长反馈纯计算） --------------------
export { computeProgression } from './progression/computeProgression';
export type { ProgressComputationOptions } from './progression/computeProgression';
export type { ProgressBreakdownRow, ProgressResult } from './progression/types';

// -------------------- Record Types（唯一记录类型注册中心） --------------------
export {
    DEFAULT_RECORD_TYPES,
    DEFAULT_TEMPLATE_RECORD_TYPES,
    ENERGY_RECORD_TYPE,
    ENERGY_RECORD_TYPE_ID,
    buildRecordTypeInputSettings,
    getEffectiveRecordTypes,
    getRecordTypeById,
    getTemplateRecordTypeById,
    getTemplateRecordTypes,
    isDirectRecordType,
} from './recordTypes/public';
export type { RecordTypeDefinition, TemplateRecordTypeDefinition } from './recordTypes/public';

// -------------------- Core Services（DI 需要的 token / class） --------------------
// 说明：这些 export 是为了组合根（main/app）和 usecases 能 resolve。
//
export { DataStore } from './services/DataStore';
export { InputService } from './services/InputService';
export { ItemService } from './services/public';
export { ActionService } from './services/ActionService';
export { TimerStateService } from './services/TimerStateService';

export { VaultFileStorage, STORAGE_TOKEN } from './services/StorageService';
export type { IPluginStorage } from './services/StorageService';


// -------------------- Record Input internals promoted for app usecase boundary --------------------
// 说明：app/usecases/recordInput.usecase.ts 只能通过 core/public.ts 访问 core。
// 这里导出的是 usecase 编排所需的稳定核心构件，不允许 features/shared 直接依赖内部路径。
export { GoalTemplateResolver, getCreateEligibleGoalPaths } from './services/GoalTemplateResolver';
export type { GoalTemplateResolveInput, GoalTemplateResolveResult, GoalTemplateSourceType } from './services/GoalTemplateResolver';
export { RecordInputKernel } from './recordInput/RecordInputKernel';
export {
    assertRecordInputRequiredFields,
    buildBatchCreateRecordSubmitResult,
    buildCreateRecordSubmitParamsFromEditorState,
    buildRecordCreateDraftFromEditorState,
    buildRecordDraftContext,
    buildUpdateRecordSubmitParamsFromEditorState,
    findMissingRecordInputRequiredFields,
    hasRecordInputRequiredValue,
    normalizeRecordInputFieldValueForTemplate,
    normalizeRecordInputFormDataForTemplate,
} from './recordInput/RecordInputFacade';
export type {
    BuildCreateRecordSubmitParamsInput,
    BuildRecordCreateDraftParams,
    BuildUpdateRecordSubmitParamsInput,
    RecordInputEditorStateLike,
} from './recordInput/RecordInputFacade';
export { buildRecordOutputPlan, buildRecordPersistencePlan } from './recordInput/snapshot/OutputPlanner';
export {
    buildCancelledResult,
    buildConflictResult,
    buildErrorResult,
    buildSuccessResult,
    buildValidationErrorResult,
} from './recordInput/submitResult';
export { applyRecordRefreshPlan, finalizeRecordSubmitResult } from './recordInput/refreshCoordinator';
export { isRecordConflictError } from './recordInput/mutationErrors';
export { createRecordInputDraftSnapshot, initializeRecordInputSession } from './recordInput/session/initialize';
export { getRecordInputSessionDraft, reduceRecordInputSession } from './recordInput/session/reducer';
export {
    RECORD_INPUT_BLOCK_SWITCH_PRESERVE_KEYS,
    RECORD_INPUT_GOAL_CONTEXT_KEYS,
    clearRecordInputGoalContext,
    isRecordInputMeaningfulValue,
    isRecordInputOptionLike,
    isRecordInputRefreshableSource,
    isRecordInputSameValue,
    preserveRecordInputBlockSwitchState,
    readRecordInputString,
} from './recordInput/session/policy';
export type {
    InitializeRecordInputSessionInput,
    RecordInputDraftSnapshot,
    RecordInputFieldSource,
    RecordInputFieldSourceMap,
    RecordInputFormData,
    RecordInputSessionAction,
    RecordInputSessionMode,
    RecordInputSessionSelection,
    RecordInputSessionState,
    RecordInputTimeDirection,
} from './recordInput/session/types';

// -------------------- Core Ports（Phase2: platform 边界） --------------------
// 说明：core 层只定义接口（Port）；平台层实现并在组合根注册。
export { VAULT_PORT_TOKEN } from './ports/VaultPort';
export type { VaultPort } from './ports/VaultPort';

export { UI_PORT_TOKEN } from './ports/UiPort';
export type { UiPort, UiNoticeHandle } from './ports/UiPort';

export { METADATA_PORT_TOKEN } from './ports/MetadataPort';
export type { MetadataPort, HeadingInfo } from './ports/MetadataPort';

export { FILESTAT_PORT_TOKEN } from './ports/FileStatPort';
export type { FileStatPort, FileStat } from './ports/FileStatPort';

export { EVENTS_PORT_TOKEN } from './ports/EventsPort';
export type { EventsPort, UnsubscribeFn } from './ports/EventsPort';

export { MODAL_PORT_TOKEN } from './ports/ModalPort';
export { MESSAGE_RENDER_PORT_TOKEN } from './ports/MessageRenderPort';
export type { MessageRenderPort, RenderMessageArgs, MessageContentType } from './ports/MessageRenderPort';
export type { ModalPort, NamePromptOptions, CheckinManagerOpenArgs } from './ports/ModalPort';


export { SettingsRepository, SETTINGS_PERSISTENCE_TOKEN } from './services/SettingsRepository';
export type { ISettingsPersistence } from './services/SettingsRepository';

export { RepositorySettingsProvider } from './services/RepositorySettingsProvider';

// services/types.ts 中包含 DI tokens + 少量 interface。
// 对外可见面统一从 core/types barrel 暴露（避免 core/public.ts 深层 export*）

//
// -------------------- Bootstrap / Polyfills --------------------
//
export { ensureReflectMetadata } from './polyfills';
export { setupCoreContainer } from './di/setupCore';

//
// -------------------- Hooks（暂时放 core，后续可迁移到 shared/ui） --------------------
//
export { useTimelineZoom } from './hooks/useTimelineZoom';
export { PROGRESS_VIEW_DEFAULT_CONFIG } from './config/views';
