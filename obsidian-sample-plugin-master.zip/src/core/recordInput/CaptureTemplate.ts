import type { FieldOption } from '@/core/fields/FieldTypes';
import type { CaptureFieldConfig } from '@/core/fields/FieldSchema';
import type { PeriodPolicy } from '@/core/period/PeriodPolicy';

export type TemplateFieldOption = FieldOption;
export type TemplateField = CaptureFieldConfig;

/**
 * User-owned capture template.
 *
 * The template decides which fields the user records, their order/defaults and
 * destination. Markdown grammar remains owned by the Record codec.
 */
export interface RecordCaptureTemplate {
  id: string;
  name: string;
  fields: TemplateField[];
  targetFile: string;
  recordTypeId?: string;
  periodPolicy?: PeriodPolicy;
  appendUnderHeader?: string;
}

export interface InputSettings {
  recordTypes: RecordCaptureTemplate[];
}
