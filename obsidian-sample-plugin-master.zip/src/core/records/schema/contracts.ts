import { RECORD_SCHEMA_CONTRACT_VERSION, type RecordFieldContract, type RecordSchemaContract } from './types';

function f(
  key: string,
  role: RecordFieldContract['role'],
  persistence: RecordFieldContract['persistence'],
  valueType: RecordFieldContract['valueType'],
  description: string,
  options: Omit<RecordFieldContract, 'key' | 'role' | 'persistence' | 'valueType' | 'description'> = {},
): RecordFieldContract {
  return { key, role, persistence, valueType, description, ...options };
}

const ENVELOPE = [
  f('记录ID', 'identity', 'target', 'record-id', 'Stable Record identity; never derived from file path or line.', { required: true, aliases: ['recordId', 'id'] }),
  f('记录类型', 'identity', 'target', 'enum', 'Business record type discriminator.', { required: true, aliases: ['recordType'] }),
] as const;

const GOAL = [
  f('目标', 'canonical-reference', 'target', 'string', 'Canonical human-readable Goal path. The path itself is the Goal identity.', { aliases: ['goalPath'] }),
] as const;
const DATE = f('日期', 'business-fact', 'target', 'date', 'Record occurrence/business date.', { aliases: ['date'] });
const CONTENT = f('内容', 'business-fact', 'target', 'string', 'Primary human-authored Record content.', { aliases: ['content', '任务内容'] });
const TAGS = f('标签', 'business-fact', 'target', 'tags', 'User-authored tags. Omit when empty.', { aliases: ['tags'] });
const ICON = f('图标', 'display-snapshot', 'target', 'string', 'Historical display snapshot. R5 decides whether displayStyle can replace this.', { aliases: ['icon'] });


const GENERIC_COMMON = [...ENVELOPE, ...GOAL, DATE] as const;

export const THOUGHT_SCHEMA: RecordSchemaContract = {
  contractVersion: RECORD_SCHEMA_CONTRACT_VERSION,
  recordType: 'thought',
  displayName: '思考',
  family: 'generic',
  capabilities: { userVisible: true, goalBindable: true, dated: true, customFields: true },
  recordFields: [...GENERIC_COMMON, TAGS, ICON, CONTENT],
};

export const FEELING_SCHEMA: RecordSchemaContract = {
  contractVersion: RECORD_SCHEMA_CONTRACT_VERSION,
  recordType: 'feeling',
  displayName: '感受',
  family: 'generic',
  capabilities: { userVisible: true, goalBindable: true, dated: true, customFields: true },
  recordFields: [...GENERIC_COMMON, TAGS, ICON, CONTENT],
};

export const EVENT_SCHEMA: RecordSchemaContract = {
  contractVersion: RECORD_SCHEMA_CONTRACT_VERSION,
  recordType: 'event',
  displayName: '事件',
  family: 'generic',
  capabilities: { userVisible: true, goalBindable: true, dated: true, customFields: true },
  recordFields: [...GENERIC_COMMON, TAGS, ICON, CONTENT],
};

export const HABIT_SCHEMA: RecordSchemaContract = {
  contractVersion: RECORD_SCHEMA_CONTRACT_VERSION,
  recordType: 'habit',
  displayName: '打卡',
  family: 'generic',
  capabilities: { userVisible: true, goalBindable: true, dated: true, customFields: true },
  recordFields: [
    ...GENERIC_COMMON,
    f('评分', 'business-fact', 'target', 'number', 'Habit rating/value.', { aliases: ['rating'] }),
    f('图片', 'business-fact', 'target', 'string', 'Canonical image/rating visual value.', { aliases: ['image'] }),
    CONTENT,
  ],
};

function periodRecord(recordType: 'plan' | 'review', displayName: string): RecordSchemaContract {
  return {
    contractVersion: RECORD_SCHEMA_CONTRACT_VERSION,
    recordType,
    displayName,
    family: 'generic',
    capabilities: { userVisible: true, goalBindable: true, dated: true, periodAware: true, customFields: true },
    recordFields: [
      ...GENERIC_COMMON,
      f('周期粒度', 'business-fact', 'target', 'enum', 'Only persisted period fact. Period ID/label are derived from 日期 + 周期粒度.', { aliases: ['periodGranularity'], allowedValues: ['week', 'month', 'quarter', 'year'] }),
      ICON,
      CONTENT,
    ],
  };
}

export const PLAN_SCHEMA = periodRecord('plan', '计划');
export const REVIEW_SCHEMA = periodRecord('review', '总结');

function simpleGoalRecord(recordType: 'blocker' | 'milestone', displayName: string): RecordSchemaContract {
  return {
    contractVersion: RECORD_SCHEMA_CONTRACT_VERSION,
    recordType,
    displayName,
    family: 'generic',
    capabilities: { userVisible: true, goalBindable: true, dated: true, customFields: true },
    recordFields: [...GENERIC_COMMON, ICON, CONTENT],
  };
}

export const BLOCKER_SCHEMA = simpleGoalRecord('blocker', '阻碍');
export const MILESTONE_SCHEMA = simpleGoalRecord('milestone', '里程碑');

const TASK_DEMAND_FIELDS = [
  f('优先级', 'domain-fact', 'target', 'enum', 'User-declared Task priority.', { aliases: ['priority'], allowedValues: ['lowest', 'low', 'medium', 'high', 'highest'] }),
  f('重要程度', 'domain-fact', 'target', 'enum', 'Eisenhower importance classification. Missing means unclassified.', { aliases: ['importance'], allowedValues: ['important', 'normal'] }),
  f('紧急程度', 'domain-fact', 'target', 'enum', 'Eisenhower urgency classification. Missing means unclassified.', { aliases: ['urgency'], allowedValues: ['urgent', 'normal'] }),
  f('预计时长', 'domain-fact', 'target', 'number', 'User-declared duration in minutes. It can complete a manual Task time range when endAt is absent; TaskSession remains the source for multi-session timer history.', { aliases: ['expectedDurationMinutes'] }),
  f('精力要求', 'domain-fact', 'target', 'enum', 'Declared overall energy demand.', { aliases: ['energyDemand'], allowedValues: ['low', 'medium', 'high'] }),
  f('脑力要求', 'domain-fact', 'target', 'enum', 'Declared cognitive demand.', { aliases: ['brainDemand'], allowedValues: ['low', 'medium', 'high'] }),
  f('体力要求', 'domain-fact', 'target', 'enum', 'Declared physical demand.', { aliases: ['physicalDemand'], allowedValues: ['low', 'medium', 'high'] }),
  f('可用场景', 'domain-fact', 'target', 'string', 'Execution contexts where the Task can actually be done. Empty or any means unrestricted.', { aliases: ['availabilityContexts'] }),
  f('恢复意图', 'domain-fact', 'omit-default', 'boolean', 'True when the Task is intentionally recovery-oriented.', { aliases: ['recoveryIntent'], defaultValue: false }),
] as const;


export const TASK_SCHEMA: RecordSchemaContract = {
  contractVersion: RECORD_SCHEMA_CONTRACT_VERSION,
  recordType: 'task',
  displayName: '任务',
  family: 'task-domain',
  capabilities: { userVisible: true, goalBindable: true, dated: true, statusful: true, customFields: true },
  recordFields: [
    ...ENVELOPE,
    f('状态', 'domain-fact', 'target', 'enum', 'Task lifecycle state.', { required: true, aliases: ['status'], allowedValues: ['open', 'done', 'cancelled', 'skipped'] }),
    f('创建于', 'domain-fact', 'target', 'datetime', 'Task creation timestamp.', { aliases: ['createdAt'] }),
    ...GOAL,
    f('系列ID', 'canonical-reference', 'target', 'record-id', 'Optional TaskSeries reference.', { aliases: ['seriesId'] }),
    f('计划时间', 'domain-fact', 'target', 'datetime', 'Scheduled execution timestamp.', { aliases: ['scheduledAt'] }),
    f('开始时间', 'domain-fact', 'target', 'datetime', 'Legacy/manual Task range start. New planning writes use scheduledAt; actual execution writes use TaskSession.', { aliases: ['startAt'] }),
    f('结束时间', 'domain-fact', 'target', 'datetime', 'Legacy/manual Task range end. Kept for compatibility; actual execution writes use TaskSession.', { aliases: ['endAt'] }),
    f('截止时间', 'domain-fact', 'target', 'datetime', 'Due timestamp.', { aliases: ['dueAt'] }),
    f('计划日期', 'domain-fact', 'target', 'date', 'Date-only scheduled execution fact used by current records.', { aliases: ['scheduledDate'] }),
    f('开始日期', 'domain-fact', 'target', 'date', 'Date-only declared start fact used by current records.', { aliases: ['startDate'] }),
    f('截止日期', 'domain-fact', 'target', 'date', 'Date-only due fact used by current records.', { aliases: ['dueDate'] }),
    f('完成于', 'domain-fact', 'target', 'datetime', 'Task completion timestamp/date.', { aliases: ['completedAt'] }),
    f('取消于', 'domain-fact', 'target', 'datetime', 'Task cancellation timestamp/date.', { aliases: ['cancelledAt'] }),
    f('跳过于', 'domain-fact', 'target', 'datetime', 'Recurring occurrence skipped timestamp/date.', { aliases: ['skippedAt'] }),
    ...TASK_DEMAND_FIELDS,
    f('内容', 'domain-fact', 'target', 'string', 'Task intent/content.', { aliases: ['content', '任务内容'] }),
  ],
};

export const TASK_SERIES_SCHEMA: RecordSchemaContract = {
  contractVersion: RECORD_SCHEMA_CONTRACT_VERSION,
  recordType: 'task-series',
  displayName: '任务系列',
  family: 'task-domain',
  capabilities: { userVisible: false, goalBindable: true, dated: true, statusful: true },
  recordFields: [
    ...ENVELOPE,
    f('状态', 'domain-fact', 'target', 'enum', 'TaskSeries lifecycle state.', { required: true, aliases: ['status'], allowedValues: ['active', 'stopped'] }),
    ...GOAL,
    ...TASK_DEMAND_FIELDS,
    f('重复单位', 'domain-fact', 'target', 'enum', 'Structured recurrence unit.', { required: true, aliases: ['recurrenceUnit'], allowedValues: ['day', 'week', 'month', 'quarter', 'year'] }),
    f('重复间隔', 'domain-fact', 'target', 'number', 'Structured recurrence interval.', { required: true, aliases: ['recurrenceInterval'], defaultValue: 1 }),
    f('重复锚点', 'domain-fact', 'target', 'enum', 'Structured recurrence anchor.', { required: true, aliases: ['recurrenceAnchor'], allowedValues: ['scheduled', 'start', 'due', 'completion'], defaultValue: 'scheduled' }),
    f('系列开始日期', 'domain-fact', 'target', 'date', 'Series anchor/start date.', { aliases: ['seriesStartDate'] }),
    f('当前任务ID', 'canonical-reference', 'target', 'record-id', 'Current active occurrence reference.', { aliases: ['currentTaskId'] }),
    f('滚动策略', 'domain-fact', 'omit-default', 'enum', 'Rollover policy; carry is currently the sole/default strategy.', { aliases: ['rolloverPolicy'], allowedValues: ['carry'], defaultValue: 'carry' }),
    f('内容', 'domain-fact', 'target', 'string', 'Long-lived recurring Task definition.', { aliases: ['content'] }),
  ],
};

export const TASK_SESSION_SCHEMA: RecordSchemaContract = {
  contractVersion: RECORD_SCHEMA_CONTRACT_VERSION,
  recordType: 'task-session',
  displayName: '任务工作块',
  family: 'internal-history',
  capabilities: { userVisible: false, goalBindable: true, dated: true, executionHistory: true },
  recordFields: [
    ...ENVELOPE,
    f('任务ID', 'canonical-reference', 'target', 'record-id', 'Executed Task reference.', { required: true, aliases: ['taskId'] }),
    f('系列ID', 'canonical-reference', 'target', 'record-id', 'Optional TaskSeries reference.', { aliases: ['seriesId'] }),
    ...GOAL,
    f('开始于', 'domain-fact', 'target', 'datetime', 'Actual session start.', { required: true, aliases: ['sessionStartedAt'] }),
    f('结束于', 'domain-fact', 'target', 'datetime', 'Actual session end.', { required: true, aliases: ['sessionEndedAt'] }),
    f('时长', 'domain-fact', 'target', 'number', 'Actual session duration in minutes.', { required: true, aliases: ['sessionDurationMinutes'] }),
    f('结果', 'domain-fact', 'target', 'enum', 'Session outcome.', { required: true, aliases: ['sessionResult'], allowedValues: ['work-block-ended', 'task-completed'] }),
    f('来源', 'measurement-provenance', 'target', 'enum', 'Execution capture source.', { required: true, aliases: ['sessionSource'], allowedValues: ['timer', 'energy-view', 'timeline', 'unknown'] }),
    f('建议时长', 'domain-fact', 'target', 'number', 'Suggested duration snapshot at execution time.', { aliases: ['suggestedDurationMinutes'] }),
    f('开始精力记录ID', 'canonical-reference', 'target', 'record-id', 'Energy snapshot at session start.', { aliases: ['startEnergyRecordId'] }),
    f('结束精力记录ID', 'canonical-reference', 'target', 'record-id', 'Energy snapshot linked after session.', { aliases: ['endEnergyRecordId'] }),
    f('精力变化', 'domain-fact', 'target', 'number', 'Linked energy delta.', { aliases: ['energyDelta'] }),
    f('脑力变化', 'domain-fact', 'target', 'number', 'Linked cognitive-energy delta.', { aliases: ['brainDelta'] }),
    f('体力变化', 'domain-fact', 'target', 'number', 'Linked physical-energy delta.', { aliases: ['physicalDelta'] }),
  ],
};

export const ENERGY_SCHEMA: RecordSchemaContract = {
  contractVersion: RECORD_SCHEMA_CONTRACT_VERSION,
  recordType: 'energy',
  displayName: '精力',
  family: 'energy-domain',
  capabilities: { userVisible: true, goalBindable: true, dated: true, subtypeAware: true, customFields: true },
  recordFields: [
    ...ENVELOPE,
    f('记录子类型', 'domain-fact', 'target', 'enum', 'Energy domain discriminator.', { required: true, aliases: ['recordSubtype'], allowedValues: ['snapshot', 'change', 'recovery', 'depletion', 'stop'] }),
    ...GOAL,
    DATE,
    f('时间', 'business-fact', 'target', 'string', 'Energy observation time when known.', { aliases: ['time'] }),
    f('时段', 'business-fact', 'target', 'string', 'Energy observation period when exact time is unavailable.', { aliases: ['period'] }),
    f('精力值', 'domain-fact', 'target', 'number', 'Canonical 0-100 energy score.', { aliases: ['score'] }),
    f('脑力精力', 'domain-fact', 'target', 'number', 'Detailed cognitive energy score.', { aliases: ['brainScore'] }),
    f('体力精力', 'domain-fact', 'target', 'number', 'Detailed physical energy score.', { aliases: ['physicalScore'] }),
    f('综合算法', 'measurement-provenance', 'target', 'string', 'Aggregation method for detailed scores.', { aliases: ['aggregateMethod'] }),
    f('评分模式', 'measurement-provenance', 'target', 'enum', 'How the energy score was captured.', { aliases: ['scoreMode'], allowedValues: ['quick', 'detailed', 'percent'] }),
    f('记录方式', 'measurement-provenance', 'target', 'enum', 'Realtime vs retrospective capture.', { aliases: ['captureMode'], allowedValues: ['realtime', 'retrospective'] }),
    f('时间精度', 'measurement-provenance', 'target', 'enum', 'Precision of observation time.', { aliases: ['timePrecision'], allowedValues: ['exact', 'approximate', 'period', 'day'] }),
    f('记录时间', 'measurement-provenance', 'target', 'datetime', 'Actual capture timestamp when available.', { aliases: ['recordedAt'] }),
    f('来源', 'measurement-provenance', 'target', 'string', 'Capture surface/source.', { aliases: ['source'] }),
  ],
};

export const RECORD_SCHEMA_CONTRACTS: readonly RecordSchemaContract[] = [
  THOUGHT_SCHEMA,
  FEELING_SCHEMA,
  EVENT_SCHEMA,
  HABIT_SCHEMA,
  PLAN_SCHEMA,
  REVIEW_SCHEMA,
  BLOCKER_SCHEMA,
  MILESTONE_SCHEMA,
  TASK_SCHEMA,
  TASK_SERIES_SCHEMA,
  TASK_SESSION_SCHEMA,
  ENERGY_SCHEMA,
];
