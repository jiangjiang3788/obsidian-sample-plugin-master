import type { EnergySnapshotInput, EnergySnapshotRecord } from './types';
import { createRecordId } from '@/core/records/RecordId';
import { encodeRecordBlock } from '@/core/records/codec/MarkdownRecordCodec';
import { calculateDetailedEnergyScore, normalizeEnergyScore, toEnergyQuickLevel } from './scale';

export const ENERGY_TARGET_FILE = '01/精力.md';
export const ENERGY_APPEND_UNDER_HEADER = '## {{goalPath}}';

function clean(value?: string): string {
  return String(value || '').trim();
}

export function buildEnergySnapshotRecord(input: EnergySnapshotInput): EnergySnapshotRecord {
  const captureMode = input.captureMode || 'realtime';
  const timePrecision = input.timePrecision || (input.time ? 'exact' : input.period ? 'period' : 'day');
  const isDetailed = input.scoreMode === 'detailed';
  const brainScore = isDetailed ? normalizeEnergyScore(input.brainScore) : undefined;
  const physicalScore = isDetailed ? normalizeEnergyScore(input.physicalScore) : undefined;
  const score = isDetailed
    ? calculateDetailedEnergyScore(input.brainScore, input.physicalScore)
    : normalizeEnergyScore(input.score);

  return {
    ...input,
    recordId: createRecordId('energy'),
    goalPath: clean(input.goalPath) || undefined,
    time: clean(input.time) || undefined,
    period: clean(input.period) || undefined,
    recordedAt: clean(input.recordedAt) || undefined,
    source: clean(input.source) || undefined,
    recordType: 'energy',
    subtype: 'snapshot',
    score,
    scoreMode: input.scoreMode || 'quick',
    captureMode,
    timePrecision,
    quickLevel: toEnergyQuickLevel(score),
    brainScore,
    physicalScore,
    aggregateMethod: isDetailed ? 'arithmetic-mean-v1' : undefined,
  };
}

/**
 * Energy Snapshot is Goal-bound but not Template-bound.
 * Goal path is the only persisted ownership identity.
 */
export function buildEnergySnapshotMarkdown(input: EnergySnapshotInput | EnergySnapshotRecord): string {
  const record = 'recordType' in input ? input : buildEnergySnapshotRecord(input);
  return encodeRecordBlock({
    recordId: record.recordId,
    recordType: 'energy',
    fields: {
      '记录子类型': 'snapshot',
      '目标': record.goalPath,
      '日期': record.date,
      '时间': record.time,
      '时段': record.period,
      '精力值': record.score,
      '脑力精力': record.brainScore,
      '体力精力': record.physicalScore,
      '综合算法': record.aggregateMethod,
      '评分模式': record.scoreMode,
      '记录方式': record.captureMode,
      '时间精度': record.timePrecision,
      '记录时间': record.recordedAt,
      '来源': record.source,
    },
  });
}
