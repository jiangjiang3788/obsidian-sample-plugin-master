import type { RecordViewItem } from '@/core/records/RecordEntity';
import type { DataStore } from '../DataStore';
import { RecordRepository, type RecordBatchOperation } from '@/core/records/RecordRepository';
import { createRecordId } from '@/core/records/RecordId';
import { asTaskRecord, asTaskSeriesRecord, type TaskDemandLevel, type TaskPriority, type TaskRecord, type TaskSeriesRecord } from '@/core/records/task/taskDomain';
import { canTransitionTaskStatus, getTaskStatus, nextTaskStatus, type TaskLifecycleCommand } from '@/core/records/task/taskStatus';
import { buildNextOccurrenceDates, normalizeRecurrenceInfo, type RecurrenceInfo } from '@/core/records/task/taskRecurrence';
import type { TaskSessionCreateInput } from '@/core/types/timer';
import { asTaskSessionRecord } from '@/core/records/task/taskSession';
import { TaskSessionMutation } from './TaskSessionMutation';
import type { ItemMutationOptions } from './types';
import { resolveRecordTargetPath } from '@/core/recordInput/storagePath';
import type { ISettingsProvider } from '@/core/services/types';
import { GoalTemplateResolver } from '../GoalTemplateResolver';

function timestampNow(): string { return new Date().toISOString(); }

function buildLegacyActualRangeCompletionSession(
  dataStore: DataStore,
  task: TaskRecord,
): TaskSessionCreateInput | null {
  const startedAt = String(task.startAt || '').trim();
  const endedAt = String(task.endAt || '').trim();
  if (!startedAt || !endedAt) return null;

  const startedMs = Date.parse(startedAt);
  const endedMs = Date.parse(endedAt);
  if (!Number.isFinite(startedMs) || !Number.isFinite(endedMs) || endedMs <= startedMs) return null;

  // Never duplicate an already-canonical execution history. This compatibility
  // migration is only for old Tasks whose actual range still lives on Task itself.
  const alreadyHasSession = dataStore.queryRecords()
    .some((record) => asTaskSessionRecord(record)?.taskId === task.id);
  if (alreadyHasSession) return null;

  const durationMinutes = Math.round(((endedMs - startedMs) / 60_000) * 100) / 100;
  if (!Number.isFinite(durationMinutes) || durationMinutes <= 0) return null;

  return {
    startedAt: new Date(startedMs).toISOString(),
    endedAt: new Date(endedMs).toISOString(),
    durationMinutes,
    result: 'task-completed',
    source: 'unknown',
  };
}

export interface TaskSeriesUpdate {
  recurrence?: Partial<RecurrenceInfo>;
  content?: string;
  goalPath?: string | null;
  priority?: TaskPriority | null;
  importance?: TaskSeriesRecord['importance'] | null;
  urgency?: TaskSeriesRecord['urgency'] | null;
  expectedDurationMinutes?: number | null;
  energyDemand?: TaskDemandLevel | null;
  brainDemand?: TaskDemandLevel | null;
  physicalDemand?: TaskDemandLevel | null;
  availabilityContexts?: TaskSeriesRecord['availabilityContexts'] | null;
  recoveryIntent?: boolean | null;
}


function sourcePath(dataStore: DataStore, item: TaskRecord): string {
  return item.source?.path || item.file?.path || dataStore.getRecordLocation(item.id)?.path || '';
}

function nextTaskFields(task: TaskRecord, series: TaskSeriesRecord, completedAt: string, nextDates: ReturnType<typeof buildNextOccurrenceDates>): Record<string, unknown> {
  return {
    status: 'open',
    // Series owns future-instance defaults. Historical/current Task metadata is never used
    // as the authority for future occurrences after a Series update.
    content: series.content || task.content,
    goalPath: series.goalPath,
    createdAt: completedAt,
    priority: series.priority,
    importance: series.importance,
    urgency: series.urgency,
    expectedDurationMinutes: series.expectedDurationMinutes,
    energyDemand: series.energyDemand,
    brainDemand: series.brainDemand,
    physicalDemand: series.physicalDemand,
    availabilityContexts: series.availabilityContexts,
    recoveryIntent: series.recoveryIntent,
    scheduledAt: nextDates.scheduledAt,
    startAt: nextDates.startAt,
    dueAt: nextDates.dueAt,
    scheduledDate: nextDates.scheduledDate,
    startDate: nextDates.startDate,
    dueDate: nextDates.dueDate,
    seriesId: series.id,
  };
}

export class TaskCompletionMutation {
  private readonly taskSessions: TaskSessionMutation;

  constructor(
    private readonly dataStore: DataStore,
    private readonly repository: RecordRepository,
    taskSessions?: TaskSessionMutation,
    private readonly settingsProvider?: ISettingsProvider,
  ) {
    this.taskSessions = taskSessions ?? new TaskSessionMutation(dataStore, repository);
  }

  private resolveTaskTargetFileTemplate(goalPath: string, fallbackPath: string): string {
    if (!this.settingsProvider) return fallbackPath;
    const resolved = GoalTemplateResolver.resolve({
      settings: this.settingsProvider.getSettings(),
      recordTypeId: 'core.task',
      goalPath,
      requireDirectGoalTemplate: true,
    });
    return String(resolved.template?.targetFile || '').trim() || fallbackPath;
  }

  async completeItem(itemId: string, _mutationOptions: ItemMutationOptions = {}): Promise<void> {
    await this.transition(itemId, 'complete');
  }

  async completeItemWithSession(
    itemId: string,
    session: TaskSessionCreateInput,
    _mutationOptions: ItemMutationOptions = {},
  ): Promise<void> {
    if (session.result !== 'task-completed') throw new Error('task_session_complete_result_required');
    await this.transition(itemId, 'complete', session);
  }

  async cancelItem(itemId: string): Promise<void> { await this.transition(itemId, 'cancel'); }
  async cancelItemWithSession(itemId: string, session: TaskSessionCreateInput): Promise<void> {
    if (session.result !== 'work-block-ended') throw new Error('task_session_cancel_result_required');
    await this.transition(itemId, 'cancel', session);
  }
  async skipItem(itemId: string): Promise<void> { await this.transition(itemId, 'skip'); }
  async skipItemWithSession(itemId: string, session: TaskSessionCreateInput): Promise<void> {
    if (session.result !== 'work-block-ended') throw new Error('task_session_skip_result_required');
    await this.transition(itemId, 'skip', session);
  }
  async reopenItem(itemId: string): Promise<void> { await this.transition(itemId, 'reopen'); }

  async updateSeries(
    seriesId: string,
    update: TaskSeriesUpdate,
    options: { includeCurrent?: boolean } = {},
  ): Promise<void> {
    const series = asTaskSeriesRecord(await this.repository.getById(seriesId));
    if (!series) throw new Error(`task_series_invalid:${seriesId}`);

    const seriesPatch: Record<string, unknown> = {};
    if (Object.prototype.hasOwnProperty.call(update, 'content') && !String(update.content || '').trim()) {
      throw new Error(`task_series_content_required:${seriesId}`);
    }
    if (update.recurrence) {
      const recurrence = normalizeRecurrenceInfo({
        ...series.recurrenceInfo,
        ...update.recurrence,
      });
      if (!recurrence) throw new Error(`task_series_recurrence_invalid:${seriesId}`);
      seriesPatch.recurrenceUnit = recurrence.unit;
      seriesPatch.recurrenceInterval = recurrence.interval;
      seriesPatch.recurrenceAnchor = recurrence.anchor;
    }

    const sharedFields: Array<[keyof TaskSeriesUpdate, string]> = [
      ['content', 'content'],
      ['goalPath', 'goalPath'],
      ['priority', 'priority'],
      ['importance', 'importance'],
      ['urgency', 'urgency'],
      ['expectedDurationMinutes', 'expectedDurationMinutes'],
      ['energyDemand', 'energyDemand'],
      ['brainDemand', 'brainDemand'],
      ['physicalDemand', 'physicalDemand'],
      ['availabilityContexts', 'availabilityContexts'],
      ['recoveryIntent', 'recoveryIntent'],
    ];
    for (const [sourceKey, patchKey] of sharedFields) {
      if (Object.prototype.hasOwnProperty.call(update, sourceKey)) seriesPatch[patchKey] = update[sourceKey];
    }

    const operations: RecordBatchOperation[] = [];
    if (Object.keys(seriesPatch).length) operations.push({ kind: 'update', recordId: series.id, patch: seriesPatch });

    if (options.includeCurrent && series.currentTaskId) {
      const current = asTaskRecord(await this.repository.getById(series.currentTaskId));
      if (!current || current.seriesId !== series.id) throw new Error(`task_series_current_conflict:${series.id}`);
      if (getTaskStatus(current) !== 'open') throw new Error(`task_series_current_not_open:${series.id}`);
      const currentPatch: Record<string, unknown> = {};
      for (const [sourceKey, patchKey] of sharedFields) {
        if (Object.prototype.hasOwnProperty.call(update, sourceKey)) currentPatch[patchKey] = update[sourceKey];
      }
      if (Object.keys(currentPatch).length) operations.push({ kind: 'update', recordId: current.id, patch: currentPatch });
    }

    if (operations.length) await this.repository.batch(operations);
  }

  async repairSeriesCurrentTask(seriesId: string): Promise<'already-valid' | 'repaired'> {
    const series = asTaskSeriesRecord(await this.repository.getById(seriesId));
    if (!series) throw new Error(`task_series_invalid:${seriesId}`);
    if (series.status !== 'active') throw new Error(`task_series_repair_requires_active:${seriesId}`);

    const pointed = series.currentTaskId ? asTaskRecord(await this.repository.getById(series.currentTaskId)) : null;
    if (pointed && pointed.seriesId === series.id && getTaskStatus(pointed) === 'open') return 'already-valid';

    const candidates = this.dataStore.queryRecords()
      .filter(item => item.recordType === 'task' && item.seriesId === series.id && getTaskStatus(item) === 'open');
    if (candidates.length !== 1) {
      throw new Error(`task_series_repair_ambiguous:${seriesId}:${candidates.length}`);
    }
    await this.repository.update(series.id, { currentTaskId: candidates[0].id });
    return 'repaired';
  }

  async stopSeries(seriesId: string, options: { cancelCurrent?: boolean } = {}): Promise<void> {
    const series = asTaskSeriesRecord(await this.repository.getById(seriesId));
    if (!series) throw new Error(`task_series_invalid:${seriesId}`);
    if (series.status !== 'active') return;
    const operations: RecordBatchOperation[] = [{ kind: 'update', recordId: series.id, patch: { status: 'stopped' } }];
    if (options.cancelCurrent && series.currentTaskId) {
      const current = asTaskRecord(await this.repository.getById(series.currentTaskId));
      if (current && getTaskStatus(current) === 'open') {
        operations.push({ kind: 'update', recordId: current.id, patch: { status: 'cancelled', cancelledAt: timestampNow() } });
      }
    }
    await this.repository.batch(operations);
  }

  private async transition(
    itemId: string,
    command: TaskLifecycleCommand,
    sessionInput?: TaskSessionCreateInput,
  ): Promise<void> {
    const task = await this.requireTask(itemId);
    const status = getTaskStatus(task);
    if (!status) throw new Error(`task_status_invalid:${itemId}`);
    const recurring = Boolean(task.seriesId);
    if (!canTransitionTaskStatus(status, command, { recurring })) {
      throw new Error(`task_transition_invalid:${status}:${command}`);
    }

    const legacyActualSession = !sessionInput && command === 'complete'
      ? buildLegacyActualRangeCompletionSession(this.dataStore, task)
      : null;
    const effectiveSessionInput = sessionInput ?? legacyActualSession ?? undefined;
    const at = effectiveSessionInput?.endedAt || timestampNow();
    if (command === 'reopen') {
      if (task.seriesId) {
        const series = asTaskSeriesRecord(await this.repository.getById(task.seriesId));
        if (!series || series.currentTaskId !== task.id) throw new Error('task_reopen_recurring_conflict');
      }
      await this.repository.update(task.id, { status: 'open', completedAt: null, cancelledAt: null, skippedAt: null });
      return;
    }

    const patch: Record<string, unknown> = { status: nextTaskStatus(command) };
    const sessionOperation = effectiveSessionInput
      ? this.taskSessions.prepareCreateOperation(task, effectiveSessionInput).operation
      : null;
    if (command === 'complete') patch.completedAt = at;
    if (legacyActualSession) {
      // The migrated Session is now the execution authority. Remove only the legacy
      // actual range; expectedDurationMinutes remains a planning/expectation fact.
      patch.startAt = null;
      patch.endAt = null;
    }
    if (command === 'cancel') patch.cancelledAt = at;
    if (command === 'skip') patch.skippedAt = at;
    if (!task.seriesId || command === 'cancel') {
      if (sessionOperation) await this.repository.batch([{ kind: 'update', recordId: task.id, patch }, sessionOperation]);
      else await this.repository.update(task.id, patch);
      return;
    }

    const series = asTaskSeriesRecord(await this.repository.getById(task.seriesId));
    if (!series) throw new Error(`task_series_missing:${task.seriesId}`);
    if (series.currentTaskId !== task.id) throw new Error(`task_series_current_conflict:${series.id}`);
    if (series.status === 'stopped') {
      // Stopping recurrence does not have to cancel the current occurrence. It can still
      // be completed/skipped, but it must never generate another instance.
      if (sessionOperation) await this.repository.batch([{ kind: 'update', recordId: task.id, patch }, sessionOperation]);
      else await this.repository.update(task.id, patch);
      return;
    }
    const recurrence = normalizeRecurrenceInfo(series.recurrenceInfo);
    if (!recurrence) throw new Error(`task_series_recurrence_invalid:${series.id}`);

    const nextId = createRecordId('task');
    const nextDates = buildNextOccurrenceDates(task, recurrence, at);
    const path = sourcePath(this.dataStore, task);
    if (!path) throw new Error(`record_location_unavailable:${task.id}`);
    const nextFields = nextTaskFields(task, series, at, nextDates);
    // Future recurring instances must be routed from the configured target-file
    // template, not by mutating the current occurrence's already-resolved path.
    const targetFileTemplate = this.resolveTaskTargetFileTemplate(
      String(nextFields.goalPath || task.goalPath || ''),
      path,
    );
    const nextPath = resolveRecordTargetPath(targetFileTemplate, 'task', nextFields);

    const operations: RecordBatchOperation[] = [
      { kind: 'update', recordId: task.id, patch },
    ];
    if (sessionOperation) operations.push(sessionOperation);
    operations.push(
      { kind: 'create', record: {
        recordId: nextId,
        recordType: 'task',
        targetFilePath: nextPath,
        targetHeader: task.header || null,
        fields: nextFields,
      } },
      { kind: 'update', recordId: series.id, patch: { currentTaskId: nextId } },
    );
    await this.repository.batch(operations);
  }

  private async requireTask(itemId: string): Promise<TaskRecord> {
    const task = asTaskRecord(await this.repository.getById(itemId));
    if (!task) throw new Error(`task_record_required:${itemId}`);
    return task;
  }
}
