// src/core/utils/index.ts
/**
 * Core Utils Public Barrel
 * ---------------------------------------------------------------
 * ✅ 任何非 core 层需要复用的“纯函数 / 纯计算”工具，都应通过此处统一导出。
 *
 * 设计原则：
 * - 只放“无副作用”或“可控副作用”的工具（例如：纯计算、格式化、解析）。
 * - 一旦导出，就会自动成为 @core/public 的一部分（对外公共面）。
 * - 如果你不确定某个工具是否应该对外，请先不要导出，等用例收敛后再放进来。
 */

export * from './array';
export * from './id';
export * from './date';
export * from './devLogger';
export * from './exportUtils';
export * from './heatmap';
export * from './heatmapTemplate';
export * from './heatmapVisual';
export * from './inputTemplateUtils';
export * from './itemGrouping';
export * from './normalize';
export * from './obsidian';
export * from './parser';
export * from '../recordInput/feedback';
export * from './pathUtils';
export * from './pathSemantic';
export * from './statisticsAggregation';
export * from '../records/task/taskStatus';
export * from '../records/task/taskTime';
export * from '../records/task/taskUtils';
export * from './templateUtils';
export * from './timeline';
export * from './timelineAggregation';
export * from './timelineBlocks';
export * from './timelineClock';
export * from './timelineInteraction';
export * from './timelineRange';
export * from './timing';
export * from './unknownRecord';
export * from '../recordInput/recovery';

export { buildTimelineScale, TIMELINE_TICK_STYLE, TIMELINE_SCALE_POLICY, TIMELINE_KEY_HOURS, timelineKeyHour } from './timelineScale';
export type { TimelineScale, TimelineScaleTick, TimelineTickLevel, TimelineDensityMode } from './timelineScale';
