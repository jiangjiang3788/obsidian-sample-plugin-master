// Current-only Record parser: runtime reads Markdown Record Blocks only.
import type { RecordEntity, RecordViewItem } from '@/core/records/RecordEntity';
import { getPeriodCount, dayjs } from './date';
import { decodeRecordContentLines } from '@/core/records/codec';
import { isStableRecordId } from '@/core/records/RecordId';
import { normalizeRecurrenceInfo } from '@/core/records/task/taskRecurrence';
import { normalizeTaskSessionDurationMinutes } from '@/core/records/task/taskSession';
import { getRecordSchemaDefinition } from '@/core/records/schema';

function localCalendarDate(value: string | undefined): string | undefined {
  if (!value) return undefined;
  const parsed = new Date(value);
  if (!Number.isFinite(parsed.getTime())) return undefined;
  const year = parsed.getFullYear();
  const month = String(parsed.getMonth() + 1).padStart(2, '0');
  const day = String(parsed.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

/**
 * Parse one <!-- start --> ... <!-- end --> Record Block.
 * Missing/invalid Record IDs are isolated by returning null; runtime never falls
 * fall back to location-derived identity.
 */
export function parseRecordBlock(
  filePath: string,
  lines: string[],
  startIdx: number,
  endIdx: number,
  parentFolder: string,
): RecordEntity | null {
  const contentLines = lines.slice(startIdx + 1, endIdx);
  const parsed = decodeRecordContentLines(contentLines, parentFolder);
  if (!parsed.recordId || !isStableRecordId(parsed.recordId)) return null;
  if (!parsed.recordType) return null;

  const isTask = parsed.recordType === 'task';
  const isTaskSeries = parsed.recordType === 'task-series';
  const isTaskSession = parsed.recordType === 'task-session';
  if (isTask && !['open', 'done', 'cancelled', 'skipped'].includes(String(parsed.status || ''))) return null;
  if (isTask && parsed.status === 'skipped' && !parsed.seriesId) return null;
  if (isTaskSeries && !['active', 'stopped'].includes(String(parsed.status || ''))) return null;
  const recurrenceInfo = isTaskSeries
    ? normalizeRecurrenceInfo({ unit: parsed.recurrenceUnit, interval: parsed.recurrenceInterval, anchor: parsed.recurrenceAnchor })
    : null;
  if (isTaskSeries && !recurrenceInfo) return null;
  const sessionDuration = normalizeTaskSessionDurationMinutes(parsed.sessionDurationMinutes);
  if (isTaskSession && (!parsed.taskId || !parsed.sessionStartedAt || !parsed.sessionEndedAt || sessionDuration == null || !parsed.sessionResult || !parsed.sessionSource)) return null;
  const canonicalDate = isTask
    ? (localCalendarDate(parsed.scheduledAt) || parsed.scheduledDate
      || localCalendarDate(parsed.dueAt) || parsed.dueDate
      || localCalendarDate(parsed.startAt) || parsed.startDate
      || localCalendarDate(parsed.createdAt)
      || localCalendarDate(parsed.completedAt)
      || localCalendarDate(parsed.endAt)
      || parsed.date)
    : (localCalendarDate(parsed.sessionStartedAt) || parsed.date
      || localCalendarDate(parsed.scheduledAt) || parsed.scheduledDate
      || localCalendarDate(parsed.dueAt) || parsed.dueDate
      || localCalendarDate(parsed.startAt) || parsed.startDate);
  const schema = getRecordSchemaDefinition(parsed.recordType);
  if (!schema) return null;
  const item: RecordViewItem = {
    id: parsed.recordId,
    title: parsed.title || '',
    content: parsed.content,
    rawSource: lines.slice(startIdx, endIdx + 1).join('\n'),
    editableText: parsed.content,
    status: parsed.status,
    tags: parsed.tags,
    goalPath: parsed.goalPath,
    recurrenceInfo: recurrenceInfo || undefined,
    created: 0,
    modified: 0,
    extra: parsed.extra,
    folder: parentFolder,
    recordType: schema.recordType,
    priority: parsed.priority,
    importance: parsed.importance,
    urgency: parsed.urgency,
    createdAt: parsed.createdAt,
    scheduledAt: parsed.scheduledAt,
    startAt: parsed.startAt,
    endAt: parsed.endAt,
    dueAt: parsed.dueAt,
    energyDemand: parsed.energyDemand,
    brainDemand: parsed.brainDemand,
    physicalDemand: parsed.physicalDemand,
    availabilityContexts: parsed.availabilityContexts,
    recoveryIntent: parsed.recoveryIntent,
    scheduledDate: parsed.scheduledDate,
    startDate: parsed.startDate,
    dueDate: parsed.dueDate,
    completedAt: parsed.completedAt,
    cancelledAt: parsed.cancelledAt,
    skippedAt: parsed.skippedAt,
    seriesId: parsed.seriesId,
    seriesStartDate: parsed.seriesStartDate,
    currentTaskId: parsed.currentTaskId,
    rolloverPolicy: parsed.rolloverPolicy,
    taskId: parsed.taskId,
    sessionStartedAt: parsed.sessionStartedAt,
    sessionEndedAt: parsed.sessionEndedAt,
    sessionDurationMinutes: sessionDuration ?? undefined,
    sessionResult: parsed.sessionResult,
    sessionSource: parsed.sessionSource,
    suggestedDurationMinutes: parsed.suggestedDurationMinutes,
    startEnergyRecordId: parsed.startEnergyRecordId,
    endEnergyRecordId: parsed.endEnergyRecordId,
    energyDelta: parsed.energyDelta,
    brainDelta: parsed.brainDelta,
    physicalDelta: parsed.physicalDelta,
    ...(parsed.recordType === 'energy' && parsed.recordSubtype ? { recordSubtype: parsed.recordSubtype } : {}),
    doneDate: parsed.completedAt,
    cancelledDate: parsed.cancelledAt,
    date: canonicalDate,
  };

  if (parsed.icon) item.icon = parsed.icon;
  if (parsed.rating !== undefined) item.rating = parsed.rating;
  if (parsed.image) item.image = parsed.image;
  if (parsed.seriesId) item.extra['系列ID'] = parsed.seriesId;
  if (parsed.expectedDurationMinutes !== undefined) {
    item.expectedDurationMinutes = parsed.expectedDurationMinutes;
  }

  item.startISO = parsed.sessionStartedAt
    || (isTask ? (parsed.scheduledAt || parsed.scheduledDate || parsed.startAt || parsed.startDate) : undefined)
    || parsed.startAt || parsed.startDate || parsed.scheduledAt || parsed.scheduledDate || parsed.dueAt || parsed.dueDate || parsed.date;
  item.endISO = parsed.sessionEndedAt || parsed.endAt || parsed.completedAt || parsed.cancelledAt || parsed.dueAt || parsed.dueDate || item.startISO;
  if (item.startISO) item.startMs = Date.parse(item.startISO);
  if (item.endISO) item.endMs = Date.parse(item.endISO);

  if (item.period && item.date) item.periodCount = getPeriodCount(item.period, dayjs(item.date));
  return item;
}

