import { RecordViewItem } from '@/core/records/RecordEntity';
import { readField } from '@/core/fields/ViewFieldCatalog';
import { getFieldDefinition } from '@/core/fields/FieldRegistry';
import { normalizeFieldKey } from '@/core/fields/FieldValueResolver';
import { getTaskStatus } from '@/core/records/task/taskStatus';
import {
    BLOCK_EXPORT_DEFAULT_CONFIG,
    getViewExportConfig,
    ExportViewConfig,
} from '@/core/config/views';

/**
 * 根据视图类型获取对应的导出配置
 */
export function getExportConfigByViewType(viewType: string): ExportViewConfig {
    return getViewExportConfig(viewType) || BLOCK_EXPORT_DEFAULT_CONFIG;
}

/**
 * 将 RecordViewItem 数组导出为 Markdown 格式。
 * 支持基于配置的分组和自定义字段输出。
 * 
 * @param items - 要导出的 RecordViewItem 数组。
 * @param config - 导出配置，默认为 BLOCK_EXPORT_DEFAULT_CONFIG。
 * @returns Markdown 格式的字符串。
 */
export function exportItemsToMarkdown(items: RecordViewItem[], config: ExportViewConfig = BLOCK_EXPORT_DEFAULT_CONFIG): string {
    const lines: string[] = [];
    const UNGROUPED_KEY = '未分类';

    /**
     * 递归按多级 groupFields 分组
     * 支持：无分组 / 单字段分组 / 多字段层级分组
     */
    const normalizeExportGroupKeys = (value: unknown): string[] => {
        if (Array.isArray(value)) {
            const keys = value.map(v => String(v ?? '').trim()).filter(Boolean);
            return keys.length ? Array.from(new Set(keys)) : [UNGROUPED_KEY];
        }
        const text = String(value ?? '').trim();
        return text ? [text] : [UNGROUPED_KEY];
    };

    const groupRecursively = (itemsToGroup: RecordViewItem[], groupFields: string[] | undefined, level: number): { key: string; items: RecordViewItem[]; children?: any[] }[] => {
        if (!groupFields || level >= groupFields.length) {
            return [{
                key: UNGROUPED_KEY,
                items: itemsToGroup,
            }];
        }

        const field = groupFields[level];
        const map = new Map<string, RecordViewItem[]>();

        itemsToGroup.forEach(item => {
            const keys = field ? normalizeExportGroupKeys(readField(item, field)) : [UNGROUPED_KEY];
            keys.forEach(key => {
                if (!map.has(key)) {
                    map.set(key, []);
                }
                map.get(key)!.push(item);
            });
        });

        const results: { key: string; items: RecordViewItem[]; children?: any[] }[] = [];
        map.forEach((groupItems, key) => {
            const children = groupRecursively(groupItems, groupFields, level + 1);
            // 如果还有下一层字段，则 children 中会包含具体 items
            results.push({
                key,
                items: level === groupFields.length - 1 ? groupItems : [],
                children: level === groupFields.length - 1 ? undefined : children,
            });
        });

        return results;
    };

    const groupFields = config.groupFields || (config.groupField ? [config.groupField] : undefined);
    const groupedTree = groupRecursively(items, groupFields, 0);

    /**
     * 展平分组树为有层级标题的 Markdown
     */
    const renderGroupTree = (nodes: { key: string; items: RecordViewItem[]; children?: any[] }[], level: number) => {
        nodes.forEach((node, groupIndex) => {
            const isRootLevel = level === 0;

            // 分组之间的分隔符（仅顶层分组之间）
            if (isRootLevel && groupIndex > 0) {
                lines.push('---');
                lines.push('');
            }

            // 分组标题
            if (config.useMarkdownHeadingForGroup) {
                const prefix = config.groupTitlePrefix || '';
                const headingLevel = Math.min(6, 2 + level); // 顶层 ##，下面依次 ###、####...
                const hashes = '#'.repeat(headingLevel);
                lines.push(`${hashes} ${prefix}${node.key}`);
                lines.push('');
            }

            // 如果还有子层级，则递归渲染子层级
            if (node.children && node.children.length > 0) {
                renderGroupTree(node.children, level + 1);
            }

            // 渲染当前层级的 items
            node.items.forEach((item, index) => {
                if (item.coreBlock === 'task') {
                    lines.push(formatTaskItem(item));
                } else {
                    lines.push(...formatBlockItem(item, index + 1, config));
                }
            });
        });
    };

    renderGroupTree(groupedTree, 0);

    return lines.join('\n');
}

/**
 * 格式化 Block 类型的 RecordViewItem
 */
function formatBlockItem(item: RecordViewItem, index: number, config: ExportViewConfig): string[] {
    const lines: string[] = [];

    // 1. 构建 ID 行 (第一行)
    // 模板示例: 'ID {{index}}/{{filename}}#{{id}}'
    let idLine = config.idTemplate
        .replace('{{index}}', index.toString().padStart(2, '0'))
        .replace('{{filename}}', item.filename || '未知文件')
        .replace('{{id}}', item.id || '');

    // 支持更多变量替换（允许在模板中写 {{date}}、{{categoryKey}} 等）
    idLine = idLine.replace(/\{\{(\w+)\}\}/g, (match, key) => {
        const val = readField(item, key);
        return val !== undefined ? String(val) : match;
    });

    lines.push(`- **${idLine}**`);

    // 2. 构建字段列表（顺序由 detailFields 决定）
    config.detailFields.forEach(field => {
        const canonicalField = normalizeFieldKey(field);
        const rawValue = readField(item, canonicalField);
        // 跳过空值，但允许 0
        if (rawValue === undefined || rawValue === null || rawValue === '') return;

        const definition = getFieldDefinition(canonicalField);
        const label = config.fieldLabels[canonicalField] || config.fieldLabels[field] || definition?.label || field;
        const renderCfg = config.fieldRender?.[canonicalField] || config.fieldRender?.[field];
        let displayValue = String(rawValue);

        // 根据字段渲染配置决定展示方式
        if (renderCfg?.type === 'emojiOrLink') {
            // 图片字段规则：如果是纯 emoji，则直接显示；否则转为 ![[ ]] 图片链接（除非已是图片语法）
            const isEmojiOnly = /^[\p{Emoji}\p{Emoji_Presentation}\p{Extended_Pictographic}\s]*$/u.test(displayValue)
                && displayValue.trim().length <= 8
                && !displayValue.includes('.');

            if (isEmojiOnly) {
                displayValue = displayValue.trim();
            } else if (!displayValue.startsWith('![[') && !displayValue.startsWith('![')) {
                displayValue = `![[${displayValue}]]`;
            }

            lines.push(`  - ${label}: ${displayValue}`);
        } else if (renderCfg?.type === 'content') {
            // 内容字段：按示例格式展开为多行
            lines.push(`  - ${label}:`);
            displayValue.split('\n').forEach(line => {
                const trimmedLine = line.trim();
                if (trimmedLine) {
                    lines.push(`  - ${trimmedLine}`);
                }
            });
        } else {
            // 默认普通字段
            lines.push(`  - ${label}: ${displayValue}`);
        }
    });

    return lines;
}

/**
 * Export a Task using canonical domain fields.
 * Export is presentation only; it is not a storage/round-trip codec.
 */
function formatTaskItem(item: RecordViewItem): string {
    const status = getTaskStatus(item) || 'unknown';
    const content = String(item.content || item.editableText || item.title || '').trim() || '未命名任务';
    const lines = [`- **任务** ${content}`];
    const fields: Array<[string, unknown]> = [
        ['记录ID', item.id],
        ['状态', status],
        ['目标', item.goalPath],
        ['优先级', item.priority],
        ['预计时长', item.expectedDurationMinutes ?? item.duration],
        ['计划时间', item.scheduledAt],
        ['开始时间', item.startAt],
        ['结束时间', item.endAt],
        ['截止时间', item.dueAt],
        ['计划日期', item.scheduledDate],
        ['开始日期', item.startDate],
        ['截止日期', item.dueDate],
        ['完成于', item.completedAt],
        ['取消于', item.cancelledAt],
        ['跳过于', item.skippedAt],
        ['系列ID', item.seriesId],
    ];
    for (const [label, value] of fields) {
        if (value === undefined || value === null || value === '') continue;
        lines.push(`  - ${label}: ${String(value)}`);
    }
    return lines.join('\n');
}
