// src/core/utils/normalize.ts
// 统一 date/dateMs/dateSource（categoryKey 已由 parser 决定；此处只兜底）

import { RecordViewItem } from '@/core/records/RecordEntity';

const ORDER = ['done','due','scheduled','start','created','end'] as const;
type DateKey = typeof ORDER[number];

/** 统一计算出 date/dateMs/dateSource；并兜底 categoryKey */
export function normalizeItemDates(it: RecordViewItem): void {
  // Non-Task records keep their own primary date semantics.
  if (it.coreBlock !== 'task') {
    if (it.date) {
      it.dateSource = 'block';
      const t = Date.parse(it.date);
      if (!isNaN(t)) it.dateMs = t;
    }
    // 兜底：没有就用空字符串（理论上 parser 会给到）
    if (!it.categoryKey) (it as any).categoryKey = '';
    return;
  }

  // Task：按优先级推导统一日期
  const pick: Record<DateKey, string | undefined> = {
    done     : it.doneDate,
    due      : it.dueAt ?? it.dueDate,
    scheduled: it.scheduledAt ?? it.scheduledDate,
    start    : it.startAt ?? it.startDate ?? it.startISO,
    created  : it.createdAt ?? it.createdDate,
    end      : it.endAt ?? it.endISO,
  };

  for (const k of ORDER) {
    const iso = pick[k];
    if (iso) {
      it.date = iso;
      it.dateSource = k;
      const t = Date.parse(iso);
      if (!isNaN(t)) it.dateMs = t;
      break;
    }
  }

  // categoryKey is display metadata only; Task status is never encoded here.
  if (!it.categoryKey) (it as any).categoryKey = '任务';
}