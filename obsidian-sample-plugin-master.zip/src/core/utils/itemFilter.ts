// src/core/utils/itemFilter.ts
// 统一的筛选 / 排序 / 日期区间 / 关键字过滤助手
// —— Task 关闭状态只认显式 status；不从 category/raw Markdown 推断。
// —— 修正数字/日期的比较与排序（避免把数值/日期按字符串字典序比较）
import { RecordViewItem } from '@/core/records/RecordEntity';
import { FilterRule, SortRule } from '@/core/view/ViewConfig';
import { readField } from '@/core/fields/ViewFieldCatalog';
import { normalizeFieldKey } from '@/core/fields/FieldValueResolver';
import { asUnknownRecord, readString, readStringArray } from './unknownRecord';

/* ---------- 通用比较：数字/日期优先，其次回退字符串 ---------- */
function coerceForCompare(v: unknown): number | string | null {
  if (v === null || v === undefined) return null;
  if (typeof v === 'number') return v;

  const s = String(v).trim();

  // 优先识别 ISO 日期（YYYY-MM-DD 开头；含时间也可）
  const isDateLike = /^\d{4}-\d{1,2}-\d{1,2}/.test(s) || /^\d{4}\/\d{1,2}\/\d{1,2}/.test(s);
  if (isDateLike) {
    const ts = Date.parse(s.replace(/\//g, '-'));
    if (!Number.isNaN(ts)) return ts;
  }

  // 识别纯数字（含小数/科学计数）
  const n = Number(s);
  if (!Number.isNaN(n) && /\d/.test(s) && !/[^\d.\-+eE]/.test(s)) return n;

  return s;
}

function cmpMixed(a: unknown, b: unknown): number {
  if (a == null && b == null) return 0;
  if (a == null) return 1;   // 让空值在后（升序）
  if (b == null) return -1;

  const A = coerceForCompare(a);
  const B = coerceForCompare(b);

  if (typeof A === 'number' && typeof B === 'number') return A - B;
  // 回退字符串语义（保持原值进行本地化比较）
  return String(a).localeCompare(String(b), 'zh');
}

/* ---------- 过滤 ---------- */
export function filterByRules(items: RecordViewItem[], rules: FilterRule[] = []) {
  if (!rules.length) return items;
  
  return items.filter(item => {
    // 如果没有规则，返回所有项目
    if (rules.length === 0) return true;
    
    // 如果只有一个规则，直接匹配
    if (rules.length === 1) return matchRule(item, rules[0]);
    
    // 处理多个规则的逻辑关系
    let result = matchRule(item, rules[0]);
    
    for (let i = 1; i < rules.length; i++) {
      const currentRule = rules[i];
      const previousRule = rules[i - 1];
      const logic = previousRule.logic || 'and';
      
      if (logic === 'and') {
        result = result && matchRule(item, currentRule);
      } else if (logic === 'or') {
        result = result || matchRule(item, currentRule);
      }
    }
    
    return result;
  });
}

function isEmptyValue(value: unknown): boolean {
  if (value === null || value === undefined) return true;
  if (Array.isArray(value)) return value.length === 0;
  return String(value).trim() === '';
}

function normalizeListValue(value: unknown): unknown[] {
  if (Array.isArray(value)) return value;
  if (value === null || value === undefined) return [];
  return String(value)
    .split(/[,，\n]/)
    .map(part => part.trim())
    .filter(Boolean);
}

function normalizeBetweenValue(value: unknown): [unknown, unknown] | null {
  if (Array.isArray(value) && value.length >= 2) return [value[0], value[1]];
  if (value === null || value === undefined) return null;

  const text = String(value).trim();
  if (!text) return null;
  const parts = text.split(/\s*(?:~|～|至|到|\.\.|,|，)\s*/).filter(Boolean);
  if (parts.length < 2) return null;
  return [parts[0], parts[1]];
}

function matchRule(item: RecordViewItem, rule: FilterRule): boolean {
  const canonicalField = normalizeFieldKey(rule.field);
  const itemRecord = asUnknownRecord(item);
  let v1: unknown = readField(item, canonicalField);
  let v2: unknown = rule.value;

  if (rule.op === 'empty') return isEmptyValue(v1);
  if (rule.op === 'notEmpty') return !isEmptyValue(v1);

  // 优先使用预处理字段进行大小写无关的比较
  if (canonicalField === 'title') {
    v1 = readString(itemRecord, 'titleLower') ?? String(v1 ?? '').toLowerCase();
    v2 = String(v2 ?? '').toLowerCase();
  } else if (canonicalField === 'content') {
    v1 = readString(itemRecord, 'contentLower') ?? String(v1 ?? '').toLowerCase();
    v2 = String(v2 ?? '').toLowerCase();
  } else if (['goalPath', 'rootGoal', 'leafGoal'].includes(canonicalField)) {
    // Goal hierarchy uses one canonical path: normalize case and support in/notIn filters.
    v1 = String(v1 ?? '').toLowerCase();
    if (rule.op === 'in' || rule.op === 'notIn') {
      v2 = normalizeListValue(v2).map(value => String(value ?? '').toLowerCase());
    } else {
      v2 = String(v2 ?? '').toLowerCase();
    }
  } else if (canonicalField === 'fullData') {
    v1 = readString(itemRecord, 'fullDataLower') ?? String(v1 ?? '').toLowerCase();
    v2 = String(v2 ?? '').toLowerCase();
  } else if (canonicalField === 'tags') {
    const listLower: string[] = readStringArray(itemRecord, 'tagsLower').length
      ? readStringArray(itemRecord, 'tagsLower')
      : (Array.isArray(v1) ? v1.map(x => String(x).toLowerCase()) : []);
    const needle = String(v2 ?? '').toLowerCase();
    if (rule.op === 'includes' || rule.op === '=') {
      return listLower.includes(needle);
    }
    if (rule.op === '!=') {
      return !listLower.includes(needle);
    }
    if (rule.op === 'in' || rule.op === 'notIn') {
      const needles = normalizeListValue(v2).map(x => String(x).toLowerCase());
      const matched = needles.some(needleValue => listLower.includes(needleValue));
      return rule.op === 'in' ? matched : !matched;
    }
    // 其他操作回退为字符串比较
    v1 = listLower.join(',');
    v2 = needle;
  }

  switch (rule.op) {
    case '='   : return cmpMixed(v1, v2) === 0;
    case '!='  : return cmpMixed(v1, v2) !== 0;
    case 'includes': return Array.isArray(v1)
        ? v1.some(x => String(x).includes(String(v2)))
        : String(v1).includes(String(v2));
    case 'regex':
      try { return new RegExp(String(v2)).test(String(v1)); }
      catch { return false; }
    case '>'   : return cmpMixed(v1, v2) > 0;
    case '<'   : return cmpMixed(v1, v2) < 0;
    case 'in': {
      const values = Array.isArray(v2) ? v2 : normalizeListValue(v2);
      return values.some(value => cmpMixed(v1, value) === 0);
    }
    case 'notIn': {
      const values = Array.isArray(v2) ? v2 : normalizeListValue(v2);
      return !values.some(value => cmpMixed(v1, value) === 0);
    }
    case 'between': {
      const range = normalizeBetweenValue(v2);
      if (!range) return false;
      const [minValue, maxValue] = range;
      return cmpMixed(v1, minValue) >= 0 && cmpMixed(v1, maxValue) <= 0;
    }
    default    : return false;
  }
}

/* ---------- 排序 ---------- */
export function sortItems(items: RecordViewItem[], rules: SortRule[] = []) {
  if (!rules.length) return items;

  return [...items].sort((a, b) => {
    for (const r of rules) {
      const canonicalField = normalizeFieldKey(r.field);
      const av = readField(a, canonicalField);
      const bv = readField(b, canonicalField);

      // 统一将空值放到最后（升序），放到最前（降序）
      if (av == null && bv == null) continue;
      if (av == null) return r.dir === 'asc' ? 1 : -1;
      if (bv == null) return r.dir === 'asc' ? -1 : 1;

      const cmp = cmpMixed(av, bv);
      if (cmp !== 0) return r.dir === 'asc' ? cmp : -cmp;
    }
    return 0;
  });
}

/* ---------- 日期区间（仅保留有统一 date 的项） ---------- */
function isClosed(it: RecordViewItem) {
  if (it.recordType !== 'task') return false;
  return it.status === 'done' || it.status === 'cancelled' || it.status === 'skipped';
}

export function filterByDateRange(items: RecordViewItem[], startISO?: string, endISO?: string) {
  if (!startISO && !endISO) return items;

  // [修复] 结束日期需要按“当天结束”做包含式过滤：
  // - startISO / endISO 常以 'YYYY-MM-DD' 形式传入（无时间）
  // - Date.parse('YYYY-MM-DD') 解析到当天 00:00:00，直接比较会把“结束日当天”的带时间条目过滤掉
  const norm = (s: string) => (s || '').trim().replace(/\//g, '-');
  const isDateOnly = (s: string) => /^\d{4}-\d{1,2}-\d{1,2}$/.test(s);

  const sMs = startISO ? Date.parse(norm(startISO)) : null;
  const eMs = (() => {
    if (!endISO) return null;
    const n = norm(endISO);
    const t = Date.parse(n);
    if (isNaN(t)) return null;
    return isDateOnly(n) ? (t + 24 * 60 * 60 * 1000 - 1) : t;
  })();

  return items.filter(it => {
    const t = (it.dateMs ?? (it.date ? Date.parse((it.date || '').replace(/\//g, '-')) : NaN));

    // 没统一日期：已关闭→隐藏；未关闭→保留
    if (isNaN(t)) {
      return !isClosed(it);
    }
    if (sMs !== null && t < sMs) return false;
    if (eMs !== null && t > eMs) return false;
    return true;
  });
}

/* ---------- 关键字 ---------- */
export function filterByKeyword(items: RecordViewItem[], kw: string) {
  if (!kw.trim()) return items;
  const s = kw.trim().toLowerCase();
  return items.filter(it => {
    const itemRecord = asUnknownRecord(it);
    const titleLower = readString(itemRecord, 'titleLower') ?? (it.title || '').toLowerCase();
    const contentLower = readString(itemRecord, 'contentLower') ?? (it.content || '').toLowerCase();
    const fullDataLower = readString(itemRecord, 'fullDataLower') ?? (it.fullData || it.rawSource || '').toLowerCase();
    const tagsLower = (it.tags || []).join(' ').toLowerCase();
    const semanticText = [it.goalPath, it.recordType, it.status].filter(Boolean).join(' ').toLowerCase();
    // Global keyword search is intentionally broader than the canonical `content` field:
    // it may discover explicit Record KV/custom fields through fullData without polluting clean content semantics.
    return (titleLower + ' ' + contentLower + ' ' + fullDataLower + ' ' + tagsLower + ' ' + semanticText).includes(s);
  });
}

/* ---------- [新增] 周期字段过滤器 ---------- */
/**
 * 根据周期字段筛选项目。
 * @param items - 要筛选的项目数组。
 * @param period - 目标周期，例如 '年', '季', '月', '周', '天'。
 * @returns 筛选后的项目数组。一个项目如果满足以下任一条件，则会被保留：
 * 1. 它没有 `period` 字段。
 * 2. 它的 `period` 字段值与传入的 `period` 参数匹配。
 */
export function filterByPeriod(items: RecordViewItem[], period: string): RecordViewItem[] {
    if (!period) {
        return items;
    }
    return items.filter(item => {
        const itemPeriod = readField(item, 'period');
        // 如果项目没有周期属性，或者其周期与当前视图周期匹配，则保留
        return itemPeriod == null || itemPeriod === '' || itemPeriod === period;
    });
}
