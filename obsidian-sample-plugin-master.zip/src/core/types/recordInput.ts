import type { RecordCaptureTemplate } from '@/core/recordInput/CaptureTemplate';
import type { RecordViewItem } from '@/core/records/RecordEntity';
import type { EditableRecordSnapshot, RecordOutputPlan, RecordPersistencePlan } from './recordSnapshot';
import type { TaskSessionCreateInput } from './timer';

export type RecordOperation =
  | 'create'
  | 'update'
  | 'delete'
  | 'complete'
  | 'task_session'
  | 'time_update';

export type RecordSubmitStatus =
  | 'success'
  | 'validation_error'
  | 'conflict'
  | 'cancelled'
  | 'error'
  | 'partial_success';

export type RecordInputSource =
  | 'quickinput'
  | 'ai_batch'
  | 'timer'
  | 'view_quick_create'
  | 'layout_renderer'
  | 'unknown';

export interface RecordInputMeta {
  timeDirection?: 'forward' | 'backward';
}

export interface RecordSubmitIssue {
  code: string;
  message: string;
  field?: string;
}

export interface RecordSubmitResult {
  status: RecordSubmitStatus;
  operation: RecordOperation;
  affectedPath?: string;
  affectedRecordId?: string;
  refresh: {
    scanPaths: string[];
    notify: boolean;
  };
  feedback?: {
    notice?: string;
  };
  followUp?: {
    startTimerForRecordId?: string;
  };
  errors?: RecordSubmitIssue[];
  warnings?: RecordSubmitIssue[];
}

export type EntryKind = 'task' | 'block';

export interface EntryContext {
  entryKind: EntryKind;
  entryId: string;
  sourcePath?: string | null;
  sourceLine?: number | null;
  categoryKey?: string | null;
  openedFrom?: 'list' | 'detail' | 'search' | 'timeline' | 'quickinput' | 'timer' | 'unknown';
}

export interface PrepareCreateRecordParams {
  blockId?: string | null;
  context?: Record<string, unknown>;
  source?: RecordInputSource;
}

export interface PrepareEditRecordParams {
  item: RecordViewItem;
  blockId?: string | null;
  source?: Extract<RecordInputSource, 'quickinput' | 'timer' | 'unknown'>;
}

export interface PreparedCreateRecord {
  blockId: string | null;
  template: RecordCaptureTemplate | null;
  initialFormData: Record<string, unknown>;
  snapshot?: EditableRecordSnapshot | null;
  outputPlan?: RecordOutputPlan;
  persistencePlan?: RecordPersistencePlan;
  warnings: RecordSubmitIssue[];
}

export interface PreparedEditRecord {
  blockId: string | null;
  template: RecordCaptureTemplate | null;
  initialFormData: Record<string, unknown>;
  snapshot?: EditableRecordSnapshot | null;
  outputPlan?: RecordOutputPlan;
  persistencePlan?: RecordPersistencePlan;
  inferred: {
    usedFallbackBlock: boolean;
    canonicalBlockId?: string | null;
    templateSourceType?: 'record-type' | 'goal-template' | null;
    resolvedBy?: 'exact' | 'inferred' | 'fallback';
  };
  warnings: RecordSubmitIssue[];
}

export interface SubmitCreateRecordParams {
  blockId: string;
  formData: Record<string, unknown>;
  context?: Record<string, unknown>;
  meta?: {
    timeDirection?: 'forward' | 'backward';
  };
  signal?: AbortSignal;
  source?: Extract<RecordInputSource, 'quickinput' | 'ai_batch' | 'timer' | 'unknown' | 'view_quick_create'>;
}

export interface SubmitUpdateRecordParams {
  item: RecordViewItem;
  blockId: string;
  formData: Record<string, unknown>;
  meta?: {
    timeDirection?: 'forward' | 'backward';
  };
  expectedOutputPlan?: Pick<RecordOutputPlan, 'targetFilePath' | 'targetHeader'> | null;
  expectedPersistencePlan?: Pick<RecordPersistencePlan, 'originalPath' | 'pathChanged' | 'writeMode'> | null;
  signal?: AbortSignal;
  source?: Extract<RecordInputSource, 'quickinput' | 'unknown'>;
}

export interface SubmitDeleteRecordParams {
  item: RecordViewItem;
  signal?: AbortSignal;
  source?: Extract<RecordInputSource, 'quickinput' | 'unknown'>;
}

export interface SubmitCompleteRecordParams {
  itemId: string;
  session?: TaskSessionCreateInput;
  options?: {
    duration?: number;
    startTime?: string | null;
    endTime?: string | null;
  };
  signal?: AbortSignal;
  source?: Extract<RecordInputSource, 'timer' | 'layout_renderer' | 'unknown'>;
}

export interface SubmitTaskSessionParams {
  itemId: string;
  session: TaskSessionCreateInput;
  signal?: AbortSignal;
  source?: Extract<RecordInputSource, 'timer' | 'unknown'>;
}

export interface SubmitUpdateRecordTimeParams {
  itemId: string;
  updates: {
    time?: string | null;
    start?: string | null;
    endTime?: string | null;
    end?: string | null;
    duration?: number | string | null;
    date?: string | null;
    direction?: 'forward' | 'backward';
  };
  signal?: AbortSignal;
  source?: Extract<RecordInputSource, 'timer' | 'layout_renderer' | 'unknown'>;
}

export interface ResolveDependenciesResult {
  blockId: string | null;
  template: RecordCaptureTemplate | null;
  warnings: RecordSubmitIssue[];
  errors: RecordSubmitIssue[];
  meta: {
    templateId?: string | null;
    templateSourceType?: 'record-type' | 'goal-template' | null;
    usedFallbackBlock: boolean;
    canonicalBlockId?: string | null;
  };
}

export interface NormalizeRecordInputParams {
  template: RecordCaptureTemplate;
  formData: Record<string, unknown>;
  context?: Record<string, unknown>;
  mode: 'create' | 'edit' | 'ai_batch';
}

export interface NormalizeRecordInputResult {
  normalizedFormData: Record<string, unknown>;
  warnings: RecordSubmitIssue[];
}

export interface ValidateRecordInputParams {
  template: RecordCaptureTemplate | null;
  formData: Record<string, unknown>;
  mode: 'create' | 'edit' | 'delete' | 'complete' | 'time_update';
  item?: RecordViewItem;
}

export interface RecordValidationResult {
  ok: boolean;
  errors: RecordSubmitIssue[];
  warnings: RecordSubmitIssue[];
}
