// src/core/domain/cache.ts

import type { Item } from './schema';

/**
 * Cache schema v1
 *  - 轻量字段、按文件分片
 */
export interface CachedItem {
  id: string;
  filePath: string;
  filename?: string;

  // 热路径字段（预处理）
  titleLower?: string;
  contentLower?: string;
  tagsLower?: string[];
  themePathNormalized?: string;
  rootTheme?: string;
  leafTheme?: string;

  // 时间与分类
  dateMs?: number;
  categoryKey: string;

  // 基本冗余
  created: number;
  modified: number;
}

export interface CacheV1 {
  // NOTE: 版本号用于“缓存失效/重建”。
  // 我们允许它是 number，以便平滑升级时兼容历史文件。
  schemaVersion: number;
  files: Record<
    string,
    {
      mtime: number;
      size: number;
      items: CachedItem[];
    }
  >;
  indexes?: {
    byDateSorted?: Array<[number, string]>; // [dateMs, id]
    byTag?: Record<string, string[]>; // tagLower -> ids
    byTheme?: Record<string, string[]>; // themePathNormalized -> ids
  };
}

// v2: 主目的为一次性修复旧 cache 造成的“items=0/不刷新”问题（强制重新扫描）
export const CURRENT_CACHE_SCHEMA_VERSION = 2;

// 将运行时 Item 映射为 CachedItem（仅保存热字段）
export function toCachedItem(it: Item): CachedItem {
  return {
    id: it.id,
    filePath: it.file?.path || '',
    filename: it.filename ?? it.fileName,
    titleLower: it.title?.toLowerCase(),
    contentLower: it.content?.toLowerCase(),
    tagsLower: (it.tags || []).map(t => t.toLowerCase()),
    themePathNormalized: it.themePath ?? it.theme,
    rootTheme: it.rootTheme,
    leafTheme: it.leafTheme,
    dateMs: it.dateMs ?? it.startMs ?? it.endMs,
    categoryKey: it.categoryKey,
    created: it.created,
    modified: it.modified,
  };
}

// 将缓存的 CachedItem 恢复为最小可用的 Item（原文内容仍需懒加载时再读取）
export function fromCachedItem(c: CachedItem): Item {
  const it = {
    id: c.id,
    title: '', // 恢复后可按需懒加载原文
    content: '',
    type: 'task', // 具体类型需在解析时写入，这里保守给默认值；下游通常不会依赖该字段筛选
    tags: c.tagsLower || [],
    theme: c.themePathNormalized,
    themePath: c.themePathNormalized,
    rootTheme: c.rootTheme,
    leafTheme: c.leafTheme,
    categoryKey: c.categoryKey,
    recurrence: 'none',
    created: c.created,
    modified: c.modified,
    dateMs: c.dateMs,
    filename: c.filename,
    file: { path: c.filePath },
    extra: {},
  } as any;

  // 恢复预处理字段，避免启动后重复计算
  it.titleLower = c.titleLower ?? '';
  it.contentLower = c.contentLower ?? '';
  it.tagsLower = c.tagsLower ?? [];
  it.themePathNormalized = c.themePathNormalized;
  it.themePath = c.themePathNormalized;
  it.rootTheme = c.rootTheme;
  it.leafTheme = c.leafTheme;

  return it as Item;
}
