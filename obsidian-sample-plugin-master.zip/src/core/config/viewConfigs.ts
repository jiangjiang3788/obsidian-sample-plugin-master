// src/core/config/viewConfigs.ts
// 跨 Feature 的视图配置，避免 features 间的直接依赖

/**
 * StatisticsView 的默认配置
 * 从 features/settings 移动到 core，符合依赖约束规范
 */
export const STATISTICS_VIEW_DEFAULT_CONFIG = {
    categories: [] as { name: string; color: string; alias?: string; }[],
    displayMode: 'smart' as 'linear' | 'logarithmic' | 'smart',
    minVisibleHeight: 15, // 最小可见高度百分比
    usePeriodField: false, // 是否使用周期字段过滤
};

/**
 * HeatmapView 默认配置（供视图 + 编辑器复用）
 */
export interface HeatmapViewConfig {
    displayMode: 'habit' | 'count';
    sourceBlockId: string;
    themePaths: string[];
    maxDailyChecks: number;
    allowManualEdit: boolean;
}

export const HEATMAP_VIEW_DEFAULT_CONFIG: HeatmapViewConfig = {
    displayMode: 'habit',
    sourceBlockId: '',
    themePaths: [],
    maxDailyChecks: 10,
    allowManualEdit: true,
};


/**
 * ProgressView 默认配置（独立成长/积分视图）
 */
export interface ProgressViewConfig {
    basePoints: number;
    levelStep: number;
    includedCategories: string[];
    ratingBonusThreshold: number;
    ratingBonusPoints: number;
    showThemeBreakdown: boolean;
    showCategoryBreakdown: boolean;
    topN: number;
}

export const PROGRESS_VIEW_DEFAULT_CONFIG: ProgressViewConfig = {
    basePoints: 1,
    levelStep: 20,
    includedCategories: [],
    ratingBonusThreshold: 4,
    ratingBonusPoints: 1,
    showThemeBreakdown: true,
    showCategoryBreakdown: true,
    topN: 5,
};

/**
 * TaskExecutionView 默认配置（按主题分组的任务执行视图）
 */
export interface TaskExecutionViewConfig {
    onlyRecurring: boolean;
}

export const TASK_EXECUTION_VIEW_DEFAULT_CONFIG: TaskExecutionViewConfig = {
    onlyRecurring: true,
};

/**
 * TableView 默认配置（供视图 + 编辑器复用）
 */
export interface TableViewConfig {
    view: 'TableView';
    title: string;
    collapsed: boolean;
    rowField: string;
    colField: string;
}

export const TABLE_VIEW_DEFAULT_CONFIG: TableViewConfig = {
    view: 'TableView',
    title: '表格视图',
    collapsed: false,
    rowField: 'categoryKey',
    colField: 'date',
};

/**
 * TimelineView 默认配置（供视图 + 编辑器复用）
 */
export interface CategoryConfig {
    /**
     * Stable identifier used across aggregation / charting.
     * Keep it required to avoid `string | undefined` leaks throughout the UI.
     */
    name: string;
    color: string;
    files: string[];
    /** Optional display alias */
    alias?: string;
}

export interface TimelineViewConfig {
    defaultHourHeight: number;
    MAX_HOURS_PER_DAY: number;
    UNTRACKED_LABEL: string;
    categories: Record<string, CategoryConfig>;
    progressOrder: string[];
}

export const TIMELINE_VIEW_DEFAULT_CONFIG: TimelineViewConfig = {
    defaultHourHeight: 50,
    MAX_HOURS_PER_DAY: 24,
    UNTRACKED_LABEL: "未记录",
    categories: {
        "工作": { name: "工作", color: "#60a5fa", files: ["工作", "Work"] },
        "学习": { name: "学习", color: "#34d399", files: ["学习", "Study"] },
        "生活": { name: "生活", color: "#fbbf24", files: ["生活", "Life"] },
    },
    progressOrder: ["工作", "学习", "生活"],
};

/**
 * BlockView 默认配置（供视图 + 编辑器复用）
 */
export interface BlockViewConfig {
    view: 'BlockView';
    title: string;
    collapsed: boolean;
    fields: string[];
    group: string;
}

export const BLOCK_VIEW_DEFAULT_CONFIG: BlockViewConfig = {
    view: 'BlockView',
    title: '块视图',
    collapsed: false,
    fields: [],
    group: 'categoryKey',
};

/**
 * ExcelView 默认配置（供视图 + 编辑器复用）
 */
export interface ExcelViewConfig {
    view: 'ExcelView';
    title: string;
    collapsed: boolean;
    fields: string[];
}

export const EXCEL_VIEW_DEFAULT_CONFIG: ExcelViewConfig = {
    view: 'ExcelView',
    title: '数据表格',
    collapsed: false,
    fields: [],
};

/**
 * EventTimelineView 默认配置（供视图 + 编辑器复用）
 */
export interface EventTimelineViewConfig {
    timeField: string;
    titleField: string;
    contentField: string;
    groupByDay: boolean;
    showWeekday: boolean;
    maxContentLength: number;
    fields: string[];
    groupFields: string[];
}

export const EVENT_TIMELINE_VIEW_DEFAULT_CONFIG: EventTimelineViewConfig = {
    timeField: 'date',
    titleField: 'title',
    contentField: 'content',
    groupByDay: true,
    showWeekday: true,
    maxContentLength: 160,
    fields: ['title', 'date'],
    groupFields: [],
};

/**
 * 导出配置（供 exportUtils 使用）
 */
export interface FieldRenderConfig {
    /**
     * 字段展示类型：
     * - normal: 普通 "标签: 值"
     * - content: 多行内容字段，按行展开
     * - emojiOrLink: 纯 emoji 直接展示，否则转为 ![[ ]] 图片链接
     */
    type?: 'normal' | 'content' | 'emojiOrLink';
}

export interface ExportViewConfig {
    // 分组：例如 'filename' / 'date' / 'header' 等
    /** @deprecated 请使用 groupFields 支持多级分组 */
    groupField?: string;            // 旧：单字段分组
    groupFields?: string[];         // 新：多字段层级分组
    groupTitlePrefix?: string;      // 可选，比如空字符串
    useMarkdownHeadingForGroup: boolean; // 是否用 '## '

    // 每个记录的结构
    idTemplate: string;             // 例如 'ID {{index}}/{{filename}}#{{id}}'
    detailFields: string[];         // e.g. ['categoryKey', 'date', 'rating', 'pintu', 'content']

    // 字段标签映射（中文标签）
    fieldLabels: Record<string, string>; // { categoryKey: '分类', date: '日期', rating: '评分', pintu: '评图', content: '内容' }

    // 字段渲染规则（决定字段展示风格）
    fieldRender?: Record<string, FieldRenderConfig>;
}

export const BLOCK_EXPORT_DEFAULT_CONFIG: ExportViewConfig = {
    // 旧：groupField: 'filename',
    // 新：按 文件 → 分类 两级导出
    groupFields: ['filename', 'categoryKey'],
    groupTitlePrefix: '',
    useMarkdownHeadingForGroup: true,
    idTemplate: 'ID {{index}}/{{filename}}#{{id}}',
    detailFields: ['categoryKey', 'date', 'rating', 'pintu', 'content'],
    fieldLabels: {
        categoryKey: '分类',
        date: '日期',
        rating: '评分',
        pintu: '评图',
        content: '内容',
        fullData: '完整数据',
    },
    fieldRender: {
        pintu: { type: 'emojiOrLink' },
        content: { type: 'content' },
        fullData: { type: 'content' },
    },
};

/**
 * EventTimelineView 导出配置
 */
export const EVENT_TIMELINE_EXPORT_CONFIG: ExportViewConfig = {
    // 旧：groupField: 'date',
    // 新：按 日期 → 分类 两级导出
    groupFields: ['date', 'categoryKey'],
    groupTitlePrefix: '',
    useMarkdownHeadingForGroup: true,
    idTemplate: 'ID {{index}}/{{filename}}#{{id}}',
    detailFields: ['title', 'date', 'categoryKey', 'content'],
    fieldLabels: {
        title: '标题',
        date: '日期',
        categoryKey: '分类',
        content: '内容',
        fullData: '完整数据',
    },
    fieldRender: {
        content: { type: 'content' },
        fullData: { type: 'content' },
    },
};

/**
 * ExcelView 导出配置
 */
export const EXCEL_EXPORT_CONFIG: ExportViewConfig = {
    // 旧：groupField: 'categoryKey',
    // 新：按 分类 → 日期 两级导出
    groupFields: ['categoryKey', 'date'],
    groupTitlePrefix: '',
    useMarkdownHeadingForGroup: true,
    idTemplate: 'ID {{index}}/{{filename}}#{{id}}',
    detailFields: ['title', 'date', 'categoryKey', 'content'],
    fieldLabels: {
        title: '标题',
        date: '日期',
        categoryKey: '分类',
        content: '内容',
        fullData: '完整数据',
    },
    fieldRender: {
        content: { type: 'content' },
        fullData: { type: 'content' },
    },
};

/**
 * StatisticsView 导出配置 - 默认按Category分类
 */
export const STATISTICS_EXPORT_CONFIG: ExportViewConfig = {
    // 旧：groupField: 'categoryKey',
    // 新：按 周期 → 分类 两级导出
    groupFields: ['period', 'categoryKey'],
    groupTitlePrefix: '',
    useMarkdownHeadingForGroup: true,
    idTemplate: 'ID {{index}}/{{filename}}#{{id}}',
    detailFields: ['title', 'date', 'categoryKey', 'period', 'content'],
    fieldLabels: {
        title: '标题',
        date: '日期',
        categoryKey: '分类',
        period: '周期',
        content: '内容',
        fullData: '完整数据',
    },
    fieldRender: {
        content: { type: 'content' },
        fullData: { type: 'content' },
    },
};

/**
 * HeatmapView 导出配置
 */
export const HEATMAP_EXPORT_CONFIG: ExportViewConfig = {
    // 旧：groupField: 'date',
    // 新：按 日期 → 分类 两级导出
    groupFields: ['date', 'categoryKey'],
    groupTitlePrefix: '',
    useMarkdownHeadingForGroup: true,
    idTemplate: 'ID {{index}}/{{filename}}#{{id}}',
    detailFields: ['date', 'categoryKey', 'rating', 'content'],
    fieldLabels: {
        date: '日期',
        categoryKey: '分类',
        rating: '评分',
        content: '内容',
        fullData: '完整数据',
    },
    fieldRender: {
        content: { type: 'content' },
        fullData: { type: 'content' },
    },
};

/**
 * TimelineView 导出配置
 */
export const TIMELINE_EXPORT_CONFIG: ExportViewConfig = {
    // 旧：groupField: 'filename',
    // 新：按 文件 → 分类 两级导出
    groupFields: ['filename', 'categoryKey'],
    groupTitlePrefix: '',
    useMarkdownHeadingForGroup: true,
    idTemplate: 'ID {{index}}/{{filename}}#{{id}}',
    detailFields: ['title', 'startTime', 'endTime', 'duration', 'categoryKey', 'content'],
    fieldLabels: {
        title: '标题',
        startTime: '开始时间',
        endTime: '结束时间',
        duration: '时长',
        categoryKey: '分类',
        content: '内容',
        fullData: '完整数据',
    },
    fieldRender: {
        content: { type: 'content' },
        fullData: { type: 'content' },
    },
};

/**
 * TableView 导出配置
 */
export const TABLE_EXPORT_CONFIG: ExportViewConfig = {
    // 旧：groupField: 'categoryKey',
    // 新：按 分类 → 日期 两级导出
    groupFields: ['categoryKey', 'date'],
    groupTitlePrefix: '',
    useMarkdownHeadingForGroup: true,
    idTemplate: 'ID {{index}}/{{filename}}#{{id}}',
    detailFields: ['title', 'date', 'categoryKey', 'content'],
    fieldLabels: {
        title: '标题',
        date: '日期',
        categoryKey: '分类',
        content: '内容',
        fullData: '完整数据',
    },
    fieldRender: {
        content: { type: 'content' },
        fullData: { type: 'content' },
    },
};

// ============== VIEW_DEFAULT_CONFIGS 聚合导出 ==============
// 用于 store 层获取默认配置，避免 store 层依赖 features 层

import type { ViewName } from '@/core/types/schema';

/**
 * 视图默认配置映射表
 * 供 store/slices 使用，避免 store 层直接依赖 features/settings/registry
 */
export const VIEW_DEFAULT_CONFIGS: Record<ViewName, any> = {
    TableView: TABLE_VIEW_DEFAULT_CONFIG,
    BlockView: BLOCK_VIEW_DEFAULT_CONFIG,
    ExcelView: EXCEL_VIEW_DEFAULT_CONFIG,
    TimelineView: TIMELINE_VIEW_DEFAULT_CONFIG,
    EventTimelineView: EVENT_TIMELINE_VIEW_DEFAULT_CONFIG,
    StatisticsView: STATISTICS_VIEW_DEFAULT_CONFIG,
    HeatmapView: HEATMAP_VIEW_DEFAULT_CONFIG,
    ProgressView: PROGRESS_VIEW_DEFAULT_CONFIG,
    TaskExecutionView: TASK_EXECUTION_VIEW_DEFAULT_CONFIG,
};
