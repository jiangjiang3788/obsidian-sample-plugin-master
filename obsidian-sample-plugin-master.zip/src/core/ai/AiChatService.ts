// src/core/ai/AiChatService.ts
/**
 * AiChatService - AI 聊天服务
 * Role: Service (AI 请求逻辑)
 * 
 * Do:
 * - 使用 AiHttpClient 发送聊天请求
 * - 组织 prompt（system + context + user）
 * - 读取 aiSettings 配置
 * 
 * Don't:
 * - 管理会话状态（那是 ChatSessionStore 的职责）
 * - 管理检索索引（那是 RetrievalService 的职责）
 */

import { singleton, inject } from 'tsyringe';
import { AiHttpClient, OpenAIChatMessage } from './AiHttpClient';
import { RetrievalService, RetrievalFilters } from './RetrievalService';
import type { AiSettings } from '@/core/types/ai-schema';
import { DEFAULT_AI_SETTINGS } from '@/core/types/ai-schema';
import type { RecordViewItem } from '@/core/records/RecordEntity';
import type { ISettingsProvider } from '@/core/services/types';
import { SettingsProviderToken } from '@/core/services/types';
import { dayjs } from '@core/utils/date';
import { devLog, devError } from '../utils/devLogger';

// ============== Types ==============

export interface ChatRequest {
    /** 用户消息 */
    userMessage: string;
    /** 历史消息（可选，用于多轮对话） */
    history?: OpenAIChatMessage[];
    /** 是否启用上下文检索 */
    enableRetrieval?: boolean;
    /** 检索过滤条件 */
    retrievalFilters?: RetrievalFilters;
    /** 检索结果数量 */
    retrievalLimit?: number;
}

export interface ChatResponse {
    /** AI 回复内容 */
    content: string;
    /** 引用的 RecordViewItem ID 列表 */
    referencedItemIds: string[];
    /** 使用的模型 */
    model: string;
    /** 检索到的上下文数量 */
    retrievalCount: number;
}

// ============== Constants ==============

const SYSTEM_PROMPT = `你是一个个人工作记录助手，帮助用户查询和分析他们的工作记录、任务和笔记。

你的职责：
1. 根据用户的问题，从提供的上下文中找到相关信息并回答
2. 回答时要简洁明了，使用中文
3. 如果引用了某条记录，请提及其标题、日期或目标
4. 如果上下文中没有相关信息，诚实地说明
5. 可以对记录进行分析、统计或总结

输出格式要求（重要）：
- 默认使用 Markdown 格式输出
- 不要输出任何 HTML 标签
- 代码块使用 \`\`\`language 格式
- 列表使用 - 或 1. 2. 格式
- 强调使用 **粗体** 或 *斜体*
- 引用使用 > 格式
- 禁止在代码块之外使用任何 HTML 标签

注意：
- 回答基于用户提供的个人记录数据
- 保持专业、友好的语气
- 不要编造不存在的信息`;

const MAX_CONTEXT_LENGTH = 200000; // 上下文最大字符数（约100k tokens）

// ============== AiChatService ==============

@singleton()
export class AiChatService {
    private httpClient: AiHttpClient;

    constructor(
        @inject(SettingsProviderToken) private settingsProvider: ISettingsProvider,
        @inject(RetrievalService) private retrievalService: RetrievalService
    ) {
        this.httpClient = new AiHttpClient();
    }

    // ============== 获取配置 ==============

    private getAiSettings(): AiSettings {
        return this.settingsProvider.getSettings().aiSettings ?? DEFAULT_AI_SETTINGS;
    }
    
    // ============== 构建上下文 ==============

    /**
     * 从检索结果构建上下文字符串
     */
    private buildContextFromItems(items: RecordViewItem[]): string {
        if (!items || items.length === 0) {
            return '';
        }

        const contextParts: string[] = [];
        let totalLength = 0;

        for (const item of items) {
            // 格式化单条记录
            const date = item.dateMs ? dayjs(item.dateMs).format('YYYY-MM-DD') : '未知日期';
            const goalPath = item.goalPath || '未归属目标';
            const title = item.title || '无标题';
            const content = (item.content || '').slice(0, 5000); // 提高单条内容长度限制
            const type = item.recordType === 'task' ? '任务' : '记录';

            const entry = `- ${type} | ${date} | ${goalPath} | ${title}${content ? ': ' + content : ''}`;
            
            // 检查长度限制
            if (totalLength + entry.length > MAX_CONTEXT_LENGTH) {
                break;
            }

            contextParts.push(entry);
            totalLength += entry.length;
        }

        return contextParts.join('\n');
    }

    // ============== 发送请求 ==============

    /**
     * 发送聊天请求
     */
    /**
     * 发送 AI 请求
     * - signal 用于 modal 关闭/unload/takeLatest 等场景的取消
     */
    async chat(request: ChatRequest, signal?: AbortSignal): Promise<ChatResponse> {
        const settings = this.getAiSettings();

        if (!settings.enabled) {
            throw new Error('智能助手未启用，请在设置中开启');
        }

        if (!settings.apiEndpoint || !settings.apiKey || !settings.model) {
            throw new Error('智能助手配置不完整，请检查接口设置');
        }

        // 构建消息列表
        const messages: OpenAIChatMessage[] = [];
        
        // 1. System prompt
        messages.push({
            role: 'system',
            content: SYSTEM_PROMPT,
        });

        // 2. 上下文（如果启用检索）
        let referencedItemIds: string[] = [];
        let retrievalCount = 0;

        if (request.enableRetrieval) {
            const retrievalService = this.retrievalService;
            
            const filters = { ...request.retrievalFilters };

            const searchResult = retrievalService.search(request.userMessage, {
                ...filters,
                limit: request.retrievalLimit ?? 10000, // 默认不限制（使用较大值）
            });

            if (searchResult.items.length > 0) {
                const contextStr = this.buildContextFromItems(searchResult.items);
                referencedItemIds = searchResult.items.map(item => item.id);
                retrievalCount = searchResult.items.length;

                messages.push({
                    role: 'system',
                    content: `以下是与用户问题相关的个人记录（共 ${retrievalCount} 条）：\n\n${contextStr}\n\n请基于这些记录回答用户的问题。`,
                });

                devLog(`AiChatService: 检索到 ${retrievalCount} 条相关记录`);
            }
        }

        // 3. 历史消息
        if (request.history && request.history.length > 0) {
            // 按字符预算裁剪历史消息（约 50k tokens）
            const MAX_HISTORY_CHARS = 100000; // 粗略≈50k tokens（中英文混合估算）
            let totalChars = 0;
            const recentHistory: OpenAIChatMessage[] = [];

            for (let i = request.history.length - 1; i >= 0; i--) {
                const msg = request.history[i];
                const msgChars = JSON.stringify(msg).length;
                if (totalChars + msgChars > MAX_HISTORY_CHARS) break;
                recentHistory.unshift(msg);
                totalChars += msgChars;
            }

            messages.push(...recentHistory);
        }

        // 4. 用户消息
        messages.push({
            role: 'user',
            content: request.userMessage,
        });

        // 发送请求
        try {
            const content = await this.httpClient.chatCompletion({
                baseURL: settings.apiEndpoint,
                apiKey: settings.apiKey,
                model: settings.model,
                temperature: settings.temperature,
                max_tokens: settings.maxTokens,
                messages,
                timeoutMs: settings.requestTimeoutMs,
                signal,
            });

            return {
                content,
                referencedItemIds,
                model: settings.model,
                retrievalCount,
            };
        } catch (e: any) {
            devError('AiChatService: 请求失败', e);
            throw new Error(`智能助手请求失败：${e.message || e}`);
        }
    }

    /**
     * 简单问答（不带上下文检索）
     */
    async simpleChat(message: string): Promise<string> {
        const response = await this.chat({
            userMessage: message,
            enableRetrieval: false,
        });
        return response.content;
    }

    /**
     * 带检索的问答
     */
    async chatWithRetrieval(
        message: string,
        filters?: RetrievalFilters,
        history?: OpenAIChatMessage[]
    ): Promise<ChatResponse> {
        return this.chat({
            userMessage: message,
            enableRetrieval: true,
            retrievalFilters: filters,
            history,
        });
    }
}

// ============== 类型导出 ==============
// 注意：不再提供 getAiChatService() 全局导出
// 业务代码应通过 DI 注入或 Context 获取服务实例
// 仅在 composition root (Modal 构造函数、ServiceManager) 中允许 container.resolve()
