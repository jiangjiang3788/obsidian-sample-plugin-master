import type { NaturalRecordBatch, NaturalRecordCommand } from '@/core/types/ai-schema';
import { isSystemRecordContextField } from '@/core/goal';
import { asUnknownRecord, isUnknownRecord, readTrimmedString } from '../utils/unknownRecord';
import type { UnknownRecord } from '../utils/unknownRecord';
import type { AiParserSnapshot, AiSnapshotRecordType, AiSnapshotGoal, AiSnapshotPreset } from './AiParserSnapshot';

type AiCommandTarget = NaturalRecordCommand['target'] & UnknownRecord;
type AiParsedCommand = NaturalRecordCommand & { target: AiCommandTarget; fieldValues: Record<string, unknown> };

function ensureCommandTarget(item: Partial<NaturalRecordCommand> & { target?: unknown }): AiCommandTarget {
  if (!isUnknownRecord(item.target)) item.target = { recordTypeId: '' };
  const target = item.target as AiCommandTarget;
  if (typeof target.recordTypeId !== 'string') target.recordTypeId = '';
  return target;
}

export function cleanAiFieldValues(values: unknown): Record<string, unknown> {
  const result: Record<string, unknown> = {};
  const record = asUnknownRecord(values);
  if (!record) return result;
  for (const [key, value] of Object.entries(record)) {
    if (isSystemRecordContextField(key)) continue;
    result[key] = value;
  }
  return result;
}

function targetString(target: UnknownRecord, key: string): string {
  return readTrimmedString(target, key) ?? '';
}

function findRecordTypeByTarget(snapshot: AiParserSnapshot, target: UnknownRecord): AiSnapshotRecordType | null {
  const recordTypes = snapshot.recordTypes ?? [];
  const recordTypeId = targetString(target, 'recordTypeId');
  return recordTypes.find((recordType) => recordType.id === recordTypeId || recordType.name === recordTypeId) || null;
}

function findGoalByTarget(snapshot: AiParserSnapshot, target: UnknownRecord): AiSnapshotGoal | null {
  const path = targetString(target, 'goalPath');
  return (snapshot.goals ?? []).find((goal) => goal.path === path) || null;
}

function findPresetByTarget(snapshot: AiParserSnapshot, target: UnknownRecord): AiSnapshotPreset | null {
  const presets = snapshot.goalPresets ?? [];
  const explicitId = targetString(target, 'goalTemplateId') || targetString(target, 'templateId');
  if (explicitId) {
    const exact = presets.find((preset) => preset.id === explicitId || preset.goalTemplateId === explicitId);
    if (exact) return exact;
  }
  const goalPath = targetString(target, 'goalPath');
  const recordTypeId = targetString(target, 'recordTypeId');
  return presets.find((preset) => {
    const goalMatches = !goalPath || preset.goalPath === goalPath;
    const recordTypeMatches = !recordTypeId || preset.recordTypeId === recordTypeId;
    return goalMatches && recordTypeMatches;
  }) || null;
}

export function normalizeParsedBatch(
  batch: NaturalRecordBatch,
  snapshot: AiParserSnapshot,
  rawText: string,
): NaturalRecordBatch {
  if (!batch.items) batch.items = [];
  batch.items.forEach((item) => {
    const parsedItem = item as AiParsedCommand;
    if (!parsedItem.rawText) parsedItem.rawText = rawText;
    const target = ensureCommandTarget(parsedItem);
    parsedItem.fieldValues = cleanAiFieldValues(parsedItem.fieldValues);

    const preset = findPresetByTarget(snapshot, target);
    if (preset) {
      target.goalTemplateId = preset.goalTemplateId || preset.id;
      target.goalPath = preset.goalPath || target.goalPath;
      target.recordTypeId = preset.recordTypeId || target.recordTypeId;
    }

    const recordType = findRecordTypeByTarget(snapshot, target);
    if (recordType) {
      target.recordTypeId = target.recordTypeId || recordType.id || '';
    }

    const goal = findGoalByTarget(snapshot, target);
    if (goal) target.goalPath = target.goalPath || goal.path;

  });
  return batch;
}
