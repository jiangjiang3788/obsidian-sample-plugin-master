/** @jsxImportSource preact */
/**
 * ThemeMatrixView - 纯视图组件（不直接订阅 store）
 * Round3: 容器/视图分离；容器负责 selectors/useCases/dataStore 注入。
 */
import { h } from 'preact';
import { AddIcon, Box, Button, Stack, TextField, Typography } from '@shared/public';
import { useState, useMemo } from 'preact/hooks';
import { TemplateEditorModal } from '@features/settings/input/TemplateEditorModal';
import type { BlockTemplate, ThemeDefinition, ThemeOverride } from '@core/public';
import { ThemeMatrixService, ThemeScanService, buildThemePathTree, flattenThemePathTree } from '@core/public';
import type { ThemePathTreeNode, ThemePathTreeFlatNode as ThemeTreeNode } from '@core/public';

import { ThemeToolbar } from './ThemeToolbar';
import { ContextualToolbar } from './ContextualToolbar';
import { ThemeTable } from './ThemeTable';
import { ThemeImportButton } from './ThemeImportButton';
import { useThemeMatrixEditor } from './useThemeMatrixEditor';
import { useBatchOperations, type BatchOperation } from './useBatchOperations';

export interface ThemeMatrixViewProps {
    blocks: any[];
    themes: any[];
    overrides: any[];
    settings: any;
    useCases: any;
    dataStore: any;
}

export function ThemeMatrixView({ blocks, themes, overrides, settings, useCases, dataStore }: ThemeMatrixViewProps) {
    
    // 【UI 临时态】这些状态不写入 settings
    const [newThemePath, setNewThemePath] = useState('');
    const [modalOpen, setModalOpen] = useState(false);
    const [modalData, setModalData] = useState<{ block: BlockTemplate; theme: ThemeDefinition; override: ThemeOverride | null } | null>(null);
    const [expandedNodes, setExpandedNodes] = useState<Set<string>>(new Set());
    const [showArchived, setShowArchived] = useState(false);
    
    // 新的编辑器状态 Hook（UI 临时态）
    const {
        editorState,
        toggleEditMode,
        handleSelectionChange,
        clearSelection,
        getSelectionStats,
        handleSelectAll,
        handleSelectBlockColumn,
    } = useThemeMatrixEditor();

    // 批量操作 Hook - 通过 useUseCases 获取
    const { executeBatchOperation, isProcessing } = useBatchOperations({
        onOperationComplete: clearSelection,
    });
    
    // 【P0-5】ThemeMatrixService - 只用于读/计算，已移除 writeOps
    const themeService = useMemo(() => new ThemeMatrixService({
        getSettings: () => settings,
    }), [settings]);
    
    // 【P0-5】ThemeScanService - 只用于扫描/预览，已移除 writeOps
    const themeScanService = useMemo(() => new ThemeScanService({ 
        getSettings: () => settings,
        dataStore, 
    }), [settings, dataStore]);
    
    // 获取扩展的主题信息
    const extendedThemes = useMemo(() => {
        return themeService.getExtendedThemes(themes);
    }, [themes, themeService]);
    
    // 提取所有主题ID，用于全选操作
    const allThemeIds = useMemo(() => extendedThemes.map(t => t.id), [extendedThemes]);
    
    // 构建主题路径树（统一 builder / 无 legacy wrapper）
    // 说明：
    // - ThemeMatrix 只关心“真实主题节点”（不需要虚节点分组），因此 createVirtualNodes=false
    // - level/expanded 不再写进节点（SSOT 是 expandedNodes Set），由 flattenThemePathTree 计算可见性与展开态
    const themeTreeRoots = useMemo(() => {
        return buildThemePathTree(extendedThemes, { createVirtualNodes: false, sortBy: 'order' });
    }, [extendedThemes]);

    // 将“themeId 展开集合”映射到 “node.id（path）展开集合”，供 flattenThemePathTree 使用
    const expandedPathIds = useMemo(() => {
        const set = new Set<string>();
        const walk = (nodes: ThemePathTreeNode[]) => {
            for (const n of nodes) {
                if (n.themeId && expandedNodes.has(n.themeId)) {
                    set.add(n.id);
                }
                if (n.children && n.children.length > 0) {
                    walk(n.children);
                }
            }
        };
        walk(themeTreeRoots);
        return set;
    }, [themeTreeRoots, expandedNodes]);

    // 扁平化（只保留“可见节点”），用于 Table 直出渲染，避免递归渲染 helpers
    const flatVisibleNodes = useMemo(() => {
        return flattenThemePathTree(themeTreeRoots, expandedPathIds).filter(n => n.visible);
    }, [themeTreeRoots, expandedPathIds]);

    // 分组主题（目前 active/inactive 都先放在同一组；archived 预留）
    const { activeThemes, archivedThemes } = useMemo(() => {
        return { activeThemes: flatVisibleNodes, archivedThemes: [] as ThemeTreeNode[] };
    }, [flatVisibleNodes]);
    
    const overridesMap = useMemo(() => {
        const map = new Map<string, ThemeOverride>();
        overrides.forEach(o => map.set(`${o.themeId}:${o.blockId}`, o));
        return map;
    }, [overrides]);
    
    // 处理节点展开/折叠（UI 临时态）
    const handleToggleExpand = (themeId: string) => {
        const newExpanded = new Set(expandedNodes);
        if (newExpanded.has(themeId)) {
            newExpanded.delete(themeId);
        } else {
            newExpanded.add(themeId);
        }
        setExpandedNodes(newExpanded);
    };
    
    // 【S6】添加主题 - 通过 useCases.theme
    const handleAddTheme = () => {
        const path = newThemePath.trim();
        if (path && !themes.some(t => t.path === path)) {
            useCases.theme.addTheme(path);
            setNewThemePath('');
        }
    };
    
    const handleCellClick = (block: BlockTemplate, theme: ThemeDefinition) => {
        // 在编辑模式下，点击单元格是用于选择，而不是打开模态框
        if (editorState.mode === 'edit') {
            const cellId = `${theme.id}:${block.id}`;
            const isSelected = editorState.selectedCells.has(cellId);
            handleSelectionChange('block', cellId, !isSelected);
            return;
        }
        // 只有在预览模式下才打开编辑器
        const override = overridesMap.get(`${theme.id}:${block.id}`) || null;
        setModalData({ block, theme, override });
        setModalOpen(true);
    };


    const handleReorderThemeSiblings = async (orderedThemeIds: string[], parentKey?: string) => {
        if (!orderedThemeIds || orderedThemeIds.length === 0) return;
        await useCases.theme.reorderThemeSiblings(orderedThemeIds, parentKey);
    };

    const handleBatchAction = (operation: BatchOperation) => {
        const { selectionType, selectedThemes, selectedCells } = editorState;

        if (selectionType === 'theme') {
            executeBatchOperation({
                operation,
                themeIds: Array.from(selectedThemes),
            });
        } else if (selectionType === 'block') {
            executeBatchOperation({
                operation,
                cellIds: Array.from(selectedCells),
            });
        }
    };

    // 主题扫描处理函数（纯读操作，由 service 提供）
    const handleThemeScan = async (config: any) => {
        return await themeScanService.scanThemesFromData(config);
    };

    // 【P0-5】主题导入处理函数 - 通过 useCases.theme 执行写入
    const handleThemeImport = async (themePaths: string[]) => {
        // 使用 service 过滤可导入的主题
        const importableThemes = themeScanService.getImportableThemes(themePaths);
        
        let imported = 0;
        let skipped = themePaths.length - importableThemes.length;
        const errors: string[] = [];
        
        // 通过 useCases.theme.addTheme 执行写入
        for (const path of importableThemes) {
            try {
                await useCases.theme.addTheme(path);
                imported++;
            } catch (error) {
                errors.push(`导入主题 "${path}" 失败: ${error}`);
            }
        }
        
        return { imported, skipped, failed: errors.length, errors };
    };

    return (
        <Box sx={{ width: '100%', maxWidth: '100%', mx: 0, px: 1, py: 1 }}>
            <Typography variant="h5" gutterBottom sx={{ mb: 1 }}>
                主题配置矩阵
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 1.25 }}>
                管理不同主题对各类Block的配置。进入编辑模式以进行批量操作。
            </Typography>
            
            {/* 工具栏 */}
            <ThemeToolbar
                mode={editorState.mode}
                onToggleEditMode={toggleEditMode}
            />
            
            <ContextualToolbar
                editorState={editorState}
                onAction={handleBatchAction}
                onClearSelection={clearSelection}
            />

            {/* 主题表格 */}
            <Box sx={{ overflowX: 'auto', width: '100%' }}>
            <ThemeTable
                blocks={blocks}
                activeThemes={activeThemes}
                archivedThemes={archivedThemes}
                showArchived={showArchived}
                overridesMap={overridesMap}
                editorState={editorState}
                onCellClick={handleCellClick}
                onToggleExpand={handleToggleExpand}
                onSelectionChange={handleSelectionChange}
                onSelectAllThemes={(isSelected: boolean) => handleSelectAll(allThemeIds, isSelected)}
                onSelectBlockColumn={(blockId: string, isSelected: boolean) => handleSelectBlockColumn(blockId, allThemeIds, isSelected)}
                onReorderThemeSiblings={handleReorderThemeSiblings}
                useCases={useCases}
            />
            </Box>
            
            {/* 添加新主题 */}
            <Stack direction="row" spacing={1} alignItems="center" sx={{ mt: 1.25 }}>
                <TextField 
                    placeholder="新主题路径 (如: 个人/习惯)" 
                    value={newThemePath} 
                    onChange={(e: any) => setNewThemePath((e.target as HTMLInputElement).value)} 
                    onKeyDown={(e: any) => e.key === 'Enter' && handleAddTheme()} 
                    size="small" 
                    variant="outlined" 
                    sx={{ flexGrow: 1, maxWidth: '320px' }} 
                />
                <Button onClick={handleAddTheme} variant="outlined" size="small" startIcon={<AddIcon />}>
                    添加主题
                </Button>
                
                <ThemeImportButton 
                    onScan={handleThemeScan}
                    onImport={handleThemeImport}
                />
            </Stack>
            
            {/* 模板编辑器模态框 */}
            {modalData && (
                <TemplateEditorModal 
                    isOpen={modalOpen} 
                    onClose={() => setModalOpen(false)} 
                    block={modalData.block} 
                    theme={modalData.theme} 
                    existingOverride={modalData.override} 
                    useCases={useCases}
                />
            )}
        </Box>
    );
}
