// src/features/dashboard/ui/ModulePanel.tsx
/** @jsxImportSource preact */
import { h } from 'preact';
// [新增] 导入 IconButton, Tooltip 和图标
import { IconButton, Tooltip } from '@mui/material';
import { DeleteOutlineIcon, IosShareIcon, SettingsIcon } from '@shared/public';

// 解决 Preact 和 Material-UI 的类型兼容性问题
const AnyIconButton = IconButton as any;


export interface ModulePanelProps {
    title: string;
    collapsed?: boolean;
    children: any;
    onActionClick?: () => void;
    onToggle?: (e: MouseEvent) => void;
    onExport?: () => void; // [新增] 导出按钮的回调函数
    onSettingsClick?: () => void; // [新增] 设置按钮的回调函数
    onRemove?: () => void; // [新增] 删除模块
}

export function ModulePanel({ title, collapsed, children, onActionClick, onToggle, onExport, onSettingsClick, onRemove }: ModulePanelProps) {
    const onHeaderClick = (e: MouseEvent) => {
        if ((e.target as HTMLElement).closest('.module-header-actions')) {
            return;
        }
        onToggle?.(e);
    };

    return (
        <div class="think-module">
            <div class="module-header" onClick={onHeaderClick as any} title="点击折叠/展开；Ctrl/⌘ + 点击：全部折叠/展开">
                <span class="module-title">{title}</span>
                <div class="module-header-controls">
                    <div class="module-header-actions">
                        {/* [新增] 删除按钮 */}
                        {onRemove && (
                            <Tooltip title="删除视图（从配置与所有布局中移除）">
                                <AnyIconButton
                                    size="small"
                                    onClick={(e: any) => {
                                        e.stopPropagation();
                                        onRemove();
                                    }}
                                    sx={{ padding: '4px' }}
                                >
                                    <DeleteOutlineIcon sx={{ fontSize: '1rem' }} />
                                </AnyIconButton>
                            </Tooltip>
                        )}
                        {/* [新增] 设置按钮 */}
                        {onSettingsClick && (
                            <Tooltip title="模块设置">
                                <AnyIconButton
                                    size="small"
                                    onClick={(e: any) => {
                                        e.stopPropagation();
                                        onSettingsClick();
                                    }}
                                    sx={{ padding: '4px' }}
                                >
                                    <SettingsIcon sx={{ fontSize: '1rem' }} />
                                </AnyIconButton>
                            </Tooltip>
                        )}
                        {/* [新增] 导出按钮 */}
                        {onExport && (
                            <Tooltip title="导出为 Markdown">
                                <AnyIconButton
                                    size="small"
                                    onClick={(e: any) => {
                                        e.stopPropagation();
                                        onExport();
                                    }}
                                    sx={{ padding: '4px' }}
                                >
                                    <IosShareIcon sx={{ fontSize: '1rem' }} />
                                </AnyIconButton>
                            </Tooltip>
                        )}
                        {onActionClick ? (
                            <span 
                                class="module-action-plus" 
                                title="创建记录"
                                onClick={(e) => {
                                    e.stopPropagation(); // 阻止事件冒泡到 header 的 onClick
                                    onActionClick();
                                }}
                            >
                                +
                            </span>
                        ) : null}
                    </div>
                    <div class="module-toggle">{collapsed ? '▶' : '▼'}</div>
                </div>
            </div>
            {!collapsed && <div class="module-content">{children}</div>}
        </div>
    );
}
