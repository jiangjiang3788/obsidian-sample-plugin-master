/** @jsxImportSource preact */
import { h } from 'preact';
import { useMemo } from 'preact/hooks';
import {
  ThinkButton,
  ThinkIcon,
  ThinkMultiCombobox,
  type ThinkComboboxOption,
} from '@shared/ui/public';
import type { DataStore } from '@core/services/public';
import type { FilterRule, RecordViewItem } from '@core/types/public';
import { getAllFields, readField } from '@core/types/public';
import { formatFieldValue, getFieldLabel } from '@core/fields/public';
import { normalizeViewFieldKey, normalizeViewMultiValue } from '@core/view/public';
import { compareRecordTypeKeys } from '@core/recordTypes/public';

interface QuickFilterField {
  field: string;
  label?: string;
  placeholder?: string;
}

interface CommonFilterPanelProps {
  dataStore: DataStore;
  filters: FilterRule[];
  onChange: (filters: FilterRule[]) => void;
  items?: RecordViewItem[];
  fieldOptions?: string[];
  title?: string;
  fields?: QuickFilterField[];
  compact?: boolean;
  showHeader?: boolean;
}

export const DEFAULT_QUICK_FILTER_FIELDS: QuickFilterField[] = [
  { field: 'goalPath', label: '目标', placeholder: '选择目标' },
  { field: 'recordType', label: '记录类型', placeholder: '选择记录类型' },
  { field: 'status', label: '状态', placeholder: '选择状态' },
  { field: 'cadence', label: '任务周期', placeholder: '选择任务周期' },
  { field: 'priority', label: '优先级', placeholder: '选择优先级' },
  { field: 'period.label', label: '周期', placeholder: '选择周期' },
];

const DEFAULT_QUICK_FILTER_FIELD_SET = new Set(
  DEFAULT_QUICK_FILTER_FIELDS.map(config => normalizeViewFieldKey(config.field))
);

export function isDefaultQuickFilterRule(rule: FilterRule): boolean {
  return rule.op === 'in' && DEFAULT_QUICK_FILTER_FIELD_SET.has(normalizeViewFieldKey(rule.field));
}

export function splitDefaultQuickFilterRules(filters: FilterRule[]): { quickRules: FilterRule[]; advancedRules: FilterRule[] } {
  const quickRules: FilterRule[] = [];
  const advancedRules: FilterRule[] = [];
  filters.forEach(rule => (isDefaultQuickFilterRule(rule) ? quickRules : advancedRules).push(rule));
  return { quickRules, advancedRules };
}


function collectFieldValues(items: RecordViewItem[], fields: string[]): Record<string, string[]> {
  const valueMap: Record<string, Set<string>> = {};
  fields.forEach(field => valueMap[normalizeViewFieldKey(field)] = new Set<string>());

  for (const item of items) {
    for (const rawField of fields) {
      const field = normalizeViewFieldKey(rawField);
      const value = readField(item, field);
      if (value === null || value === undefined || String(value).trim() === '') continue;
      const values = Array.isArray(value) ? value : [value];
      values.forEach(v => {
        const strV = String(v).trim();
        if (strV) valueMap[field].add(strV);
      });
    }
  }

  const result: Record<string, string[]> = {};
  fields.forEach(rawField => {
    const field = normalizeViewFieldKey(rawField);
    result[field] = Array.from(valueMap[field] || []).sort(field === 'recordType' ? compareRecordTypeKeys : (a, b) => a.localeCompare(b, 'zh-CN'));
  });
  return result;
}

function cleanupRuleLinks(rules: FilterRule[]): FilterRule[] {
  return rules.map((rule, index) => {
    const nextRule: FilterRule = { ...rule };
    if (index === rules.length - 1) {
      delete (nextRule as any).logic;
    } else if (!nextRule.logic) {
      nextRule.logic = 'and';
    }
    return nextRule;
  });
}

function getQuickRule(filters: FilterRule[], field: string): FilterRule | undefined {
  const normalizedField = normalizeViewFieldKey(field);
  return filters.find(rule => normalizeViewFieldKey(rule.field) === normalizedField && rule.op === 'in');
}

function upsertQuickRule(filters: FilterRule[], field: string, values: string[]): FilterRule[] {
  const cleanValues = normalizeViewMultiValue(values);
  const normalizedField = normalizeViewFieldKey(field);
  const existingIndex = filters.findIndex(rule => normalizeViewFieldKey(rule.field) === normalizedField && rule.op === 'in');

  if (cleanValues.length === 0) {
    if (existingIndex < 0) return cleanupRuleLinks(filters);
    return cleanupRuleLinks(filters.filter((_, index) => index !== existingIndex));
  }

  if (existingIndex >= 0) {
    return cleanupRuleLinks(filters.map((rule, index) => (
      index === existingIndex ? { ...rule, field: normalizedField, value: cleanValues } : { ...rule }
    )));
  }

  return cleanupRuleLinks([
    ...filters.map(rule => ({ ...rule })),
    { field: normalizedField, op: 'in', value: cleanValues },
  ]);
}

function hasAnyQuickFilter(filters: FilterRule[], fields: QuickFilterField[]): boolean {
  const fieldSet = new Set(fields.map(f => normalizeViewFieldKey(f.field)));
  return filters.some(rule => fieldSet.has(normalizeViewFieldKey(rule.field)) && rule.op === 'in' && normalizeViewMultiValue(rule.value).length > 0);
}

function clearQuickFilters(filters: FilterRule[], fields: QuickFilterField[]): FilterRule[] {
  const fieldSet = new Set(fields.map(f => normalizeViewFieldKey(f.field)));
  return cleanupRuleLinks(filters.filter(rule => !(fieldSet.has(normalizeViewFieldKey(rule.field)) && rule.op === 'in')));
}


export function CommonFilterPanel({
  dataStore,
  filters,
  onChange,
  items,
  fieldOptions,
  title = '常用筛选',
  fields = DEFAULT_QUICK_FILTER_FIELDS,
  compact = false,
  showHeader = true,
}: CommonFilterPanelProps) {
  const sourceItems = useMemo(() => items ?? dataStore.queryItems(), [items, dataStore]);
  const availableFields = useMemo(() => new Set((fieldOptions ?? getAllFields(sourceItems)).map(normalizeViewFieldKey)), [fieldOptions, sourceItems]);
  const quickFields = useMemo(
    () => fields
      .map(config => ({ ...config, field: normalizeViewFieldKey(config.field) }))
      .filter((config, index, array) => config.field && availableFields.has(config.field) && array.findIndex(item => item.field === config.field) === index),
    [fields, availableFields]
  );
  const valueOptions = useMemo(
    () => collectFieldValues(sourceItems, quickFields.map(config => config.field)),
    [sourceItems, quickFields]
  );
  const hasQuickFilters = hasAnyQuickFilter(filters, quickFields);

  if (quickFields.length === 0) return null;

  return (
    <div className={`think-common-filter${compact ? ' think-common-filter--compact' : ''}`}>
      {showHeader && (
        <div className="think-common-filter__header">
          <span className="think-common-filter__title">{title}</span>
          <ThinkButton
            size="sm"
            variant="secondary"
            leadingIcon={<ThinkIcon name="rotate-ccw" />}
            onClick={() => onChange(clearQuickFilters(filters, quickFields))}
            disabled={!hasQuickFilters}
            className="think-common-filter__clear"
          >
            清空
          </ThinkButton>
        </div>
      )}

      <div className="think-common-filter__grid">
        {quickFields.map(config => {
          const label = config.label || getFieldLabel(config.field);
          const rule = getQuickRule(filters, config.field);
          const values = normalizeViewMultiValue(rule?.value);

          return (
            <div key={config.field} className="think-common-filter__field">
              <span className="think-common-filter__label">{label}</span>
              <ThinkMultiCombobox
                values={values}
                options={Array.from(new Set([
                  ...(valueOptions[normalizeViewFieldKey(config.field)] || []),
                  ...values,
                ])).map((value): ThinkComboboxOption => ({
                  value,
                  label: formatFieldValue(config.field, value),
                }))}
                onChange={(newValues) => onChange(upsertQuickRule(filters, config.field, newValues))}
                placeholder={config.placeholder || `选择${label}`}
                allowCustom={config.field !== 'recordType'}
              />
            </div>
          );
        })}
      </div>
    </div>
  );
}
