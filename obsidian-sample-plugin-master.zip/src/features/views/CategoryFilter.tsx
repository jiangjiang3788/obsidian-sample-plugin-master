/** @jsxImportSource preact */
import { h } from 'preact';
import { useState, useMemo } from 'preact/hooks';
import { 
    Popover, 
    FormGroup, 
    FormControlLabel, 
    Checkbox, 
    Button,
    Box,
    Typography,
    Chip,
    IconButton
} from '@mui/material';
import FilterListIcon from '@mui/icons-material/FilterList';
import type { ViewInstance } from '@/core/types/schema';
import { collectCategoriesFromViews } from '@core/utils/itemGrouping';

// Type compatibility
const AnyButton = Button as any;
const AnyPopover = Popover as any;
const AnyBox = Box as any;
const AnyTypography = Typography as any;
const AnyChip = Chip as any;
const AnyFormGroup = FormGroup as any;
const AnyFormControlLabel = FormControlLabel as any;
const AnyCheckbox = Checkbox as any;

interface CategoryFilterProps {
    selectedCategories: string[];
    onSelectionChange: (categories: string[]) => void;
    viewInstances: ViewInstance[];
    predefinedCategories?: string[];
}

export function CategoryFilter({ selectedCategories, onSelectionChange, viewInstances, predefinedCategories = [] }: CategoryFilterProps) {
    const [anchorEl, setAnchorEl] = useState<HTMLElement | null>(null);

    const allCategories = useMemo(() => {
        return collectCategoriesFromViews(viewInstances, predefinedCategories);
    }, [viewInstances, predefinedCategories]);

    const handleClick = (event: any) => {
        setAnchorEl(event.currentTarget);
    };

    const handleClose = () => {
        setAnchorEl(null);
    };

    const handleToggleCategory = (categoryName: string) => {
        const newSelection = selectedCategories.includes(categoryName)
            ? selectedCategories.filter(c => c !== categoryName)
            : [...selectedCategories, categoryName];
        onSelectionChange(newSelection);
    };

    const handleSelectAll = () => {
        onSelectionChange(allCategories);
    };

    const handleClearAll = () => {
        onSelectionChange([]);
    };

    const open = Boolean(anchorEl);
    const selectedCount = selectedCategories.length;
    const totalCount = allCategories.length;

    return (
        <div class="category-filter-container">
            <AnyButton
                size="small"
                variant={selectedCount > 0 && selectedCount < totalCount ? 'contained' : 'outlined'}
                startIcon={<FilterListIcon />}
                onClick={handleClick}
                sx={{ textTransform: 'none' }}
            >
                分类筛选 {selectedCount > 0 && selectedCount < totalCount && `(${selectedCount}/${totalCount})`}
            </AnyButton>

            {selectedCount > 0 && selectedCount < totalCount && (
                <div class="selected-categories-list">
                    {selectedCategories.slice(0, 3).map(cat => (
                        <AnyChip
                            key={cat}
                            label={cat}
                            size="small"
                            onDelete={() => handleToggleCategory(cat)}
                            sx={{ height: '20px', fontSize: '0.75rem' }}
                        />
                    ))}
                    {selectedCategories.length > 3 && (
                        <AnyChip
                            label={`+${selectedCategories.length - 3}`}
                            size="small"
                            sx={{ height: '20px', fontSize: '0.75rem' }}
                        />
                    )}
                </div>
            )}

            <AnyPopover
                open={open}
                anchorEl={anchorEl}
                onClose={handleClose}
                anchorOrigin={{
                    vertical: 'bottom',
                    horizontal: 'left',
                }}
                transformOrigin={{
                    vertical: 'top',
                    horizontal: 'left',
                }}
            >
                <AnyBox sx={{ p: 2, minWidth: '250px', maxWidth: '400px', maxHeight: '500px', overflowY: 'auto' }}>
                    <AnyTypography variant="subtitle2" gutterBottom>
                        选择要显示的分类
                    </AnyTypography>
                    
                    <AnyBox sx={{ mb: 1, display: 'flex', gap: 1 }}>
                        <AnyButton size="small" onClick={handleSelectAll}>
                            全选
                        </AnyButton>
                        <AnyButton size="small" onClick={handleClearAll}>
                            清空
                        </AnyButton>
                    </AnyBox>

                    {allCategories.length === 0 ? (
                        <AnyTypography variant="body2" color="text.secondary" sx={{ py: 2 }}>
                            暂无分类
                        </AnyTypography>
                    ) : (
                        <AnyFormGroup>
                            {allCategories.map(cat => (
                                <AnyFormControlLabel
                                    key={cat}
                                    control={
                                        <AnyCheckbox
                                            size="small"
                                            checked={selectedCategories.includes(cat)}
                                            onChange={() => handleToggleCategory(cat)}
                                        />
                                    }
                                    label={<span class="text-md">{cat}</span>}
                                />
                            ))}
                        </AnyFormGroup>
                    )}
                </AnyBox>
            </AnyPopover>
        </div>
    );
}
