import type {
  DataStore,
  ActionService,
  TimerStateService,
  InputService,
  ItemService,
  SettingsRepository,
} from '@core/services/public';
import type { ChatSessionStore } from '@core/ai/public';
import type { WhiteboardStore } from '@core/whiteboard/public';
import type { RendererService } from '@/app/dashboard/RendererService';
import type { TimerService } from '@features/timer/TimerService';
import type { FloatingTimerWidget } from '@features/timer/FloatingTimerWidget';
import type { UseCases } from '@/app/usecases';

/**
 * ServiceManager 内部服务缓存（仅用于 app 层编排，不作为对外 API）。
 *
 * 注意：这里刻意保持为 Partial，以便按启动步骤逐步填充。
 */
export type ServiceManagerServices = Partial<{
    settingsRepository: SettingsRepository;
    dataStore: DataStore;
    rendererService: RendererService;
    actionService: ActionService;
    timerService: TimerService;
    timerStateService: TimerStateService;
    inputService: InputService;
    timerWidget: FloatingTimerWidget;
    itemService: ItemService;
    useCases: UseCases;
    chatSessionStore: ChatSessionStore;
    whiteboardStore: WhiteboardStore;
}>;
