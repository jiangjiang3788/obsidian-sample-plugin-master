// src/app/usecases/index.ts
/**
 * UseCases 统一导出
 * Role: UseCase (应用层入口)
 * 
 * Do:
 * - 提供统一的 UseCase 创建入口
 * - 作为 UI 层调用业务逻辑的唯一入口
 * - 通过 createUseCases(store) 显式注入 store
 * 
 * Don't:
 * - 引入 UI/Obsidian API（保持可测试性）
 * - 持有状态
 * - 使用全局单例（禁止 getAppStoreInstance）
 * 
 * ⚠️ P0-2 架构约束：
 * - UI 层必须通过 UseCases 调用业务逻辑
 * - UI 通过 UseCases 调用业务逻辑
 * - 禁止 UI 直接调用 appStore['_updateSettingsAndPersist']
 * - 禁止 UI 直接调用 Zustand Store actions
 * - ⛔ 禁止使用全局单例
 */

import type { InjectionToken } from 'tsyringe';
import { SettingsUseCase, createSettingsUseCase } from './settings.usecase';
import { BlocksUseCase, createBlocksUseCase } from './blocks.usecase';
import { ThemeUseCase, createThemeUseCase } from './theme.usecase';
import { LayoutUseCase, createLayoutUseCase } from './layout.usecase';
import { ViewInstanceUseCase, createViewInstanceUseCase } from './viewinstance.usecase';
import { TimerUseCase, createTimerUseCase } from './timer.usecase';
import { RecordInputUseCase, createRecordInputUseCase } from './recordInput.usecase';
import type { DataStore, InputService, ItemService, TimerStateService } from '@core/public';

/**
 * Zustand Store 类型（用于 createUseCases 参数）
 */
export type AppStoreApi = ReturnType<typeof import('@/app/store/useAppStore').createAppStore>;

/**
 * UseCases 集合接口
 */
export interface UseCases {
    settings: SettingsUseCase;
    blocks: BlocksUseCase;
    theme: ThemeUseCase;
    layout: LayoutUseCase;
    viewInstance: ViewInstanceUseCase;
    timer: TimerUseCase;
    recordInput: RecordInputUseCase;
}

/**
 * UseCases DI Token
 * 用于从 DI 容器中获取 UseCases 单例
 */
export const USECASES_TOKEN: InjectionToken<UseCases> = 'UseCases';

/**
 * UseCase 依赖集合（冻结阶段）
 * - 由 ServiceManager 作为组合根注入
 * - 禁止在 UseCase 内部自行 resolve 依赖（避免隐藏依赖 / 权力外溢）
 */
export interface UseCaseDeps {
    timerStateService: TimerStateService;
    inputService: InputService;
    itemService: ItemService;
    dataStore: DataStore;
}

/**
 * 创建 UseCases 实例
 * 
 * ⚠️ P0-2 架构约束：
 * - 必须由 ServiceManager 调用，显式传入 store
 * - 禁止使用全局单例
 * - store 通过闭包传递给各个 UseCase
 * 
 * @param store Zustand Store 实例
 * @returns UseCases 集合
 */
export function createUseCases(store: AppStoreApi, deps: UseCaseDeps): UseCases {
    return {
        settings: createSettingsUseCase(store),
        blocks: createBlocksUseCase(store),
        theme: createThemeUseCase(store),
        layout: createLayoutUseCase(store),
        viewInstance: createViewInstanceUseCase(store),
        timer: createTimerUseCase(store, deps.timerStateService),
        recordInput: createRecordInputUseCase(store, {
            inputService: deps.inputService,
            itemService: deps.itemService,
            dataStore: deps.dataStore,
        }),
    };
}

// 导出具体的 UseCase 类型
export { SettingsUseCase } from './settings.usecase';
export { BlocksUseCase } from './blocks.usecase';
export { ThemeUseCase } from './theme.usecase';
export { LayoutUseCase } from './layout.usecase';
export { ViewInstanceUseCase } from './viewinstance.usecase';
export { TimerUseCase } from './timer.usecase';
export { RecordInputUseCase } from './recordInput.usecase';

// UI 层请从 '@/app/public' 获取 useUseCases（冻结阶段唯一出口）
