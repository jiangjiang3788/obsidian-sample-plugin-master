// src/app/usecases/settings.usecase.ts
/**
 * SettingsUseCase - 设置相关用例
 * Role: UseCase (应用层)
 * 
 * Do:
 * - 封装设置相关的业务意图（仅 settings 域：AI设置、计时器等）
 * - 调用 Zustand Store 的 actions
 * - 统一错误处理
 * 
 * Don't:
 * - 直接操作 SettingsRepository
 * - 持有 UI 相关逻辑
 * - 直接修改 settings 数据结构
 * - ⛔ 使用全局单例（禁止 getAppStoreInstance）
 * 
 * NOTE: ViewInstance CRUD 请使用 useCases.viewInstance.*
 * NOTE: reorderItems 请使用 useCases.group.reorderItems
 */

import type { AiSettings } from '@core/types/public';
import type { AppStoreApi } from './AppStoreApi';
import { devLog, devError } from '@core/utils/public';
import { updateCategoryColorMap } from '@core/types/public';

/**
 * 设置用例类
 * P0 止血点：UI 通过 useCases 调用
 */
export class SettingsUseCase {
    private store: AppStoreApi;

    constructor(store: AppStoreApi) {
        this.store = store;
    }

    /**
     * 设置悬浮计时器启用状态
     * @param enabled 是否启用
     */
    async setFloatingTimerEnabled(enabled: boolean): Promise<void> {
        try {
            const state = this.store.getState();
            
            if (!state.isInitialized) {
                devError('[SettingsUseCase] Store 未初始化，无法设置悬浮计时器状态');
                return;
            }
            
            await state.setFloatingTimerEnabled(enabled);
            
            // [新增] 同步更新 UI 可见性
            // 当用户在设置中明确启用/禁用时，UI 状态应立即跟随
            state.ui.setTimerWidgetVisible(enabled);
        } catch (error) {
            devError('[SettingsUseCase] setFloatingTimerEnabled 失败:', error);
            throw error;
        }
    }

    /**
     * 开发模式：控制是否把错误堆栈输出到 console.error
     * - 开启：toast 仍显示，同时 console.error 输出 stack（便于定位）
     * - 关闭：只 toast，不污染控制台
     */
    async setDevConsoleStackEnabled(enabled: boolean): Promise<void> {
        try {
            const state = this.store.getState();
            if (!state.isInitialized) {
                devError('[SettingsUseCase] Store 未初始化，无法设置 devConsoleStackEnabled');
                return;
            }
            await state.updateSettings((draft) => {
                draft.devConsoleStackEnabled = enabled;
            });
        } catch (error) {
            devError('[SettingsUseCase] setDevConsoleStackEnabled 失败:', error);
            throw error;
        }
    }

    /**
     * 切换计时器悬浮窗可见性（临时状态，不持久化）
     */
    async toggleTimerWidgetVisibility(): Promise<void> {
        try {
            const state = this.store.getState();
            
            if (!state.isInitialized) {
                devError('[SettingsUseCase] Store 未初始化，无法切换计时器可见性');
                return;
            }

            devLog("[计时器浮窗] 命令：toggleTimerWidgetVisibility 触发", { enabled: state.settings.floatingTimerEnabled, visible: state.ui.isTimerWidgetVisible });
            
            if (!state.settings.floatingTimerEnabled) {
                await state.setFloatingTimerEnabled(true);
                state.ui.setTimerWidgetVisible(true);
                devLog("[计时器浮窗] 未启用 -> 已启用并设为可见");
                return;
            } else {
                state.ui.toggleTimerWidgetVisible();
                devLog("[计时器浮窗] 已启用 -> 切换可见性为", state.ui.isTimerWidgetVisible);
            }
        } catch (error) {
            devError('[SettingsUseCase] toggleTimerWidgetVisibility 失败:', error);
        }
    }


    /** 设置无上下文精力记录（例如 iOS Shortcut）的默认目标路径。空值表示自动选择第一个活跃目标。 */
    async setEnergyDefaultGoalPath(goalPath: string | null): Promise<void> {
        try {
            const state = this.store.getState();
            if (!state.isInitialized) {
                devError('[SettingsUseCase] Store 未初始化，无法设置默认精力目标');
                return;
            }
            await state.updateSettings((draft) => {
                draft.energySettings = {
                    ...(draft.energySettings || {}),
                    defaultGoalPath: String(goalPath || '').trim(),
                };
            });
        } catch (error) {
            devError('[SettingsUseCase] setEnergyDefaultGoalPath 失败:', error);
            throw error;
        }
    }

    /**
     * 更新 AI 设置
     * P0 止血点：UI 不再直接调用 appStore._updateSettingsAndPersist
     * @param aiSettings 完整的 AI 设置对象
     */
    async updateAiSettings(aiSettings: AiSettings): Promise<void> {
        try {
            const state = this.store.getState();
            
            if (!state.isInitialized) {
                devError('[SettingsUseCase] Store 未初始化，无法更新 AI 设置');
                return;
            }
            
            await state.updateAiSettings(aiSettings);
        } catch (error) {
            devError('[SettingsUseCase] updateAiSettings 失败:', error);
            throw error;
        }
    }



    /** 记录最近在 QuickInput 中明确选择的 Goal；用于选择器快捷入口。 */
    async rememberRecentGoalPath(goalPath: string, limit = 5): Promise<void> {
        try {
            const path = String(goalPath || '').trim();
            if (!path) return;
            const state = this.store.getState();
            if (!state.isInitialized) return;
            await state.updateSettings((draft) => {
                const previous = Array.isArray(draft.recentGoalPaths) ? draft.recentGoalPaths : [];
                draft.recentGoalPaths = [path, ...previous.filter((item) => item !== path)].slice(0, Math.max(1, limit));
            });
        } catch (error) {
            devError('[SettingsUseCase] rememberRecentGoalPath 失败:', error);
        }
    }

    /**
     * 更新全局分类颜色配置
     * @param colors categoryKey 基础类别 → 颜色 映射
     */
    async updateCategoryColors(colors: Record<string, string>): Promise<void> {
        try {
            const state = this.store.getState();
            if (!state.isInitialized) {
                devError('[SettingsUseCase] Store 未初始化，无法更新分类颜色');
                return;
            }
            await state.updateSettings((draft) => {
                draft.categoryColors = colors;
            });
            // 同步更新运行时颜色映射
            updateCategoryColorMap(colors);
        } catch (error) {
            devError('[SettingsUseCase] updateCategoryColors 失败:', error);
            throw error;
        }
    }
}

/**
 * 创建设置用例实例
 * @param store Zustand Store 实例
 */
export function createSettingsUseCase(store: AppStoreApi): SettingsUseCase {
    return new SettingsUseCase(store);
}
