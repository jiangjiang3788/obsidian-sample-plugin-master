import { applyRecordRefreshPlan, buildSuccessResult, finalizeRecordSubmitResult } from '@core/recordInput/public';
import type { RecordCaptureTemplate, RecordViewItem } from '@core/types/public';
import type {
  NormalizeRecordInputResult,
  RecordOutputPlan,
  RecordPersistencePlan,
  RecordSubmitResult,
  ResolveDependenciesResult,
} from '@core/recordInput/public';

import { mapSubmitError } from '../error';
import { issue, toArray } from '../issues';
import { getItemFilePath } from '../locator';
import { buildRefreshPlan, getFileItemsByPath } from '../paths';
import type { RecordInputWorkflowRuntime } from './types';

export interface RecordMigrationTransactionParams {
  item: RecordViewItem;
  template: RecordCaptureTemplate;
  resolved: ResolveDependenciesResult;
  normalized: NormalizeRecordInputResult;
  outputPlan: RecordOutputPlan;
  persistencePlan: RecordPersistencePlan;
  warnings: RecordSubmitResult['warnings'];
  signal?: AbortSignal;
}

/**
 * Safe update transaction for path-changing edits/conversions.
 *
 * The transaction is intentionally not a rollback transaction: it writes the new
 * record first, then deletes the old record. If deletion fails, the new record is
 * kept and the old record is preserved with a partial_success result so the user
 * can manually clean up without data loss.
 */
export class RecordMigrationTransaction {
  constructor(private runtime: RecordInputWorkflowRuntime) {}

  async execute(params: RecordMigrationTransactionParams): Promise<RecordSubmitResult> {
    const targetPath = params.outputPlan.targetFilePath || '';
    const createdPath = await this.runtime.deps.inputService.createRecordAtPlannedLocation(
      params.template,
      params.normalized.normalizedFormData,
      { signal: params.signal, autoRefresh: false, recordId: params.item.id },
    );

    const scannedNewPath = await applyRecordRefreshPlan(this.runtime.deps.dataStore, buildRefreshPlan([createdPath], false));
    const afterTargetItems = scannedNewPath.get(createdPath) ?? getFileItemsByPath(this.runtime.deps.dataStore, createdPath);
    const createdRecord = afterTargetItems.find(item => item.id === params.item.id);
    if (!createdRecord) throw new Error(`record_move_scan_failed:${params.item.id}`);

    try {
      const deletedPath = await this.runtime.deps.inputService.deleteExistingRecord(params.item, {
        signal: params.signal,
        autoRefresh: false,
      });
      return finalizeRecordSubmitResult(this.runtime.deps.dataStore, buildSuccessResult('update', {
        affectedPath: createdPath,
        affectedRecordId: createdRecord?.id ?? params.item.id,
        refresh: buildRefreshPlan([createdPath, deletedPath]),
        feedback: {
          notice: `✅ 已迁移保存：${params.persistencePlan.originalPath || '原位置'} → ${createdPath}`,
        },
        warnings: [
          ...(params.warnings || []),
          issue(
            'record_update_moved_to_new_path',
            `路径变化已执行安全迁移：已先写入 ${createdPath}，再删除原位置 ${params.persistencePlan.originalPath || '未知位置'}。`,
          ),
        ],
      }));
    } catch (deleteError) {
      return finalizeRecordSubmitResult(this.runtime.deps.dataStore, {
        status: 'partial_success',
        operation: 'update',
        affectedPath: createdPath,
        affectedRecordId: createdRecord?.id ?? params.item.id,
        refresh: buildRefreshPlan([createdPath, params.persistencePlan.originalPath]),
        feedback: {
          notice: `已写入新位置 ${createdPath}，但旧记录删除失败；请检查并手动清理 ${params.persistencePlan.originalPath || '原位置'}。`,
        },
        warnings: params.warnings,
        errors: [
          issue(
            'record_update_old_entry_delete_failed',
            `安全迁移保存：已先写入新位置 ${createdPath}，但删除原记录 ${params.persistencePlan.originalPath || '未知位置'} 失败。为避免数据丢失，旧记录被保留，请手动检查并清理。`,
          ),
          ...toArray(mapSubmitError('update', deleteError).errors),
        ],
      });
    }
  }
}
