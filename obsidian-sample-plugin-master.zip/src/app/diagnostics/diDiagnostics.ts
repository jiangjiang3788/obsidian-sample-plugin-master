// src/app/diagnostics/diDiagnostics.ts
// Dev-only diagnostics for DI / container wiring.
// Default: OFF to keep startup logs clean. Enable in dev console:
//   globalThis.__THINK_DI_DEBUG__ = true

import { devLog, devWarn } from '@core/utils/public';

function isDevBuild(): boolean {
    // Keep diagnostics parseable in both Vite ESM and Jest CJS. The debug switch is
    // opt-in anyway, so Node's NODE_ENV is enough to suppress it in production tools.
    return typeof process !== 'undefined'
        ? process.env.NODE_ENV !== 'production'
        : true;
}

export function isDiDebugEnabled(): boolean {
    return !!(isDevBuild() && (globalThis as any).__THINK_DI_DEBUG__);
}

export function diDebug(...args: any[]): void {
    if (!isDiDebugEnabled()) return;
    devLog('[DI]', ...args);
}

export function diWarn(...args: any[]): void {
    if (!isDiDebugEnabled()) return;
    devWarn('[DI]', ...args);
}
