import { container } from 'tsyringe';
import type { PluginHost } from '@core/ports/public';

import { SETTINGS_PERSISTENCE_TOKEN } from '@core/services/public';
import { devError, devLog } from '@core/utils/public';

import { diDebug, diWarn } from '@/app/diagnostics/diDiagnostics';

import type { ThinkSettings } from '@core/types/public';
import { safeAsync } from '@shared/utils/public';
import { startMeasure } from '@shared/utils/public';

import { createAppStore, STORE_TOKEN } from '@/app/store/useAppStore';
import { createUseCases, USECASES_TOKEN } from '@/app/usecases';
import { FloatingTimerWidget } from '@features/timer/FloatingTimerWidget';
import type { ServiceManagerServices } from '@/app/ServiceManager.services';
import type { Disposables } from '@/app/runtime/disposables';
import type { BootstrapResolved } from '@/app/bootstrap/buildRuntime';
import { setDevConsoleStackEnabled } from '@shared/utils/public';
import { applyRecordTypeColorOverrides, clearRecordTypeColorOverrides } from '@/app/presentation/RecordTypeColorRuntime';

export async function initializeCore(opts: {
    plugin: PluginHost;
    services: ServiceManagerServices;
    disposables?: Disposables;
    bootstrap: Pick<BootstrapResolved, 'settingsRepository' | 'timerStateService' | 'initialSettings' | 'inputService' | 'itemService' | 'dataStore'>;
}): Promise<void> {
    const { plugin, services, disposables, bootstrap } = opts;
    const stopMeasure = startMeasure('ServiceManager.initializeCore');

    await (
        safeAsync(
            async () => {
                // 1. 解析核心服务
                // DI diagnostics: guard before any resolve (dev only, opt-in)
                if (!container.isRegistered(SETTINGS_PERSISTENCE_TOKEN)) {
                    diWarn('SettingsPersistence NOT registered in container used for resolve()');
                    throw new Error('SettingsPersistence token missing before resolve()');
                } else {
                    diDebug('SettingsPersistence is registered before resolve()');
                }

                // 1. 使用上层传入的依赖（避免在此处散落 resolve）
                services.settingsRepository = bootstrap.settingsRepository;

                // 初始化 SettingsRepository 的设置（由上层 resolve 并下发）
                const diInitialSettings: ThinkSettings = bootstrap.initialSettings;
                services.settingsRepository.setInitialSettings(diInitialSettings);
                diDebug('SettingsRepository.setInitialSettings() called');

                services.timerStateService = bootstrap.timerStateService;

                // 2. 创建 Zustand Store 并注册到 DI
                const settingsRepository = services.settingsRepository;
                const zustandStore = createAppStore(settingsRepository);

                // P0-3: 注册 STORE_TOKEN 到 DI 容器（替代全局单例）
                container.register(STORE_TOKEN, { useValue: zustandStore });
                devLog('[ThinkPlugin] Zustand Store 已注册到 DI 容器');

                // 使用 SettingsRepository 加载的 settings 初始化 Zustand store
                const zustandInitialSettings = settingsRepository.getSettings();
                zustandStore.getState().initialize(zustandInitialSettings);
                devLog('[ThinkPlugin] Zustand Store 初始化完成');

                // 开发模式：初始化 console.error stack 开关
                setDevConsoleStackEnabled(!!zustandStore.getState().settings.devConsoleStackEnabled);
                applyRecordTypeColorOverrides(zustandStore.getState().settings.recordTypeColors);

                // 订阅 SettingsRepository 的变更，仅同步到 Zustand Store
                const unsubscribeSettingsRepo = settingsRepository.subscribe((settings) => {
                    zustandStore.setState({ settings });
                    applyRecordTypeColorOverrides(settings.recordTypeColors);
                });
                disposables?.add('SettingsRepository.subscribe()', unsubscribeSettingsRepo);
                disposables?.add('RecordTypeColorRuntime', clearRecordTypeColorOverrides);
                devLog('[ThinkPlugin] SettingsRepository 订阅已建立（纯同步 settings）');

                // TimerWidget 生命周期管理：通过监听 store 中 settings.floatingTimerEnabled 变化
                const unsubscribeFloatingTimer = zustandStore.subscribe(
                    (state) => state.settings.floatingTimerEnabled,
                    (floatingTimerEnabled, prevFloatingTimerEnabled) => {
                        // 从禁用到启用：创建并加载 TimerWidget
                        if (floatingTimerEnabled && !prevFloatingTimerEnabled) {
                            if (!services.timerWidget) {
                                services.timerWidget = new FloatingTimerWidget(plugin);
                                services.timerWidget.load();
                                zustandStore.setState((s) => ({
                                    ui: { ...s.ui, isTimerWidgetVisible: true },
                                }));
                                devLog('[计时器浮窗] 已启用 -> 创建并显示浮窗');
                            }
                        }

                        // 从启用到禁用：卸载 TimerWidget
                        if (!floatingTimerEnabled && prevFloatingTimerEnabled) {
                            zustandStore.setState((s) => ({
                                ui: { ...s.ui, isTimerWidgetVisible: false },
                            }));
                            if (services.timerWidget) {
                                services.timerWidget.unload();
                                services.timerWidget = undefined;
                                devLog('[计时器浮窗] 已禁用 -> 卸载浮窗');
                            }
                        }
                    }
                );
                disposables?.add('AppStore.subscribe(floatingTimerEnabled)', unsubscribeFloatingTimer);
                devLog('[ThinkPlugin] TimerWidget 生命周期监听已建立');
// 开发模式：监听设置变更，决定是否输出 console.error stack
const unsubscribeDevConsole = zustandStore.subscribe(
    (state) => !!state.settings.devConsoleStackEnabled,
    (enabled) => {
        setDevConsoleStackEnabled(enabled);
    }
);
disposables?.add('AppStore.subscribe(devConsoleStackEnabled)', unsubscribeDevConsole);
devLog('[ThinkPlugin] DevConsoleStackEnabled 监听已建立');



                // 3. 创建 UseCases 并注册到 DI 容器（传入 store）
                services.useCases = createUseCases(zustandStore, {
                    timerStateService: services.timerStateService!,
                    inputService: bootstrap.inputService,
                    itemService: bootstrap.itemService,
                    dataStore: bootstrap.dataStore,
                });
                container.register(USECASES_TOKEN, { useValue: services.useCases });
                devLog('[ThinkPlugin] UseCases 创建完成');

                const duration = stopMeasure();
                devLog(`[ThinkPlugin] 核心服务初始化完成 (${duration.toFixed(2)}ms)`);
            },
            'ServiceManager.initializeCore',
            { showNotice: false }
        )
    );
}
