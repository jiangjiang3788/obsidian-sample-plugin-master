import { RECORD_TYPE_IDS } from '@core/recordTypes/public';
import type { QuickInputConfig } from '@core/services/public';
import { minutesToTime } from '@core/utils/public';

import { openCreateModal } from './openCreateModal';
import type { TimelineCreateParams } from './types';

function getEventClientY(event: MouseEvent | TouchEvent): number {
  if ('touches' in event && event.touches?.length) {
    return event.touches[0].clientY;
  }
  if ('changedTouches' in event && event.changedTouches?.length) {
    return event.changedTouches[0].clientY;
  }
  return (event as MouseEvent).clientY;
}

function buildTimelineCreateConfig(params: TimelineCreateParams): QuickInputConfig | null {
  const targetEl = params.event.currentTarget as HTMLElement | null;
  if (!targetEl) return null;

  const rect = targetEl.getBoundingClientRect();
  const clientY = getEventClientY(params.event);
  const y = clientY - rect.top;
  const clickedMinute = Math.max(0, Math.floor((y / params.hourHeight) * 60));

  const prevBlock = params.dayBlocks.filter((block) => block.blockEndMinute <= clickedMinute).pop();
  const nextBlock = params.dayBlocks.find((block) => block.blockStartMinute >= clickedMinute);

  const context: Record<string, unknown> = {
    日期: params.day,
    __recordUiContext: {
      kind: 'timeline_create',
      timeContext: {
        date: params.day,
        clickedMinute,
      },
    },
  };

  context['时间'] = prevBlock
    ? minutesToTime(prevBlock.blockEndMinute)
    : minutesToTime(clickedMinute);

  if (nextBlock) {
    context['结束'] = minutesToTime(nextBlock.blockStartMinute);
  }

  return {
    blockId: RECORD_TYPE_IDS.TASK,
    context,
  };
}

export function openCreateFromTimeline(params: TimelineCreateParams): boolean {
  return openCreateModal(params.app, buildTimelineCreateConfig(params), 'view_quick_create', { allowBlockSwitch: false });
}
