// src/shared/ui/modals/EditTaskModal.tsx
//这个是时间轴编辑的弹窗现在已经弃用 使用通用弹窗
/** @jsxImportSource preact */
import { h } from 'preact';
import { useEffect } from 'preact/hooks';
import type { TaskBlock } from '@core/public';
import { timeToMinutes, minutesToTime, normalizeTaskTimeTriple } from '@core/public';
import { Dialog, DialogTitle, DialogContent, DialogActions, Button, TextField } from '@mui/material';
import { useTimeFormState } from '@shared/hooks/useFormState';
import { useSaveHandler } from '@shared/patterns/ModalSavePattern';
import { computeLinkedTimeChanges } from '@shared/utils/linkedTimeFields';
import type { UpdateTaskTimeHandler } from '@shared/types/taskTime';

export interface EditTaskModalProps {
  isOpen: boolean;
  onClose: () => void;
  task: TaskBlock;
  /**
   * 保存处理器（由 feature 层注入）。
   * shared/ui 不直接依赖 core Service（如 ItemService），仅通过回调完成保存。
   */
  onUpdateTaskTime: UpdateTaskTimeHandler;
  onSave?: () => void;
}

/**
 * 通用的“精确编辑任务时间”弹窗。
 *
 * 迁移原因：
 * - shared/ui 不能依赖 features（否则 shared 就会变成绕过边界的 tunnel）
 * - 这个组件本质是可复用 UI + core service 能力，因此归位到 shared/ui/modals
 */
export function EditTaskModal({ isOpen, onClose, task, onUpdateTaskTime, onSave }: EditTaskModalProps) {
  // 使用专门的时间表单状态管理
  const formState = useTimeFormState({
    startTime: minutesToTime(task.startMinute),
    endTime: minutesToTime(task.endMinute),
    duration: String(task.duration),
  });

  const { state: timeData, updateField, lastChanged } = formState;

  // 智能时间计算逻辑
  useEffect(() => {
    const changes = computeLinkedTimeChanges(
      timeData,
      { startKey: 'startTime', endKey: 'endTime', durationKey: 'duration' },
      lastChanged,
      { durationOutput: 'string' }
    );

    if (Object.keys(changes).length > 0) {
      Object.entries(changes).forEach(([field, value]) => {
        updateField(field as keyof typeof timeData, value);
      });
    }
  }, [timeData, lastChanged, updateField]);

  // 验证函数
  const validateTimeData = () => {
    const startM = timeToMinutes(timeData.startTime);
    const endM = timeToMinutes(timeData.endTime);
    const duration = Number(timeData.duration);

    if (startM === null || (timeData.endTime && endM === null) || isNaN(duration)) {
      throw new Error('请输入有效的时间和时长');
    }

    const normalized = normalizeTaskTimeTriple({
      startTime: timeData.startTime,
      endTime: timeData.endTime,
      duration,
    });

    return {
      time: normalized.startTime ?? timeData.startTime,
      endTime: normalized.endTime ?? timeData.endTime,
      duration: normalized.duration ?? duration,
    };
  };

  // 使用统一的保存处理模式
  const handleSave = useSaveHandler(
    async () => {
      const timeUpdateData = validateTimeData();
      await onUpdateTaskTime(task.id, timeUpdateData);
      onSave?.();
      onClose();
    },
    {
      successMessage: '任务时间已更新',
      errorMessage: '更新失败',
    }
  );

  return (
    <Dialog open={isOpen} onClose={onClose}>
      <DialogTitle>编辑任务时间</DialogTitle>
      <DialogContent>
        <div style={{ marginBottom: '1rem', marginTop: '0.5rem' }}>
          <p
            style={{
              fontSize: '0.9em',
              color: 'var(--text-muted)',
              maxWidth: '400px',
              whiteSpace: 'nowrap',
              overflow: 'hidden',
              textOverflow: 'ellipsis',
            }}
          >
            {task.pureText}
          </p>
        </div>

        <TextField
          label="开始时间"
          type="time"
          value={timeData.startTime}
          onChange={(e) => updateField('startTime', (e.target as HTMLInputElement).value)}
          fullWidth
          margin="normal"
          InputLabelProps={{ shrink: true }}
        />

        <TextField
          label="结束时间"
          type="time"
          value={timeData.endTime}
          onChange={(e) => updateField('endTime', (e.target as HTMLInputElement).value)}
          fullWidth
          margin="normal"
          InputLabelProps={{ shrink: true }}
        />

        <TextField
          label="持续时长 (分钟)"
          type="number"
          value={timeData.duration}
          onChange={(e) => updateField('duration', (e.target as HTMLInputElement).value)}
          fullWidth
          margin="normal"
          inputProps={{ min: 0 }}
        />
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>取消</Button>
        <Button onClick={handleSave} variant="contained">
          保存
        </Button>
      </DialogActions>
    </Dialog>
  );
}
