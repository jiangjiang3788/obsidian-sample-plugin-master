export { StatisticsView } from './StatisticsViewContainer';
