export { StatisticsView } from './StatisticsViewContainer';
