// src/features/dashboard/ui/LayoutRenderer.tsx
/** @jsxImportSource preact */
import { h, Fragment } from 'preact';
import { useState, useMemo, useEffect, useCallback, useRef } from 'preact/hooks'; // [修改] 导入 useRef
import { DataStore } from '@core/public';
import { Layout, ViewInstance, Item } from '@core/public'; // [修改] 导入 Item 类型
import { ModulePanel } from './ModulePanel';
import { DashboardViewComponents as ViewComponents } from './index';

import { getDateRange, dayjs } from '@core/public';
import { useZustandAppStore, useUseCases } from '@/app/public';
import type { ActionService } from '@core/public';
import { ItemService } from '@core/public';
import type { TimerService } from '@features/timer/TimerService';
import { useViewData } from '@/features/settings/useViewData';
import { QuickInputModal } from '@/features/quickinput/QuickInputModal';
import { openModuleSettingsWidget } from './ModuleSettingsModal';
import { App, Notice } from 'obsidian'; // [修改] 导入 Notice
import { exportItemsToMarkdown, getExportConfigByViewType } from '@core/public'; // [新增] 导入导出函数
import { ViewToolbar } from '@features/views/ViewToolbar'; // [新增] 导入统一工具栏组件

// [修改] ViewContent 组件增加 onDataLoaded 和 selectedThemes props
const ViewContent = ({
    viewInstance,
    dataStore,
    dateRange,
    keyword,
    layoutView,
    isOverviewMode,
    useFieldGranularity,
    selectedThemes, // [新增]
    selectedCategories, // [新增]
    app,
    onMarkDone,
    actionService,
    itemService,
    timerService,
    timers, // [新增]
    allThemes, // [新增]
    inputSettings, // [新增]
    onDataLoaded, // [新增]
}: {
    viewInstance: ViewInstance;
    dataStore: DataStore;
    dateRange: [Date, Date];
    keyword: string;
    layoutView: string;
    isOverviewMode: boolean;
    useFieldGranularity: boolean;
    selectedThemes: string[]; // [新增]
    selectedCategories: string[]; // [新增]
    app: App;
    onMarkDone: (id: string) => void;
    actionService: ActionService;
    itemService: ItemService;
    timerService: TimerService;
    timers: any[]; // [新增]
    allThemes: any[]; // [新增]
    inputSettings: any; // [新增]
    onDataLoaded: (items: Item[]) => void; // [新增]
}) => {
    const viewItems = useViewData({
        dataStore,
        viewInstance,
        dateRange,
        keyword,
        layoutView,
        isOverviewMode: !!isOverviewMode,
        useFieldGranularity,
        selectedThemes,
        selectedCategories,
    });

    // [新增] 使用 useEffect 将数据传递给父组件
    useEffect(() => {
        if (onDataLoaded) {
            onDataLoaded(viewItems);
        }
    }, [viewItems, onDataLoaded]);

    const ViewComponent = (ViewComponents as any)[viewInstance.viewType];
    if (!ViewComponent) return <div>未知视图: {viewInstance.viewType}</div>;

    const viewProps: any = {
        app,
        items: viewItems,
        dateRange,
        module: viewInstance,
        currentView: layoutView,
        useFieldGranularity,
        ...viewInstance.viewConfig,
        groupField: viewInstance.group,
        groupFields: viewInstance.groupFields,
        fields: viewInstance.fields,
        onMarkDone: onMarkDone,
        actionService: actionService,
        itemService: itemService,
        timerService: timerService,
        timers: timers, // [新增]
        allThemes: allThemes, // [新增]
        inputSettings: inputSettings, // [新增]
        selectedCategories,
    };

    return <ViewComponent {...viewProps} />;
};

export function LayoutRenderer({ layout, dataStore, app, actionService, itemService, timerService }: any) {
    // [P1] 通过 Context 获取 UseCases（已移除 useAppStore，统一用 Zustand）
    const useCases = useUseCases();
    
    // 使用 Zustand store 获取 settings 相关状态
    const allViews = useZustandAppStore(state => state.settings.viewInstances);
    const inputSettings = useZustandAppStore(state => state.settings.inputSettings); // [修改] 获取完整 inputSettings
    // [修改] 使用 Zustand store 获取 timers
    const timers = useZustandAppStore(state => state.timer.timers);
    const allThemes = inputSettings.themes; // [兼容] 保持 allThemes 变量
    
    const [expandedState, setExpandedState] = useState<Record<string, boolean>>({});
    const [isStateInitialized, setIsStateInitialized] = useState(false);
    
    // [新增] 创建一个 ref 来缓存每个模块的数据
    const modulesDataCache = useRef<Record<string, Item[]>>({});

    // [新增] 首屏就绪埋点：Dashboard 首次完成渲染后记录一次
    const firstScreenReportedRef = useRef(false);
    useEffect(() => {
        if (firstScreenReportedRef.current) return;
        firstScreenReportedRef.current = true;
        requestAnimationFrame(() => {
            dataStore.writePerformanceReport('firstScreenReady', {
                layoutId: layout.id,
                viewCount: layout.viewInstanceIds.length
            });
            console.log('[ThinkPlugin] 首屏就绪');
        });
    }, []);

    useEffect(() => {
        const initialState: Record<string, boolean> = {};
        layout.viewInstanceIds.forEach((viewId: string) => {
            const view = allViews.find((v: any) => v.id === viewId);
            if (view) {
                initialState[viewId] = !view.collapsed;
            }
        });
        setExpandedState(initialState);
        setIsStateInitialized(true);
    }, [layout.id]); // 移除 allViews 依赖，只在 layout.id 变化时重置折叠状态

    // 单独处理视图实例变化时的折叠状态更新
    useEffect(() => {
        if (!isStateInitialized) return;
        
        setExpandedState(prevState => {
            const newState = { ...prevState };
            layout.viewInstanceIds.forEach((viewId: string) => {
                const view = allViews.find((v: any) => v.id === viewId);
                if (view && !(viewId in prevState)) {
                    // 只为新增的视图实例设置初始状态，保持现有的折叠状态
                    newState[viewId] = !view.collapsed;
                }
            });
            return newState;
        });
    }, [allViews, isStateInitialized, layout.viewInstanceIds]);

    const getInitialDate = () => {
        return layout.initialDateFollowsNow ? dayjs() : (layout.initialDate ? dayjs(layout.initialDate) : dayjs());
    };

    const [layoutView, setLayoutView] = useState(layout.initialView || '月');
    const [layoutDate, setLayoutDate] = useState(getInitialDate());
    const [selectedThemes, setSelectedThemes] = useState<string[]>(layout.selectedThemes || []); // [新增] 主题筛选状态
    const [selectedCategories, setSelectedCategories] = useState<string[]>(layout.selectedCategories || []); // [新增] 分类筛选状态
    
    // [新增] 预定义分类列表（从设置中获取）
    const predefinedCategories = useMemo(() => {
        return inputSettings.categories || [];
    }, [inputSettings]);

    // [修复] 分离布局重置和主题筛选的effect，避免主题筛选时跳转视图
    useEffect(() => {
        setLayoutDate(getInitialDate());
        setLayoutView(layout.initialView || '月');
    }, [layout.id, layout.initialDate, layout.initialDateFollowsNow, layout.initialView]);

    // [新增] 仅当布局中的筛选器设置变化时才更新状态
    useEffect(() => {
        setSelectedThemes(layout.selectedThemes || []);
        setSelectedCategories(layout.selectedCategories || []);
    }, [layout.selectedThemes, layout.selectedCategories]);

    // [新增] 处理导出的函数
    const handleExport = useCallback((viewId: string, viewTitle: string) => {
        const items = modulesDataCache.current[viewId];
        if (!items || items.length === 0) {
            new Notice('没有内容可导出');
            return;
        }
        
        // 根据视图类型获取对应的导出配置
        const viewInstance = allViews.find(v => v.id === viewId);
        let exportConfig = viewInstance ? getExportConfigByViewType(viewInstance.viewType) : undefined;

        // [修复] 将视图实例中的动态分组配置合并到导出配置中
        if (viewInstance && exportConfig) {
            // 优先使用 viewInstance.groupFields (多级分组)
            // 其次兼容 viewInstance.group (单级分组)
            // 最后回退到默认配置
            const dynamicGroupFields = viewInstance.groupFields && viewInstance.groupFields.length > 0
                ? viewInstance.groupFields
                : (viewInstance.group ? [viewInstance.group] : undefined);

            if (dynamicGroupFields) {
                exportConfig = {
                    ...exportConfig,
                    groupFields: dynamicGroupFields
                };
            }
        }
        
        const markdownContent = exportItemsToMarkdown(items, exportConfig);
        navigator.clipboard.writeText(markdownContent);
        new Notice(`"${viewTitle}" 的内容已复制到剪贴板！`);
    }, [allViews]); // 依赖 allViews 来获取视图类型

    const handleQuickInputAction = (viewInstance: ViewInstance) => {
        const config = actionService.getQuickInputConfigForView(viewInstance, layoutDate, layoutView);
        if (config) {
            new QuickInputModal(app, config.blockId, config.context, config.themeId).open();
        }
    };
    
    const handleMarkItemDone = useCallback((itemId: string) => {
        itemService.completeItem(itemId);
    }, [itemService]);

    const handleToggle = useCallback((viewId: string, event?: MouseEvent) => {
        const isToggleAll = event?.metaKey || event?.ctrlKey;

        if (isToggleAll) {
            setExpandedState(currentState => {
                const shouldExpandAll = !currentState[viewId];
                const newState: Record<string, boolean> = {};
                for (const id in currentState) {
                    newState[id] = shouldExpandAll;
                }
                return newState;
            });
        } else {
            setExpandedState(prev => ({ ...prev, [viewId]: !prev[viewId] }));
        }
    }, []);


    // 设置按钮：打开“视图设置”浮窗（统一 FloatingPanel 能力：可拖动 / 点击外部关闭）
    const handleSettingsClick = useCallback((viewInstance: ViewInstance) => {
        openModuleSettingsWidget(viewInstance);
    }, []);

    // [P1] 处理主题筛选变化 - 通过 UseCase 层
    const handleThemeSelectionChange = useCallback((themes: string[]) => {
        setSelectedThemes(themes);
        useCases.layout.updateLayout(layout.id, { selectedThemes: themes });
    }, [layout.id, useCases.layout]);

    // [P1] 处理分类筛选变化 - 通过 UseCase 层
    const handleCategorySelectionChange = useCallback((categories: string[]) => {
        setSelectedCategories(categories);
        useCases.layout.updateLayout(layout.id, { selectedCategories: categories });
    }, [layout.id, useCases.layout]);

    const renderViewInstance = (viewId: string) => {
        const viewInstance = allViews.find(v => v.id === viewId);
        if (!viewInstance) return <div class="think-module">视图 (ID: {viewId}) 未找到</div>;

        const isExpanded = !!expandedState[viewId];

        return (
            <ModulePanel 
                key={viewId}
                title={viewInstance.title} 
                collapsed={!isExpanded}
                onToggle={(e: MouseEvent) => handleToggle(viewId, e)}
                onActionClick={() => handleQuickInputAction(viewInstance)}
                onExport={() => handleExport(viewInstance.id, viewInstance.title)} // [修改] 传递 onExport
                onSettingsClick={() => handleSettingsClick(viewInstance)} // [新增] 传递设置回调
            >
                {isExpanded && (
                    <ViewContent
                        viewInstance={viewInstance}
                        dataStore={dataStore}
                        dateRange={useMemo(() => {
                            const range = getDateRange(layoutDate, layoutView);
                            return [range.startDate.toDate(), range.endDate.toDate()] as [Date, Date];
                        }, [layoutDate, layoutView])}
                        keyword=""
                        layoutView={layoutView}
                        isOverviewMode={false}
                        useFieldGranularity={false}
                        selectedThemes={selectedThemes} // [新增] 传递主题筛选
                        selectedCategories={selectedCategories} // [新增] 传递分类筛选
                        app={app}
                        onMarkDone={handleMarkItemDone}
                        actionService={actionService}
                        itemService={itemService}
                        timerService={timerService}
                        timers={timers} // [新增]
                        allThemes={allThemes} // [新增]
                        inputSettings={inputSettings} // [新增]
                        onDataLoaded={(items) => { modulesDataCache.current[viewInstance.id] = items; }} // [修改] 传递 onDataLoaded
                    />
                )}
            </ModulePanel>
        );
    };

    const gridStyle = layout.displayMode === 'grid' ? { display: 'grid', gridTemplateColumns: `repeat(${layout.gridConfig?.columns || 2}, 1fr)`, gap: '8px' } : {};

    return (
        <div>
            <ViewToolbar
                currentView={layoutView}
                currentDate={layoutDate}
                onViewChange={setLayoutView}
                onDateChange={setLayoutDate}
                selectedThemes={selectedThemes}
                selectedCategories={selectedCategories}
                onThemeSelectionChange={handleThemeSelectionChange}
                onCategorySelectionChange={handleCategorySelectionChange}
                viewInstances={layout.viewInstanceIds.map((id: string) => allViews.find((v: any) => v.id === id)).filter(Boolean)}
                hideToolbar={layout.hideToolbar}
                themes={allThemes} // [新增] 传递主题列表
                predefinedCategories={predefinedCategories} // [新增] 传递预定义分类
            />
            <div style={gridStyle}>
                {isStateInitialized && layout.viewInstanceIds.map(renderViewInstance)}
            </div>
            
            {/* 模块设置已迁移为 FloatingWidget（openModuleSettingsWidget），不再在此处直接渲染 Modal */}
        </div>
    );
}
