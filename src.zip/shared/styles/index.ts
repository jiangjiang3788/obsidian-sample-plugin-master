// src/shared/styles/index.ts
// 统一导出MUI主题

export { theme as muiTheme } from './mui-theme';
