// src/core/config/index.ts
export * from './viewConfigs';
