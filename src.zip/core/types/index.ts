// src/core/types/index.ts
/**
 * 统一导出核心类型定义
 */

// 导出域类型
export * from './domain';
export * from './common';
