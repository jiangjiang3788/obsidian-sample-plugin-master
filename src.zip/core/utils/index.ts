// src/core/utils/index.ts
export * from './date';
export * from './text';
export * from './regex';
export * from './timing';
// [新增] 导出新的模板工具函数
export * from './templateUtils'; 
export * from './mark';
export * from './obsidian';
export * from './themeUtils';
export * from './exportUtils'; // [新增] 导出新的导出工具