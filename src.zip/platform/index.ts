// src/platform/index.ts
export * from './obsidian';