// src/app/store/slices/theme.slice.ts
/**
 * ThemeSlice - Zustand Theme 状态切片
 * Role: Store Slice (状态管理)
 * 
 * Do:
 * - 管理 Theme 相关的辅助状态（loading/error）
 * - 提供 Theme 相关 actions（委托给 SettingsRepository）
 * - 提供查询方法
 * 
 * Don't:
 * - 直接写 settings（由 ServiceManager 订阅 SettingsRepository 统一更新）
 * - 直接进行 IO 操作
 * - 持有 UI 逻辑
 * 
 * S2 规范：
 * - SettingsRepository 是 settings 的唯一写入口
 * - Zustand store 只是订阅者，由 ServiceManager 同步
 */

import type { StateCreator } from 'zustand';
import type { ThinkSettings, ThemeDefinition } from '@core/public';
import type { SettingsRepository } from '@core/public';
import type { ActiveStatus } from '@core/public';
import {generateId, devWarn, devError} from '@core/public';
import { createSliceMeta } from '@core/public';


function normalizeThemePath(path: string): string {
    return path.split('/').map(part => part.trim()).filter(Boolean).join('/');
}

function getNearestParentPath(path: string, themes: ThemeDefinition[]): string | null {
    const parts = normalizeThemePath(path).split('/');
    if (parts.length <= 1) return null;

    const themePaths = new Set(themes.map(t => normalizeThemePath(t.path)));
    for (let i = parts.length - 1; i >= 1; i--) {
        const candidate = parts.slice(0, i).join('/');
        if (themePaths.has(candidate)) return candidate;
    }
    return null;
}

function getSiblingOrderForNewTheme(path: string, themes: ThemeDefinition[]): number {
    const normalizedPath = normalizeThemePath(path);
    const parentPath = getNearestParentPath(normalizedPath, themes);
    const siblingOrders = themes
        .filter(t => getNearestParentPath(t.path, themes) === parentPath)
        .map(t => typeof t.order === 'number' && Number.isFinite(t.order) ? t.order : -1);
    const maxOrder = siblingOrders.length > 0 ? Math.max(...siblingOrders) : -1;
    return maxOrder + 1;
}

// ============== 类型定义 ==============

export interface ThemeSliceState {
    // Theme 数据从 settings.inputSettings.themes 读取
    // 这里只定义辅助状态
    themeLoading: boolean;
    themeError: string | null;
}

export interface ThemeSliceActions {
    // Theme CRUD
    addTheme: (path: string) => Promise<ThemeDefinition | null>;
    updateTheme: (id: string, updates: Partial<ThemeDefinition>) => Promise<void>;
    deleteTheme: (id: string) => Promise<void>;
    reorderThemeSiblings: (orderedThemeIds: string[], parentKey?: string) => Promise<void>;
    
    // Theme 批量操作
    batchUpdateThemes: (themeIds: string[], updates: Partial<ThemeDefinition>) => Promise<void>;
    batchDeleteThemes: (themeIds: string[]) => Promise<void>;
    batchUpdateThemeStatus: (themeIds: string[], status: ActiveStatus) => Promise<void>;
    batchUpdateThemeIcon: (themeIds: string[], icon: string) => Promise<void>;
    
    // 查询方法
    getThemes: () => ThemeDefinition[];
    getTheme: (id: string) => ThemeDefinition | undefined;
    // 状态管理
    setThemeError: (error: string | null) => void;
}

export type ThemeSlice = ThemeSliceState & ThemeSliceActions;

// ============== Slice 创建器 ==============

/**
 * 创建 Theme Slice
 * @param settingsRepository 设置仓库（用于持久化）
 * @param getSettings 获取当前设置的函数
 */
export function createThemeSlice(
    settingsRepository: SettingsRepository
): StateCreator<
    ThemeSlice & { settings: ThinkSettings; isInitialized: boolean },
    [],
    [],
    ThemeSlice
> {
    return (set, get) => ({
        // ============== 初始状态 ==============
        themeLoading: false,
        themeError: null,

        // ============== Theme CRUD ==============

        addTheme: async (path: string): Promise<ThemeDefinition | null> => {
            const state = get();
            if (!state.isInitialized) {
                devError('[ThemeSlice] Store 未初始化');
                return null;
            }

            if (!path) {
                devWarn('[ThemeSlice] 主题路径不能为空');
                return null;
            }

            // 检查路径是否已存在
            const existingThemes = state.settings.inputSettings?.themes || [];
            if (existingThemes.some(t => t.path === path)) {
                devWarn(`[ThemeSlice] 主题路径 "${path}" 已存在`);
                return null;
            }

            set({ themeLoading: true, themeError: null });

            try {
                const normalizedPath = normalizeThemePath(path);
                const newTheme: ThemeDefinition = {
                    id: generateId('thm'),
                    path: normalizedPath,
                    icon: '📁',
                    order: getSiblingOrderForNewTheme(normalizedPath, existingThemes)
                };

                // S1: 传入 ActionMeta 用于 dev 日志
                await settingsRepository.update(draft => {
                    if (!draft.inputSettings.themes) {
                        draft.inputSettings.themes = [];
                    }
                    draft.inputSettings.themes.push(newTheme);
                }, createSliceMeta('theme.addTheme'));

                // S2: settings 由 ServiceManager 订阅 SettingsRepository 统一更新
                set({ themeLoading: false });
                return newTheme;
            } catch (error: any) {
                devError('[ThemeSlice] addTheme 失败:', error);
                set({ themeError: error.message || '添加主题失败', themeLoading: false });
                return null;
            }
        },

        updateTheme: async (id: string, updates: Partial<ThemeDefinition>): Promise<void> => {
            const state = get();
            if (!state.isInitialized) {
                devError('[ThemeSlice] Store 未初始化');
                return;
            }

            // 检查路径重复
            if (updates.path) {
                const existingThemes = state.settings.inputSettings?.themes || [];
                if (existingThemes.some(t => t.path === updates.path && t.id !== id)) {
                    devWarn(`[ThemeSlice] 主题路径 "${updates.path}" 已存在`);
                    return;
                }
            }

            set({ themeLoading: true, themeError: null });

            try {
                // S1: 传入 ActionMeta 用于 dev 日志
                await settingsRepository.update(draft => {
                    const theme = draft.inputSettings.themes?.find(t => t.id === id);
                    if (theme) {
                        Object.assign(theme, updates);
                    }
                }, createSliceMeta('theme.updateTheme'));
                // S2: settings 由 ServiceManager 订阅 SettingsRepository 统一更新
                set({ themeLoading: false });
            } catch (error: any) {
                devError('[ThemeSlice] updateTheme 失败:', error);
                set({ themeError: error.message || '更新主题失败', themeLoading: false });
            }
        },

        deleteTheme: async (id: string): Promise<void> => {
            const state = get();
            if (!state.isInitialized) {
                devError('[ThemeSlice] Store 未初始化');
                return;
            }

            set({ themeLoading: true, themeError: null });

            try {
                // S1: 传入 ActionMeta 用于 dev 日志
                await settingsRepository.update(draft => {
                    // 删除主题
                    draft.inputSettings.themes = draft.inputSettings.themes?.filter(t => t.id !== id) || [];
                }, createSliceMeta('theme.deleteTheme'));
                // S2: settings 由 ServiceManager 订阅 SettingsRepository 统一更新
                set({ themeLoading: false });
            } catch (error: any) {
                devError('[ThemeSlice] deleteTheme 失败:', error);
                set({ themeError: error.message || '删除主题失败', themeLoading: false });
            }
        },

        reorderThemeSiblings: async (orderedThemeIds: string[], parentKey?: string): Promise<void> => {
            const state = get();
            if (!state.isInitialized) {
                devError('[ThemeSlice] Store 未初始化');
                return;
            }

            if (!orderedThemeIds || orderedThemeIds.length === 0) return;

            set({ themeLoading: true, themeError: null });

            try {
                const orderMap = new Map<string, number>();
                orderedThemeIds.forEach((id, index) => orderMap.set(id, index));

                await settingsRepository.update(draft => {
                    const themes = draft.inputSettings.themes || [];

                    // 关键修复：拖拽根主题时也必须持久化。这里不再依赖 UI 的树节点，
                    // 而是直接按提交的 ID 顺序写入 settings.inputSettings.themes[*].order。
                    themes.forEach(theme => {
                        const nextOrder = orderMap.get(theme.id);
                        if (typeof nextOrder === 'number') {
                            theme.order = nextOrder;
                        }
                    });
                }, createSliceMeta('theme.reorderThemeSiblings'));

                set({ themeLoading: false });
            } catch (error: any) {
                devError('[ThemeSlice] reorderThemeSiblings 失败:', { error, orderedThemeIds, parentKey });
                set({ themeError: error.message || '主题排序失败', themeLoading: false });
            }
        },

        // ============== 批量操作 ==============

        batchUpdateThemes: async (themeIds: string[], updates: Partial<ThemeDefinition>): Promise<void> => {
            const state = get();
            if (!state.isInitialized) return;

            set({ themeLoading: true, themeError: null });

            try {
                // S1: 传入 ActionMeta 用于 dev 日志
                await settingsRepository.update(draft => {
                    themeIds.forEach(id => {
                        const theme = draft.inputSettings.themes?.find(t => t.id === id);
                        if (theme) {
                            Object.assign(theme, updates);
                        }
                    });
                }, createSliceMeta('theme.batchUpdateThemes'));
                // S2: settings 由 ServiceManager 订阅 SettingsRepository 统一更新
                set({ themeLoading: false });
            } catch (error: any) {
                devError('[ThemeSlice] batchUpdateThemes 失败:', error);
                set({ themeError: error.message || '批量更新主题失败', themeLoading: false });
            }
        },

        batchDeleteThemes: async (themeIds: string[]): Promise<void> => {
            const state = get();
            if (!state.isInitialized) return;

            set({ themeLoading: true, themeError: null });

            try {
                const themeIdSet = new Set(themeIds);
                // S1: 传入 ActionMeta 用于 dev 日志
                await settingsRepository.update(draft => {
                    draft.inputSettings.themes = draft.inputSettings.themes?.filter(t => !themeIdSet.has(t.id)) || [];
                }, createSliceMeta('theme.batchDeleteThemes'));
                // S2: settings 由 ServiceManager 订阅 SettingsRepository 统一更新
                set({ themeLoading: false });
            } catch (error: any) {
                devError('[ThemeSlice] batchDeleteThemes 失败:', error);
                set({ themeError: error.message || '批量删除主题失败', themeLoading: false });
            }
        },

        batchUpdateThemeStatus: async (themeIds: string[], status: ActiveStatus): Promise<void> => {
            const state = get();
            if (!state.isInitialized) return;

            set({ themeLoading: true, themeError: null });

            try {
                // S1: 传入 ActionMeta 用于 dev 日志
                await settingsRepository.update(draft => {
                    const themePaths = themeIds
                        .map(id => draft.inputSettings.themes?.find(t => t.id === id)?.path)
                        .filter(Boolean) as string[];

                    if (!draft.activeThemePaths) {
                        draft.activeThemePaths = [];
                    }

                    if (status === 'active') {
                        themePaths.forEach(path => {
                            if (!draft.activeThemePaths!.includes(path)) {
                                draft.activeThemePaths!.push(path);
                            }
                        });
                    } else {
                        draft.activeThemePaths = draft.activeThemePaths.filter(path => !themePaths.includes(path));
                    }
                }, createSliceMeta('theme.batchUpdateThemeStatus'));
                // S2: settings 由 ServiceManager 订阅 SettingsRepository 统一更新
                set({ themeLoading: false });
            } catch (error: any) {
                devError('[ThemeSlice] batchUpdateThemeStatus 失败:', error);
                set({ themeError: error.message || '批量更新主题状态失败', themeLoading: false });
            }
        },

        batchUpdateThemeIcon: async (themeIds: string[], icon: string): Promise<void> => {
            const state = get();
            if (!state.isInitialized) return;

            set({ themeLoading: true, themeError: null });

            try {
                // S1: 传入 ActionMeta 用于 dev 日志
                await settingsRepository.update(draft => {
                    themeIds.forEach(id => {
                        const theme = draft.inputSettings.themes?.find(t => t.id === id);
                        if (theme) {
                            theme.icon = icon;
                        }
                    });
                }, createSliceMeta('theme.batchUpdateThemeIcon'));
                // S2: settings 由 ServiceManager 订阅 SettingsRepository 统一更新
                set({ themeLoading: false });
            } catch (error: any) {
                devError('[ThemeSlice] batchUpdateThemeIcon 失败:', error);
                set({ themeError: error.message || '批量更新主题图标失败', themeLoading: false });
            }
        },

        // ============== 查询方法 ==============

        getThemes: (): ThemeDefinition[] => {
            const state = get();
            return state.settings.inputSettings?.themes || [];
        },

        getTheme: (id: string): ThemeDefinition | undefined => {
            const state = get();
            return state.settings.inputSettings?.themes?.find(t => t.id === id);
        },


        // ============== 状态管理 ==============

        setThemeError: (error: string | null) => {
            set({ themeError: error });
        },
    });
}
