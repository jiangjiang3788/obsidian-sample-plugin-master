import type { ZustandAppStore } from '@/app/store/useAppStore';

export const selectSettings = (s: ZustandAppStore) => s.settings;

export const selectInputSettings = (s: ZustandAppStore) => s.settings.inputSettings;

// inputSettings helpers (avoid repeating nullish checks in UI)
export const selectInputBlocks = (s: ZustandAppStore) => s.settings.inputSettings?.blocks ?? [];
export const selectInputThemes = (s: ZustandAppStore) => s.settings.inputSettings?.themes ?? [];

export const selectAiSettings = (s: ZustandAppStore) => s.settings.aiSettings;

export const selectLayouts = (s: ZustandAppStore) => s.settings.layouts;

export const selectViewInstances = (s: ZustandAppStore) => s.settings.viewInstances;

export const makeSelectLayoutById = (layoutId: string) => (s: ZustandAppStore) =>
  s.settings.layouts?.find((l) => l.id === layoutId);

export const makeSelectViewInstanceById = (instanceId: string) => (s: ZustandAppStore) =>
  s.settings.viewInstances?.find((v) => v.id === instanceId);

export const selectFloatingTimerEnabled = (s: ZustandAppStore) => s.settings.floatingTimerEnabled;


export const selectDevConsoleStackEnabled = (s: ZustandAppStore) => !!s.settings.devConsoleStackEnabled;

const EMPTY_CATEGORY_COLORS: Record<string, string> = {};
export const selectCategoryColors = (s: ZustandAppStore) => s.settings.categoryColors ?? EMPTY_CATEGORY_COLORS;
