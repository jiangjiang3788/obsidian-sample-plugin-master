// src/app/usecases/group.usecase.ts
/**
 * GroupUseCase - 分组相关用例
 * 
 * @deprecated Group 功能已在 S5 移除。Layout/ViewInstance 现使用扁平列表管理。
 * 此文件仅保留接口壳以避免 import 编译错误，所有方法调用会直接抛出异常。
 */

import type { Group, GroupType, Groupable } from '@/core/types/schema';

const DISABLED_ERROR = 'Group feature is disabled (temporarily removed in S5). Use useCases.layout or useCases.viewInstance instead.';

/**
 * 分组用例类
 * 
 * @deprecated 【硬禁用】所有方法直接抛出异常，禁止使用。
 */
export class GroupUseCase {
    /**
     * @deprecated Group feature removed in S5
     * @throws Error always
     */
    async moveItem(itemId: string, targetParentId: string | null): Promise<void> {
        throw new Error(DISABLED_ERROR);
    }

    /**
     * @deprecated Group feature removed in S5
     * @throws Error always
     */
    async addGroup(name: string, parentId: string | null, type: GroupType): Promise<Group | null> {
        throw new Error(DISABLED_ERROR);
    }

    /**
     * @deprecated Group feature removed in S5
     * @throws Error always
     */
    async updateGroup(id: string, updates: Partial<Group>): Promise<void> {
        throw new Error(DISABLED_ERROR);
    }

    /**
     * @deprecated Group feature removed in S5
     * @throws Error always
     */
    async deleteGroup(id: string): Promise<void> {
        throw new Error(DISABLED_ERROR);
    }

    /**
     * @deprecated Group feature removed in S5
     * @throws Error always
     */
    async duplicateGroup(groupId: string): Promise<void> {
        throw new Error(DISABLED_ERROR);
    }

    /**
     * @deprecated Group feature removed in S5
     * @throws Error always
     */
    async reorderItems(
        reorderedSiblings: (Groupable & { isGroup?: boolean })[],
        itemType: 'group' | 'viewInstance' | 'layout'
    ): Promise<void> {
        throw new Error(DISABLED_ERROR);
    }
}

/**
 * 创建分组用例实例
 * @deprecated Group feature removed in S5
 */
export function createGroupUseCase(): GroupUseCase {
    return new GroupUseCase();
}
