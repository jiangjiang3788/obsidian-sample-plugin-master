// src/features/settings/ui/components/SettingsTreeView.tsx
/**
 * @deprecated 【S5 已移除】Group 功能已在 S5 移除。
 * 此文件仅保留作参考，禁止使用。
 * Layout/ViewInstance 现使用扁平列表管理，请使用 LayoutSettings.tsx。
 * 
 * 任何尝试使用此组件都会直接抛出异常。
 */
/** @jsxImportSource preact */
import { h, ComponentChild } from 'preact';

const DEPRECATED_ERROR = 'SettingsTreeView is deprecated. Group feature has been removed in S5. Use LayoutSettings instead.';

/**
 * @deprecated Group feature removed in S5
 * @throws Error always - this component is disabled
 */
export function SettingsTreeView(props: any): never {
    throw new Error(DEPRECATED_ERROR);
}

// ============== 以下为原始代码，仅供参考，不会被执行 ==============
/*
import { useState, useEffect } from 'preact/hooks';
import { Box, Stack, Typography, IconButton, Tooltip, TextField, Collapse, Button } from '@mui/material';
import ArrowRightIcon from '@mui/icons-material/ArrowRight';
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import AddCircleOutlineIcon from '@mui/icons-material/AddCircleOutline';
import DriveFileMoveOutlinedIcon from '@mui/icons-material/DriveFileMoveOutlined';
import DeleteForeverOutlinedIcon from '@mui/icons-material/DeleteForeverOutlined';
import ContentCopyIcon from '@mui/icons-material/ContentCopy';
import type { Group, Groupable } from '@/core/types/schema';
import { createGroupUseCase } from '@/app/usecases/group.usecase';
import { MoveItemDialog } from '@shared/ui/composites/dialogs/MoveItemDialog';

export interface TreeItem extends Groupable {
    name: string;
    isGroup: boolean;
}

// 原始实现已被禁用，详见 S5 迁移说明
*/
