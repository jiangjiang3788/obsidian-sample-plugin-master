// src/features/settings/ui/SettingsTab.tsx
/** @jsxImportSource preact */
import { render } from 'preact';
import { unmountComponentAtNode } from 'preact/compat';
import { PluginSettingTab, App } from 'obsidian';
import { ThemeProvider, CssBaseline, Box, Tabs, Tab } from '@mui/material';
import type ThinkPlugin from '@main';
import { useLocalStorage } from '@shared/hooks';
import { LOCAL_STORAGE_KEYS } from '@/core/types/constants';
import { theme as baseTheme } from '@shared/styles/mui-theme';

import { LayoutSettings } from './LayoutSettings';
import { InputSettings } from './InputSettings';
import { AppStore } from '@/app/AppStore';
import { DataStore } from '@/core/services/DataStore';
import { GeneralSettings } from './GeneralSettings';
import { AiSettings } from './AiSettings';
import { ServicesProvider, type Services } from '@/app/AppStoreContext';

function a11yProps(index: number) {
    return { id: `settings-tab-${index}`, 'aria-controls': `settings-tabpanel-${index}` };
}

function TabPanel(props: { children?: any; value: number; index: number; }) {
    const { children, value, index, ...other } = props;
    return (
        <div role="tabpanel" hidden={value !== index} id={`settings-tabpanel-${index}`} {...other}>
            {value === index && <Box sx={{ p: 2, pt: 3 }}>{children}</Box>}
        </div>
    );
}

function SettingsRoot({ app, appStore, dataStore }: { app: App, appStore: AppStore, dataStore: DataStore }) {
    const [tabIndex, setTabIndex] = useLocalStorage(LOCAL_STORAGE_KEYS.SETTINGS_TABS, 0);

    return (
        <ThemeProvider theme={baseTheme}>
            <CssBaseline />
            <Box sx={{ width: '100%' }} class="think-setting-root">
                <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
                    <Tabs value={tabIndex} onChange={(_, newValue) => setTabIndex(newValue)} aria-label="settings tabs">
                        <Tab label="快速输入" {...a11yProps(0)} />
                        <Tab label="布局" {...a11yProps(1)} />
                        <Tab label="通用" {...a11yProps(2)} />
                        <Tab label="AI" {...a11yProps(3)} />
                    </Tabs>
                </Box>
                <TabPanel value={tabIndex} index={0}><InputSettings appStore={appStore} dataStore={dataStore} /></TabPanel>
                <TabPanel value={tabIndex} index={1}><LayoutSettings app={app} appStore={appStore} /></TabPanel>
                <TabPanel value={tabIndex} index={2}><GeneralSettings appStore={appStore} /></TabPanel>
                <TabPanel value={tabIndex} index={3}><AiSettings /></TabPanel>
            </Box>
        </ThemeProvider>
    );
}

export class SettingsTab extends PluginSettingTab {
    id: string;
    private services: Services;

    constructor(public app: App, private plugin: ThinkPlugin, private dataStore: DataStore) {
        super(app, plugin);
        this.id = plugin.manifest.id;
        // 初始化 services 对象
        this.services = {
            appStore: plugin.appStore,
            dataStore: plugin.dataStore,
            inputService: plugin.inputService,
            useCases: plugin.useCases,
        };
    }

    display(): void {
        const { containerEl } = this;
        containerEl.empty();
        render(
            <ServicesProvider services={this.services}>
                <SettingsRoot app={this.app} appStore={this.plugin.appStore} dataStore={this.dataStore} />
            </ServicesProvider>,
            containerEl
        );
    }

    hide(): void {
        unmountComponentAtNode(this.containerEl);
    }
}
